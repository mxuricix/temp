#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_manuals.py - Genera los manuales PDF de ejecucion (identidad iSOC/Devel).

Produce dos PDF:
  1) Manual de Validacion de Fuentes de Informacion  (para el CLIENTE)
  2) Manual de Certificacion de Reglas SIEM          (uso INTERNO Devel)

Requiere: reportlab, Pillow.  Uso:  python tools/build_manuals.py
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Preformatted, Image, KeepTogether)

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
LOGO = os.path.join(REPO, "logo.png")

DARK   = colors.HexColor("#0d0f13")
ORANGE = colors.HexColor("#ff3a0e")
ORANGE2= colors.HexColor("#ff6a43")
INK    = colors.HexColor("#1a1f29")
MUTE   = colors.HexColor("#6b7280")
LINE   = colors.HexColor("#e5e7eb")
CODEBG = colors.HexColor("#f3f4f6")
OKC    = colors.HexColor("#15803d")
WARNC  = colors.HexColor("#a16207")
BADC   = colors.HexColor("#b91c1c")

# ----------------------------- estilos -----------------------------------
def styles():
    base = ParagraphStyle('base', fontName='Helvetica', fontSize=10.5, leading=15,
                          textColor=INK, alignment=TA_LEFT, spaceAfter=6)
    return {
        'base': base,
        'h1': ParagraphStyle('h1', parent=base, fontName='Helvetica-Bold', fontSize=16,
                             leading=20, textColor=colors.HexColor("#0e7490"),
                             spaceBefore=16, spaceAfter=8),
        'h2': ParagraphStyle('h2', parent=base, fontName='Helvetica-Bold', fontSize=12.5,
                             leading=16, textColor=INK, spaceBefore=12, spaceAfter=5),
        'muted': ParagraphStyle('muted', parent=base, fontSize=9, textColor=MUTE),
        'code': ParagraphStyle('code', parent=base, fontName='Courier', fontSize=9,
                               leading=12.5, textColor=colors.HexColor("#111827"),
                               backColor=CODEBG, borderColor=LINE, borderWidth=0.5,
                               borderPadding=7, spaceBefore=4, spaceAfter=8),
        'bullet': ParagraphStyle('bullet', parent=base, leftIndent=14, bulletIndent=2,
                                 spaceAfter=3),
        't1': ParagraphStyle('t1', fontName='Helvetica-Bold', fontSize=8.5, leading=11,
                             textColor=colors.HexColor("#9aa3b2")),
        't2': ParagraphStyle('t2', fontName='Helvetica-Bold', fontSize=18, leading=21,
                             textColor=colors.white),
        't3': ParagraphStyle('t3', fontName='Helvetica-Bold', fontSize=10.5, leading=13,
                             textColor=ORANGE2),
    }

ST = styles()

# ------------------------- banda de certificacion -------------------------
def cert_band(subtitle):
    # logo escalado (ratio 1315x753)
    if os.path.isfile(LOGO):
        h = 42
        w = h * (1315.0 / 753.0)
        logo = Image(LOGO, width=w, height=h)
    else:
        logo = Paragraph("<b>DEVEL</b>", ST['t2'])
    txt = [
        Paragraph("CERTIFICACION DE FUENTES DE INFORMACION", ST['t1']),
        Spacer(1, 2),
        Paragraph("iSOC &mdash; Devel Group", ST['t2']),
        Spacer(1, 2),
        Paragraph(subtitle, ST['t3']),
    ]
    inner = Table([[logo, txt]], colWidths=[70, None])
    inner.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), DARK),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (0, 0), 14),
        ('LEFTPADDING', (1, 0), (1, 0), 16),
        ('RIGHTPADDING', (-1, 0), (-1, 0), 14),
        ('TOPPADDING', (0, 0), (-1, -1), 12),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('LINEBELOW', (0, 0), (-1, -1), 2.2, ORANGE),
    ]))
    return inner

# ------------------------------- bloques ----------------------------------
def code(txt):
    # escapar &,<,> para Preformatted? Preformatted no interpreta markup -> ok tal cual
    return Preformatted(txt, ST['code'])

def bullets(items):
    out = []
    for it in items:
        out.append(Paragraph(("&bull;&nbsp;&nbsp;" + it), ST['bullet']))
    return out

def verdict_table():
    data = [
        [Paragraph("<b>Veredicto</b>", ST['base']), Paragraph("<b>Significado</b>", ST['base'])],
        [Paragraph('<font color="#15803d"><b>COVERED</b></font>', ST['base']),
         Paragraph("El host genera toda la telemetria necesaria para detectar ese comando.", ST['base'])],
        [Paragraph('<font color="#a16207"><b>PARTIAL</b></font>', ST['base']),
         Paragraph("Genera lo basico, pero falta enriquecimiento (linea de comandos, PS logging, reenvio a SIEM, etc.).", ST['base'])],
        [Paragraph('<font color="#b91c1c"><b>NOT_COVERED</b></font>', ST['base']),
         Paragraph("Falta la telemetria primaria: el comando no se veria. Requiere accion.", ST['base'])],
    ]
    t = Table(data, colWidths=[90, None])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
        ('GRID', (0, 0), (-1, -1), 0.5, LINE),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    return t

def callout(txt, kind='info'):
    c = {'info': colors.HexColor("#0e7490"), 'warn': WARNC, 'bad': BADC}[kind]
    bg = {'info': colors.HexColor("#ecfeff"), 'warn': colors.HexColor("#fef9c3"),
          'bad': colors.HexColor("#fee2e2")}[kind]
    p = Paragraph(txt, ParagraphStyle('co', parent=ST['base'], textColor=colors.HexColor("#111827")))
    t = Table([[p]], colWidths=[None])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg),
        ('LINEBEFORE', (0, 0), (0, -1), 3, c),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    return t

# ------------------------------ footer ------------------------------------
def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 7.5)
    canvas.setFillColor(MUTE)
    canvas.drawString(18 * mm, 10 * mm,
                      "Devel Security  —  Certificacion SOC / STRIKE   ·   CONFIDENCIAL")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, "Pag. %d" % doc.page)
    canvas.setStrokeColor(LINE)
    canvas.line(18 * mm, 13 * mm, A4[0] - 18 * mm, 13 * mm)
    canvas.restoreState()

def build(path, subtitle, story_blocks):
    doc = SimpleDocTemplate(path, pagesize=A4,
                            leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=14 * mm, bottomMargin=18 * mm,
                            title=subtitle, author="Devel Group - iSOC")
    story = [cert_band(subtitle), Spacer(1, 14)]
    story += story_blocks
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print("[+] PDF:", path)

# =========================================================================
#  CONTENIDO - Manual 1: Validacion de Fuentes (CLIENTE)
# =========================================================================
def manual_cliente():
    s = []
    s.append(Paragraph("Manual de Validacion de Fuentes de Informacion", ST['h1']))
    s.append(Paragraph(
        "Esta guia permite al cliente verificar que sus endpoints <b>Windows</b> y "
        "<b>Linux</b> estan configurados para generar la telemetria (logs, auditoria, "
        "Sysmon/auditd) que el SOC necesita para detectar las tecnicas de la metodologia "
        "STRIKE. El resultado es un reporte HTML de certificacion que se entrega al equipo de Devel.",
        ST['base']))
    s.append(callout(
        "<b>Importante:</b> ninguno de los scripts ejecuta comandos ofensivos ni modifica "
        "configuraciones. Son de <b>solo lectura</b>: consultan la configuracion del sistema "
        "y producen un informe. Pueden correrse en produccion.", 'info'))

    s.append(Paragraph("1. Contenido del paquete", ST['h2']))
    s += bullets([
        "<font face='Courier'>windows\\Invoke-StrikeTelemetryAudit.ps1</font> &mdash; audit para Windows.",
        "<font face='Courier'>linux/strike_linux_posture_audit.sh</font> &mdash; audit para Linux.",
        "<font face='Courier'>catalog/strike_catalog.json</font> &mdash; catalogo de tecnicas STRIKE (no editar).",
        "<font face='Courier'>logo.png</font> &mdash; identidad para el reporte.",
    ])

    s.append(Paragraph("2. Ejecucion en Windows", ST['h2']))
    s.append(Paragraph("Abrir <b>PowerShell como Administrador</b> (obligatorio: la lectura de "
                       "<font face='Courier'>auditpol</font> requiere privilegios). Ubicarse en la carpeta y ejecutar:", ST['base']))
    s.append(code(
        "cd <carpeta-del-paquete>\n"
        "powershell -ExecutionPolicy Bypass -File .\\windows\\Invoke-StrikeTelemetryAudit.ps1 -OpenReport"))
    s.append(Paragraph("Parametros utiles:", ST['base']))
    s += bullets([
        "<font face='Courier'>-OpenReport</font> &mdash; abre el reporte HTML al terminar.",
        "<font face='Courier'>-OutputDir C:\\ruta</font> &mdash; carpeta donde dejar los reportes.",
        "<font face='Courier'>-Full</font> &mdash; incluye en consola todos los pasos (no solo los que fallan).",
        "<font face='Courier'>-DeepSysmon</font> &mdash; inspecciona la configuracion efectiva de Sysmon.",
    ])
    s.append(callout(
        "Si se ejecuta <b>sin</b> privilegios de administrador, las subcategorias de "
        "<font face='Courier'>auditpol</font> quedan en UNKNOWN e inflan los NOT_COVERED. "
        "Siempre correr en consola elevada.", 'warn'))

    s.append(Paragraph("3. Ejecucion en Linux", ST['h2']))
    s.append(Paragraph("Ejecutar como <b>root</b> (con <font face='Courier'>sudo</font>): "
                       "<font face='Courier'>auditctl -l</font> solo lista reglas con privilegios.", ST['base']))
    s.append(code(
        "cd <carpeta-del-paquete>\n"
        "chmod +x linux/strike_linux_posture_audit.sh\n"
        "sudo ./linux/strike_linux_posture_audit.sh --output-dir ./reportes"))
    s.append(Paragraph("Genera en la carpeta de salida un <b>.html</b> (reporte de certificacion) "
                       "y un <b>.csv</b> con el detalle por tecnica.", ST['base']))

    s.append(Paragraph("4. Como leer el reporte", ST['h2']))
    s.append(Paragraph("El reporte clasifica cada paso de STRIKE con uno de tres veredictos:", ST['base']))
    s.append(verdict_table())
    s.append(Spacer(1, 6))
    s.append(Paragraph("La seccion <b>Acciones recomendadas</b> indica, por cada fuente de datos "
                       "faltante, la ruta de GPO (Windows) o el comando (Linux) para habilitarla. "
                       "Tras aplicar los cambios, volver a ejecutar para confirmar el avance.", ST['base']))

    s.append(Paragraph("5. Que entregar a Devel", ST['h2']))
    s += bullets([
        "El archivo <b>.html</b> generado (por cada host o muestra representativa).",
        "Opcionalmente el <b>.csv</b> para consolidacion.",
        "Indicar sistema operativo y rol del equipo auditado.",
    ])
    s.append(callout(
        "Objetivo de la certificacion: que las fuentes de informacion del endpoint esten "
        "completas <b>antes</b> de confiar en las reglas de deteccion del SIEM.", 'info'))
    return s

# =========================================================================
#  CONTENIDO - Manual 2: Certificacion de Reglas SIEM (INTERNO)
# =========================================================================
def manual_interno():
    s = []
    s.append(Paragraph("Manual de Certificacion de Reglas SIEM &mdash; USO INTERNO", ST['h1']))
    s.append(callout(
        "<b>Documento interno de Devel / iSOC.</b> No distribuir al cliente. Describe la "
        "emision de eventos sinteticos de certificacion hacia el SIEM.", 'bad'))
    s.append(Paragraph(
        "<font face='Courier'>strike_syslog_emitter.sh</font> envia al receptor syslog del SIEM una "
        "<b>rafaga</b> de eventos sinteticos &mdash; uno por cada paso del catalogo STRIKE (337) &mdash; "
        "emulando un endpoint llamado <b>EP_CERTIFICATION</b>. Sirve para verificar que las reglas "
        "de deteccion esten bien configuradas: luego se revisa en el SIEM que IDs llegaron y que "
        "alertas se dispararon.", ST['base']))
    s.append(callout(
        "<b>No ejecuta</b> ninguno de los comandos ofensivos: solo construye texto de log y lo envia "
        "por el socket. Cada evento lleva el ID STRIKE (ej. <font face='Courier'>id=1.1</font>), su "
        "tecnica MITRE y el comando representativo.", 'info'))

    s.append(Paragraph("1. Requisitos", ST['h2']))
    s += bullets([
        "Host Linux con <font face='Courier'>bash</font> (redireccion /dev/udp) o <font face='Courier'>nc</font>.",
        "<font face='Courier'>python3</font> o <font face='Courier'>jq</font> para leer el catalogo.",
        "IP y puerto del receptor syslog del SIEM (por defecto UDP/514).",
        "<font face='Courier'>catalog/strike_catalog.json</font> junto al paquete.",
    ])

    s.append(Paragraph("2. Ejecucion", ST['h2']))
    s.append(Paragraph("Rafaga completa (337 eventos) al SIEM:", ST['base']))
    s.append(code(
        "chmod +x linux/strike_syslog_emitter.sh\n"
        "./linux/strike_syslog_emitter.sh -s 10.0.0.50"))
    s.append(Paragraph("Con manifiesto para reconciliar, puerto/proto/formato a medida:", ST['base']))
    s.append(code(
        "./linux/strike_syslog_emitter.sh -s 10.0.0.50 -p 1514 --proto tcp \\\n"
        "    --format rfc5424 --manifest certificacion_$(date +%F).csv"))
    s.append(Paragraph("Filtrar por escenario o plataforma, o ensayar sin enviar:", ST['base']))
    s.append(code(
        "./linux/strike_syslog_emitter.sh -s 10.0.0.50 --scenario 1,2,3\n"
        "./linux/strike_syslog_emitter.sh -s 10.0.0.50 --platform windows\n"
        "./linux/strike_syslog_emitter.sh --dry-run | less"))

    s.append(Paragraph("3. Opciones principales", ST['h2']))
    s += bullets([
        "<font face='Courier'>-s</font> IP del SIEM (obligatorio salvo --dry-run).",
        "<font face='Courier'>-p</font> puerto (514) &nbsp; <font face='Courier'>--proto</font> udp|tcp.",
        "<font face='Courier'>-H</font> hostname emulado (EP_CERTIFICATION) &nbsp; <font face='Courier'>-t</font> tag (STRIKE_CERT).",
        "<font face='Courier'>--format</font> rfc3164 | rfc5424.",
        "<font face='Courier'>--scenario</font> N[,N...] &nbsp; <font face='Courier'>--platform</font> windows|linux|aws|azure|cicd|hybrid-ad|kubernetes|entra-m365.",
        "<font face='Courier'>--manifest</font> CSV de lo enviado &nbsp; <font face='Courier'>--delay-ms</font> pausa entre eventos.",
    ])

    s.append(Paragraph("4. Formato del evento", ST['h2']))
    s.append(code(
        '<133>Oct 29 13:16:12 EP_CERTIFICATION STRIKE_CERT[13054]:\n'
        '  STRIKE_CERT run_id=... id=1.1 mitre=T1047 platform=windows\n'
        '  scenario="2025-PA-P1-Windows-Baseline-v01"\n'
        '  step="Windows Management Instrumentation: T1047"\n'
        '  cmd="cmd /c wmic useraccount get /ALL /format:csv"'))
    s.append(Paragraph("Los marcadores <font face='Courier'>RUN_START</font> / "
                       "<font face='Courier'>RUN_END</font> acotan el lote; cada corrida lleva un "
                       "<font face='Courier'>run_id</font> unico.", ST['base']))

    s.append(Paragraph("5. Flujo de certificacion en el SIEM", ST['h2']))
    s += bullets([
        "Correr el emisor con <font face='Courier'>--manifest</font>.",
        "En el SIEM filtrar <font face='Courier'>host=EP_CERTIFICATION</font> y/o "
        "<font face='Courier'>tag=STRIKE_CERT</font>, acotando por <font face='Courier'>run_id</font>.",
        "Cruzar el manifiesto (enviados) contra lo recibido/alertado.",
        "Cada ID sin alerta = regla faltante o mal configurada &rarr; corregir y reejecutar.",
    ])
    s.append(callout(
        "El camino SIEM/syslog cubre TODA la metodologia (Windows, Linux y los escenarios cloud: "
        "AWS, Azure, CICD, Entra, Kubernetes, M365). El audit de postura de endpoint cubre solo lo "
        "que es telemetria de host.", 'info'))
    return s

# ------------------------------- main -------------------------------------
def main():
    out1 = os.path.join(REPO, "entregables", "validacion-fuentes-clientes",
                        "Manual-Validacion-Fuentes-de-Informacion.pdf")
    out2 = os.path.join(REPO, "entregables", "certificacion-devel-interno",
                        "Manual-Certificacion-Reglas-SIEM-INTERNO.pdf")
    os.makedirs(os.path.dirname(out1), exist_ok=True)
    os.makedirs(os.path.dirname(out2), exist_ok=True)
    build(out1, "Validacion de Fuentes &middot; Cliente (Windows / Linux)", manual_cliente())
    build(out2, "Certificacion de Reglas SIEM &middot; Uso interno", manual_interno())


if __name__ == "__main__":
    main()
