# CI/CD Supply Chain Compromise to Production

| | |
|---|---|
| **Status** | draft |
| **Severity** | critical |
| **Target environment** | GitHub Actions, GitLab CI/CD, Jenkins, Azure Pipelines u otra plataforma con repositorio, runner, secrets, registry y target BAS |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078.004 — Cloud Accounts |
| **Tags** | `cicd` · `software-supply-chain` · `atomic-tests` · `poisoned-pipeline` · `runner` · `oidc` · `secrets` · `artifact-integrity` · `slsa` · `deployment` · `attack-flow` · `rollback` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T21:06:13.314Z |
| **Actualizado** | 2026-07-20T21:06:13.314Z |

## Descripción

Escenario BAS canónico para SCM y CI/CD heterogéneos. Modela identidad comprometida, descubrimiento de repositorio y pipeline, Poisoned Pipeline Execution directo e indirecto, abuso de dependencias y componentes, acceso a runner y secretos, OIDC hacia cloud, manipulación de artefactos y provenance, bypass de gates, despliegue canary, persistencia y evasión. Cada step es un procedimiento atómico independiente.

## Steps

### 1. Validar token de SCM

**MITRE:** T1078.004

Validar un token BAS contra la API del repositorio sin modificar contenido.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api user | tee "${STRIKE_STATE_DIR}/scm-identity.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api user | tee "${STRIKE_STATE_DIR}/scm-identity.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/me/api/json" | tee "${STRIKE_STATE_DIR}/scm-identity.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se devuelve la identidad o el token es rechazado.

**Señales de detección:**

Audit log de autenticación API, token, IP, user agent y organización.

### 2. Enumerar repositorios accesibles

**MITRE:** T1213.003

Enumerar repositorios visibles para la identidad comprometida.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh repo list --limit 100 --json nameWithOwner,visibility | tee "${STRIKE_STATE_DIR}/repositories.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab repo list --per-page 100 --output json | tee "${STRIKE_STATE_DIR}/repositories.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/api/json?tree=jobs[name,url]" | tee "${STRIKE_STATE_DIR}/repositories.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se obtiene el inventario o una denegación.

**Señales de detección:**

API list repositories y acceso anómalo a múltiples proyectos.

### 3. Inspeccionar protección de branches

**MITRE:** T1213.003

Consultar reglas de protección, revisiones y restricciones del branch principal.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}/branches/${STRIKE_DEFAULT_BRANCH}/protection" | tee "${STRIKE_STATE_DIR}/branch-protection.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api "projects/${STRIKE_PROJECT_ID}/protected_branches/${STRIKE_DEFAULT_BRANCH}" | tee "${STRIKE_STATE_DIR}/branch-protection.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/config.xml" | tee "${STRIKE_STATE_DIR}/job-config.xml"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se obtiene la configuración de protección.

**Señales de detección:**

Consultas de administración sobre branch protection.

### 4. Enumerar definiciones de pipeline

**MITRE:** T1213.003

Identificar workflows, .gitlab-ci.yml o Jenkinsfile y scripts referenciados.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}/contents/.github/workflows" | tee "${STRIKE_STATE_DIR}/pipeline-files.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api "projects/${STRIKE_PROJECT_ID}/repository/files/.gitlab-ci.yml?ref=${STRIKE_DEFAULT_BRANCH}" | tee "${STRIKE_STATE_DIR}/pipeline-files.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/config.xml" | tee "${STRIKE_STATE_DIR}/pipeline-files.xml"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se identifican archivos ejecutables por CI/CD.

**Señales de detección:**

Lectura de archivos de pipeline seguida por cambios o ejecuciones.

### 5. Enumerar runners o agentes

**MITRE:** T1526

Enumerar runners, etiquetas, grupos y estado cuando la plataforma lo permita.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}/actions/runners" | tee "${STRIKE_STATE_DIR}/runners.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api "projects/${STRIKE_PROJECT_ID}/runners" | tee "${STRIKE_STATE_DIR}/runners.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/computer/api/json" | tee "${STRIKE_STATE_DIR}/runners.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se obtiene metadata de runners o acceso denegado.

**Señales de detección:**

API runner inventory y consulta de self-hosted runners.

### 6. Enumerar environments y gates

**MITRE:** T1526

Enumerar entornos de despliegue, aprobaciones y secretos asociados como metadata.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}/environments" | tee "${STRIKE_STATE_DIR}/environments.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api "projects/${STRIKE_PROJECT_ID}/environments" | tee "${STRIKE_STATE_DIR}/environments.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/api/json?tree=property[*]" | tee "${STRIKE_STATE_DIR}/environments.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se identifican entornos protegidos.

**Señales de detección:**

Consultas de environments y protection rules.

### 7. Enumerar metadata de secretos

**MITRE:** T1526

Enumerar nombres de variables o secretos sin solicitar valores.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}/actions/secrets" | tee "${STRIKE_STATE_DIR}/secret-metadata.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api "projects/${STRIKE_PROJECT_ID}/variables" | tee "${STRIKE_STATE_DIR}/secret-metadata.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/credentials/store/system/domain/_/api/json" | tee "${STRIKE_STATE_DIR}/secret-metadata.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

Se obtiene metadata o el control lo bloquea.

**Señales de detección:**

API de secrets/variables desde identidad no administrativa.

### 8. Crear branch BAS

**MITRE:** T1136

Crear un branch efímero strike-bas/run-id para preparar modificaciones controladas.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
git fetch origin "${STRIKE_DEFAULT_BRANCH}"
git checkout -B "strike-bas/${STRIKE_RUN_ID}" "origin/${STRIKE_DEFAULT_BRANCH}"
git push --set-upstream origin "strike-bas/${STRIKE_RUN_ID}"
printf '%s' "strike-bas/${STRIKE_RUN_ID}" > "${STRIKE_STATE_DIR}/branch-name"
```

**Resultado esperado:**

El branch se crea y luego se elimina.

**Señales de detección:**

Creación de branch por token inusual y nombre BAS.

### 9. Modificar directamente pipeline canary

**MITRE:** T1677

Añadir un comando canary a la definición de pipeline en un branch BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
cp "${STRIKE_PIPELINE_FILE}" "${STRIKE_STATE_DIR}/pipeline.original"
printf '
# STRIKE BAS direct PPE %s
' "${STRIKE_RUN_ID}" >> "${STRIKE_PIPELINE_FILE}"
git add "${STRIKE_PIPELINE_FILE}"
git commit -m "STRIKE BAS: direct pipeline canary ${STRIKE_RUN_ID}"
git push origin HEAD
```

**Resultado esperado:**

La plataforma ejecuta o bloquea el pipeline modificado.

**Señales de detección:**

Cambio de workflow/Jenkinsfile y ejecución posterior.

### 10. Modificar script invocado por pipeline

**MITRE:** T1677

Alterar un script de build referenciado por el pipeline sin modificar la definición principal.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
cp "${STRIKE_BUILD_SCRIPT}" "${STRIKE_STATE_DIR}/build-script.original"
printf '
printf "strike-bas-indirect-%s\n" "${STRIKE_RUN_ID}" > "${STRIKE_STATE_DIR}/indirect.marker"
' >> "${STRIKE_BUILD_SCRIPT}"
git add "${STRIKE_BUILD_SCRIPT}"
git commit -m "STRIKE BAS: indirect pipeline canary ${STRIKE_RUN_ID}"
git push origin HEAD
```

**Resultado esperado:**

El comando canary se ejecuta indirectamente o el control lo bloquea.

**Señales de detección:**

Cambio en scripts/build.sh seguido por job CI.

### 11. Simular ejecución desde contribución no confiable

**MITRE:** T1677

Crear una contribución BAS desde branch/fork controlado para validar triggers y acceso a secretos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh workflow run "${STRIKE_GITHUB_WORKFLOW}" --repo "${STRIKE_REPOSITORY}" --ref "strike-bas/${STRIKE_RUN_ID}" -f bas_input="${STRIKE_UNTRUSTED_INPUT}"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/pipeline" -f ref="strike-bas/${STRIKE_RUN_ID}" -f "variables[][key]=STRIKE_BAS_INPUT" -f "variables[][value]=${STRIKE_UNTRUSTED_INPUT}"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -X POST -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/buildWithParameters?STRIKE_BAS_INPUT=$(python3 -c 'import urllib.parse,os; print(urllib.parse.quote(os.environ["STRIKE_UNTRUSTED_INPUT"]))')"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

La ejecución es aislada o bloqueada según políticas.

**Señales de detección:**

Pipeline de PR/MR, actor externo, trigger pull_request_target o equivalente.

### 12. Inyectar input no confiable en shell canary

**MITRE:** T1677

Pasar un valor sintético con metacaracteres a un pipeline diseñado para demostrar interpolación insegura sin ejecutar payload externo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh workflow run "${STRIKE_GITHUB_WORKFLOW}" --repo "${STRIKE_REPOSITORY}" --ref "strike-bas/${STRIKE_RUN_ID}" -f bas_input="${STRIKE_UNTRUSTED_INPUT}"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/pipeline" -f ref="strike-bas/${STRIKE_RUN_ID}" -f "variables[][key]=STRIKE_BAS_INPUT" -f "variables[][value]=${STRIKE_UNTRUSTED_INPUT}"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -X POST -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/buildWithParameters?STRIKE_BAS_INPUT=$(python3 -c 'import urllib.parse,os; print(urllib.parse.quote(os.environ["STRIKE_UNTRUSTED_INPUT"]))')"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

La prueba demuestra sanitización o genera una marca local.

**Señales de detección:**

Inputs de issue/PR/branch usados en comandos shell.

### 13. Modificar template reusable/include

**MITRE:** T1677

Cambiar una plantilla reutilizable canary referenciada por otros pipelines.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
cp "${STRIKE_REUSABLE_TEMPLATE}" "${STRIKE_STATE_DIR}/template.original"
printf '
# STRIKE BAS reusable template mutation %s
' "${STRIKE_RUN_ID}" >> "${STRIKE_REUSABLE_TEMPLATE}"
git add "${STRIKE_REUSABLE_TEMPLATE}"
git commit -m "STRIKE BAS: reusable template canary ${STRIKE_RUN_ID}"
git push origin HEAD
```

**Resultado esperado:**

El cambio afecta la ejecución canary o es bloqueado por revisión.

**Señales de detección:**

Cambio en reusable workflow, include o shared library.

### 14. Usar componente de terceros no fijado

**MITRE:** T1195.001

Cambiar una referencia canary desde SHA/digest inmutable hacia tag mutable.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
cp "${STRIKE_PIPELINE_FILE}" "${STRIKE_STATE_DIR}/pipeline-pin.original"
python3 - <<'PY2'
from pathlib import Path
import os,re
p=Path(os.environ['STRIKE_PIPELINE_FILE'])
s=p.read_text()
s2=re.sub(r'(@[0-9a-fA-F]{40})', '@main', s, count=1)
if s2==s: s2=s+'
# STRIKE BAS: no immutable component reference found
'
p.write_text(s2)
PY2
git add "${STRIKE_PIPELINE_FILE}"
git commit -m "STRIKE BAS: mutable component reference ${STRIKE_RUN_ID}"
git push origin HEAD
```

**Resultado esperado:**

El policy engine bloquea o registra la referencia mutable.

**Señales de detección:**

Diff con action/include/plugin no fijado y policy violation.

### 15. Resolver dependencia canary desde registry no esperado

**MITRE:** T1195.001

Solicitar una dependencia sintética cuyo nombre puede resolverse desde un registry alterno controlado.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
npm view "${STRIKE_CANARY_PACKAGE}" --registry "${STRIKE_CANARY_REGISTRY}" --json | tee "${STRIKE_STATE_DIR}/dependency-resolution.json"
```

**Resultado esperado:**

El build usa el registry interno esperado o se detecta la resolución indebida.

**Señales de detección:**

Conexión a registry no autorizado y package resolution.

### 16. Modificar lockfile canary

**MITRE:** T1195.001

Cambiar una dependencia sintética en el lockfile dentro de un branch BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cp "${STRIKE_LOCKFILE}" "${STRIKE_STATE_DIR}/lockfile.original"
printf "\n# strike-bas-change\n" >> "${STRIKE_LOCKFILE}"
```

**Resultado esperado:**

Revisión, hash o policy detecta el cambio.

**Señales de detección:**

Diff de lockfile y origen de paquete nuevo.

### 17. Ejecutar script post-install canary

**MITRE:** T1195.001

Instalar un paquete sintético que ejecuta únicamente una marca local durante post-install.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
mkdir -p "${STRIKE_STATE_DIR}/pkg"
cat > "${STRIKE_STATE_DIR}/pkg/package.json" <<'JSON'
{"name":"strike-bas-package","version":"1.0.0","scripts":{"postinstall":"echo strike-bas-postinstall > postinstall.marker"}}
JSON
(cd "${STRIKE_STATE_DIR}/pkg" && npm install --ignore-scripts=false)
cp "${STRIKE_STATE_DIR}/pkg/postinstall.marker" "${STRIKE_STATE_DIR}/postinstall.marker"
```

**Resultado esperado:**

El runner registra o bloquea scripts de instalación.

**Señales de detección:**

Proceso npm/pip/package hook y archivo marker.

### 18. Enumerar entorno del runner

**MITRE:** T1082

Recolectar OS, usuario, variables no secretas y herramientas del runner.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
uname -a | tee "${STRIKE_STATE_DIR}/runner-uname.txt"
id | tee "${STRIKE_STATE_DIR}/runner-id.txt"
env | sed -E '/TOKEN|SECRET|PASSWORD|KEY|CREDENTIAL/Id' | sort > "${STRIKE_STATE_DIR}/runner-env-sanitized.txt"
```

**Resultado esperado:**

Se obtiene inventario técnico sin imprimir secretos.

**Señales de detección:**

Procesos uname/env filtrado y job anómalo.

### 19. Buscar archivos de credenciales canary

**MITRE:** T1552.001

Buscar únicamente rutas canary del workspace y home del runner, sin leer credenciales reales.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
find "${HOME:-/tmp}" "${STRIKE_WORKSPACE}" -maxdepth 3 -type f \( -name credentials -o -name config.json -o -name kubeconfig -o -name "*.pem" \) -print 2>/dev/null | tee "${STRIKE_STATE_DIR}/credential-file-paths.txt"
```

**Resultado esperado:**

Se detecta o bloquea el acceso a archivos sensibles.

**Señales de detección:**

find/grep sobre .aws, .docker, kubeconfig o archivos canary.

### 20. Acceder a secreto canary del pipeline

**MITRE:** T1552

Calcular el hash de un secreto sintético inyectado por el pipeline sin imprimirlo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
printf %s "${STRIKE_CANARY_SECRET}" | sha256sum | tee "${STRIKE_STATE_DIR}/canary-secret.sha256"
```

**Resultado esperado:**

Se obtiene el hash o el secreto no se entrega al job.

**Señales de detección:**

Acceso a variable protegida y uso por job no habitual.

### 21. Reutilizar token de job

**MITRE:** T1550.001

Usar el token efímero del job para consultar un recurso canary adicional permitido por la plataforma.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api "repos/${STRIKE_REPOSITORY}" | tee "${STRIKE_STATE_DIR}/job-token-reuse.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    : "${CI_JOB_TOKEN:?CI_JOB_TOKEN requerido}" "${CI_API_V4_URL:?CI_API_V4_URL requerido}"; curl -fsS -H "JOB-TOKEN: ${CI_JOB_TOKEN}" "${CI_API_V4_URL}/projects/${STRIKE_PROJECT_ID}" | tee "${STRIKE_STATE_DIR}/job-token-reuse.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/api/json" | tee "${STRIKE_STATE_DIR}/job-token-reuse.json"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

El scope limita el acceso o la consulta es exitosa.

**Señales de detección:**

Job token usado contra otro proyecto, API o package registry.

### 22. Solicitar token OIDC del pipeline

**MITRE:** T1528

Solicitar un ID token OIDC con audiencia canary y guardar solo claims no sensibles.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    : "${ACTIONS_ID_TOKEN_REQUEST_URL:?}" "${ACTIONS_ID_TOKEN_REQUEST_TOKEN:?}"; curl -fsSL -H "Authorization: Bearer ${ACTIONS_ID_TOKEN_REQUEST_TOKEN}" "${ACTIONS_ID_TOKEN_REQUEST_URL}&audience=${STRIKE_OIDC_AUDIENCE}" | tee "${STRIKE_STATE_DIR}/oidc-response.json"; jq -r .value "${STRIKE_STATE_DIR}/oidc-response.json" > "${STRIKE_OIDC_TOKEN_FILE}"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    : "${CI_JOB_JWT_V2:?CI_JOB_JWT_V2 requerido}"; printf %s "${CI_JOB_JWT_V2}" > "${STRIKE_OIDC_TOKEN_FILE}"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    : "${STRIKE_OIDC_TOKEN:?STRIKE_OIDC_TOKEN requerido}"; printf %s "${STRIKE_OIDC_TOKEN}" > "${STRIKE_OIDC_TOKEN_FILE}"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

El token se emite únicamente con permisos explícitos.

**Señales de detección:**

OIDC token request, audience, subject, repo, branch y workflow.

### 23. Asumir rol cloud BAS mediante OIDC

**MITRE:** T1548.005

Intercambiar el token OIDC por una sesión temporal restringida a recursos BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
aws sts assume-role-with-web-identity --role-arn "${STRIKE_OIDC_ROLE_ARN}" --role-session-name "strike-cicd-${STRIKE_RUN_ID}" --web-identity-token "$(cat "${STRIKE_OIDC_TOKEN_FILE}")" --duration-seconds 900 --output json > "${STRIKE_STATE_DIR}/oidc-session.json"
jq '{AssumedRoleUser:.AssumedRoleUser,Expiration:.Credentials.Expiration}' "${STRIKE_STATE_DIR}/oidc-session.json"
```

**Resultado esperado:**

El trust policy acepta claims autorizados o bloquea la sesión.

**Señales de detección:**

STS/Cloud audit AssumeRoleWithWebIdentity y claims.

### 24. Comprobar acceso al socket Docker

**MITRE:** T1059.013

Consultar docker info o equivalente desde runner canary sin crear contenedores privilegiados.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
docker info --format "{{json .ServerVersion}}" | tee "${STRIKE_STATE_DIR}/docker-info.txt"
```

**Resultado esperado:**

El socket no está disponible o se registra el acceso.

**Señales de detección:**

Proceso docker, acceso a /var/run/docker.sock y API daemon.

### 25. Crear marcador persistente en runner

**MITRE:** T1543

Crear y eliminar un archivo marker en una ruta BAS para comprobar persistencia entre jobs de runner reutilizado.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
printf "strike-bas-%s" "${STRIKE_RUN_ID:-manual}" > "${STRIKE_RUNNER_MARKER}"
```

**Resultado esperado:**

El siguiente job encuentra el marker solo si el runner conserva estado.

**Señales de detección:**

Escritura fuera del workspace y reutilización de runner.

### 26. Modificar artefacto después del build

**MITRE:** T1565.001

Cambiar un archivo canary después de calcular su digest y antes de publicación.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cp "${STRIKE_ARTIFACT}" "${STRIKE_STATE_DIR}/artifact.original"
sha256sum "${STRIKE_ARTIFACT}" > "${STRIKE_STATE_DIR}/artifact.before.sha256"
printf "\nstrike-bas-tamper\n" >> "${STRIKE_ARTIFACT}"
sha256sum "${STRIKE_ARTIFACT}" > "${STRIKE_STATE_DIR}/artifact.after.sha256"
```

**Resultado esperado:**

La verificación detecta que el digest cambió.

**Señales de detección:**

Artifact hash mismatch y modificación fuera de etapa build.

### 27. Sobrescribir tag mutable canary

**MITRE:** T1195.002

Publicar un segundo digest bajo el mismo tag canary en un registry aislado.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
tmp="${STRIKE_STATE_DIR}/oci-image"
mkdir -p "${tmp}"
printf 'first-%s
' "${STRIKE_RUN_ID}" > "${tmp}/payload.txt"
cat > "${tmp}/Dockerfile" <<'EOF'
FROM scratch
COPY payload.txt /payload.txt
EOF
docker build -t "${STRIKE_REGISTRY_IMAGE}:${STRIKE_MUTABLE_TAG}" "${tmp}"
docker push "${STRIKE_REGISTRY_IMAGE}:${STRIKE_MUTABLE_TAG}"
printf 'second-%s
' "${STRIKE_RUN_ID}" > "${tmp}/payload.txt"
docker build -t "${STRIKE_REGISTRY_IMAGE}:${STRIKE_MUTABLE_TAG}" "${tmp}"
docker push "${STRIKE_REGISTRY_IMAGE}:${STRIKE_MUTABLE_TAG}"
```

**Resultado esperado:**

La inmutabilidad bloquea el push o se detecta el digest nuevo.

**Señales de detección:**

Registry PutImage/push con tag existente y digest distinto.

### 28. Publicar paquete canary

**MITRE:** T1195.002

Publicar una versión sintética en un namespace de paquete BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
pkg="${STRIKE_STATE_DIR}/npm-package"
mkdir -p "${pkg}"
cat > "${pkg}/package.json" <<EOF
{"name":"${STRIKE_PACKAGE_NAME}","version":"0.0.${STRIKE_RUN_ID//[^0-9]/0}","description":"STRIKE BAS synthetic package"}
EOF
printf 'module.exports="strike-bas";
' > "${pkg}/index.js"
(cd "${pkg}" && npm publish --registry "${STRIKE_PACKAGE_REGISTRY}")
```

**Resultado esperado:**

La publicación queda registrada y se elimina o depreca después.

**Señales de detección:**

Package publish por token CI y nuevo versionado.

### 29. Generar provenance del artefacto

**MITRE:** T1213

Generar provenance canary con sujeto, digest y parámetros del build.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
python3 - <<'PY2'
import hashlib,json,os
p=os.environ["STRIKE_ARTIFACT"]
h=hashlib.sha256(open(p,"rb").read()).hexdigest()
json.dump({"subject":[{"name":os.path.basename(p),"digest":{"sha256":h}}],"builder":{"id":"strike-bas"}},open(os.environ["STRIKE_STATE_DIR"]+"/provenance.json","w"),indent=2)
PY2
```

**Resultado esperado:**

El archivo de provenance referencia el digest correcto.

**Señales de detección:**

Creación de attestation/provenance en job.

### 30. Alterar provenance canary

**MITRE:** T1565.001

Modificar el digest dentro de una copia canary del provenance.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cp "${STRIKE_STATE_DIR}/provenance.json" "${STRIKE_STATE_DIR}/provenance.original.json"
python3 - <<'PY2'
import json,os
p=os.environ["STRIKE_STATE_DIR"]+"/provenance.json"
d=json.load(open(p)); d["subject"][0]["digest"]["sha256"]="0"*64; json.dump(d,open(p,"w"),indent=2)
PY2
```

**Resultado esperado:**

La verificación debe fallar.

**Señales de detección:**

Cambio de attestation y fallo de validación.

### 31. Intentar desplegar artefacto sin firma

**MITRE:** T1072

Solicitar deployment canary con artefacto sin firma o attestation válida.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v cosign >/dev/null 2>&1 || { echo "cosign requerido" >&2; exit 90; }
if cosign verify "${STRIKE_REGISTRY_IMAGE}:${STRIKE_MUTABLE_TAG}" > "${STRIKE_STATE_DIR}/signature-check.txt" 2>&1; then
  echo "La imagen está firmada; la prueba unsigned no aplica" >&2
  exit 90
fi
kubectl apply --dry-run=server -n "${STRIKE_DEPLOY_NAMESPACE}" -f "${STRIKE_DEPLOYMENT_MANIFEST}"
```

**Resultado esperado:**

El gate bloquea o evidencia una brecha de integridad.

**Señales de detección:**

Deployment event sin signature/provenance válido.

### 32. Modificar manifiesto de despliegue

**MITRE:** T1072

Cambiar imagen o versión canary en un manifest de deployment.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cp "${STRIKE_DEPLOYMENT_MANIFEST}" "${STRIKE_STATE_DIR}/deployment.original"
python3 - <<'PY2'
from pathlib import Path
import os,re
p=Path(os.environ['STRIKE_DEPLOYMENT_MANIFEST'])
s=p.read_text()
s2=re.sub(r'(image:\s*)\S+', r''+os.environ['STRIKE_IMAGE_REPLACEMENT'], s, count=1)
if s2==s: raise SystemExit('No se encontró campo image:')
p.write_text(s2)
PY2
```

**Resultado esperado:**

El cambio requiere aprobación o se despliega al target BAS.

**Señales de detección:**

Diff de manifest/Helm values y deployment posterior.

### 33. Intentar omitir aprobación manual

**MITRE:** T1072

Intentar promover un deployment BAS sin satisfacer el gate de aprobación.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh workflow run "${STRIKE_GITHUB_WORKFLOW}" --repo "${STRIKE_REPOSITORY}" --ref "strike-bas/${STRIKE_RUN_ID}" -f environment="${STRIKE_DEPLOY_NAMESPACE}"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/jobs/${STRIKE_ARTIFACT_ID}/play"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    curl -fsS -X POST -u "${JENKINS_USER}:${JENKINS_API_TOKEN}" "${JENKINS_URL}/job/${STRIKE_JENKINS_JOB}/build?token=${STRIKE_JENKINS_BUILD_TOKEN}"
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

La plataforma bloquea el deployment o registra bypass.

**Señales de detección:**

Deployment sin reviewer, environment protection o manual job.

### 34. Desplegar artefacto canary

**MITRE:** T1072

Desplegar únicamente la aplicación sintética del laboratorio.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
kubectl apply -n "${STRIKE_DEPLOY_NAMESPACE}" -f "${STRIKE_DEPLOYMENT_MANIFEST}"
kubectl rollout status -n "${STRIKE_DEPLOY_NAMESPACE}" -f "${STRIKE_DEPLOYMENT_MANIFEST}" --timeout=180s
```

**Resultado esperado:**

El target muestra la versión canary esperada.

**Señales de detección:**

Deployment event, identity, artifact digest y target.

### 35. Omitir etapa de seguridad canary

Modificar condiciones para saltar una etapa de scanning sintética en el branch BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
cd "${STRIKE_WORKSPACE}"
cp "${STRIKE_PIPELINE_FILE}" "${STRIKE_STATE_DIR}/pipeline-security.original"
printf '
# STRIKE BAS: security stage bypass canary %s
' "${STRIKE_RUN_ID}" >> "${STRIKE_PIPELINE_FILE}"
git add "${STRIKE_PIPELINE_FILE}"
git commit -m "STRIKE BAS: security stage bypass ${STRIKE_RUN_ID}"
git push origin HEAD
```

**Resultado esperado:**

Policy o revisión detecta la omisión.

**Señales de detección:**

Pipeline diff, job de seguridad skipped y branch actor.

### 36. Eliminar artefacto de auditoría canary

**MITRE:** T1070.008

Eliminar únicamente un artifact/log sintético generado por el laboratorio.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
test -f "${STRIKE_AUDIT_ARTIFACT}"
mkdir -p "${STRIKE_STATE_DIR}/audit-backup"
cp -a "${STRIKE_AUDIT_ARTIFACT}" "${STRIKE_STATE_DIR}/audit-backup/original"
rm -f "${STRIKE_AUDIT_ARTIFACT}"
```

**Resultado esperado:**

La retención o permisos lo bloquean o el evento queda auditado.

**Señales de detección:**

Artifact deletion y reducción de evidencia.

### 37. Agregar deploy key canary

**MITRE:** T1098.001

Agregar una clave pública sintética a un repositorio BAS y eliminarla después.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api --method POST "repos/${STRIKE_REPOSITORY}/keys" -f title="strike-bas-${STRIKE_RUN_ID}" -f key="${STRIKE_CANARY_PUBLIC_KEY}" -F read_only=true | tee "${STRIKE_STATE_DIR}/deploy-key.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/deploy_keys" -f title="strike-bas-${STRIKE_RUN_ID}" -f key="${STRIKE_CANARY_PUBLIC_KEY}" -F can_push=false | tee "${STRIKE_STATE_DIR}/deploy-key.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    echo "Jenkins no administra deploy keys SCM de forma nativa" >&2; exit 90
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

La clave se crea o una política lo bloquea.

**Señales de detección:**

Audit create deploy key y primer uso.

### 38. Crear webhook canary

**MITRE:** T1136

Crear un webhook hacia un receptor local/canary y eliminarlo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    gh api --method POST "repos/${STRIKE_REPOSITORY}/hooks" -f name=web -F active=false -f "config[url]=${STRIKE_CANARY_WEBHOOK_URL}" -f "events[]=push" | tee "${STRIKE_STATE_DIR}/webhook.json"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/hooks" -f url="${STRIKE_CANARY_WEBHOOK_URL}" -F push_events=true -F enable_ssl_verification=true | tee "${STRIKE_STATE_DIR}/webhook.json"
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    echo "Requiere plugin de webhook específico del job Jenkins" >&2; exit 90
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

El webhook se registra o permisos lo bloquean.

**Señales de detección:**

Webhook creation, URL, events y actor.

### 39. Crear variable CI/CD canary

**MITRE:** T1098.001

Crear una variable sintética protegida y eliminarla después.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
case "${STRIKE_CICD_PLATFORM}" in
  github)
    : "${GITHUB_TOKEN:?GITHUB_TOKEN requerido}"
    printf %s "${STRIKE_VARIABLE_VALUE}" | gh secret set "${STRIKE_VARIABLE_NAME}" --repo "${STRIKE_REPOSITORY}"
    ;;
  gitlab)
    : "${GITLAB_TOKEN:?GITLAB_TOKEN requerido}"
    glab api --method POST "projects/${STRIKE_PROJECT_ID}/variables" -f key="${STRIKE_VARIABLE_NAME}" -f value="${STRIKE_VARIABLE_VALUE}" -F protected=true -F masked=false
    ;;
  jenkins)
    : "${JENKINS_URL:?JENKINS_URL requerido}" "${JENKINS_USER:?JENKINS_USER requerido}" "${JENKINS_API_TOKEN:?JENKINS_API_TOKEN requerido}"
    echo "Requiere Credentials Binding/API plugin para Jenkins" >&2; exit 90
    ;;
  *) echo "STRIKE_CICD_PLATFORM no soportada: ${STRIKE_CICD_PLATFORM}" >&2; exit 90 ;;
esac
```

**Resultado esperado:**

La variable aparece como metadata y queda auditada.

**Señales de detección:**

Variable/secret creation por identidad no habitual.

### 40. Consumir CPU controlada en runner

**MITRE:** T1496

Ejecutar una carga de CPU limitada durante veinte segundos en el runner BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-cicd-state}"
mkdir -p "${STRIKE_STATE_DIR}"
timeout 20 sh -c "while true; do :; done" || true
```

**Resultado esperado:**

El job respeta límites o genera alerta de consumo.

**Señales de detección:**

CPU spike, proceso shell y job actor.

---
_Exportado desde STRIKE — `ci-cd-supply-chain-compromise-to-production`_
