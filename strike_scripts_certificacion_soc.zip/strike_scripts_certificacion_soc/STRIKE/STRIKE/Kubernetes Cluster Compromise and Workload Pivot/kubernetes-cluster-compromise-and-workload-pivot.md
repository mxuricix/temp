# Kubernetes Cluster Compromise and Workload Pivot

| | |
|---|---|
| **Status** | draft |
| **Severity** | critical |
| **Target environment** | Kubernetes upstream, EKS, AKS, GKE u OpenShift con audit logs y namespace BAS aislado |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078 — Valid Accounts |
| **Tags** | `kubernetes` · `containers` · `atomic-tests` · `rbac` · `secrets` · `pod-exec` · `persistence` · `escape-to-host` · `workload-identity` · `attack-flow` · `helm` · `rollback` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T21:05:32.749Z |
| **Actualizado** | 2026-07-20T21:05:32.749Z |

## Descripción

Escenario BAS canónico y agnóstico de distribución para validar compromiso de identidad Kubernetes, descubrimiento de recursos y RBAC, acceso a Secrets, ejecución remota, persistencia, elevación mediante bindings y workloads de alto riesgo, evasión de controles e impacto canary. Cada step es un procedimiento atómico independiente y reversible.

## Steps

### 1. Validar identidad Kubernetes

**MITRE:** T1078

Validar el kubeconfig o token BAS y obtener la identidad efectiva autorizada por el API server.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl auth whoami -o json | tee "${STRIKE_STATE_DIR}/k8s-auth-whoami.json"
```

**Resultado esperado:**

El API responde y se obtiene la identidad o grupos asociados.

**Señales de detección:**

Kubernetes audit: SelfSubjectReview/SelfSubjectAccessReview, usuario, grupos, source IP y user agent.

### 2. Enumerar namespaces

**MITRE:** T1613

Enumerar namespaces visibles para la identidad comprometida.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl get namespaces -o json | tee "${STRIKE_STATE_DIR}/k8s-list-namespaces.json"
```

**Resultado esperado:**

Se obtiene la lista o una denegación explícita.

**Señales de detección:**

Audit events list namespaces; identidad no habitual y enumeración temprana.

### 3. Enumerar pods

**MITRE:** T1613

Enumerar pods del namespace BAS para identificar workloads y service accounts.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get pods -o json | tee "${STRIKE_STATE_DIR}/k8s-list-pods.json"
```

**Resultado esperado:**

Se obtiene el inventario de pods visibles.

**Señales de detección:**

Audit list pods; volumen y namespace consultado.

### 4. Enumerar nodos

**MITRE:** T1613

Enumerar nodos y metadatos del clúster.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl get nodes -o json | tee "${STRIKE_STATE_DIR}/k8s-list-nodes.json"
```

**Resultado esperado:**

Se obtiene la lista o RBAC bloquea la consulta.

**Señales de detección:**

Audit list nodes por identidad no administrativa.

### 5. Enumerar deployments

**MITRE:** T1613

Enumerar deployments del namespace BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get deployments -o json | tee "${STRIKE_STATE_DIR}/k8s-list-deployments.json"
```

**Resultado esperado:**

Se identifican workloads gestionados.

**Señales de detección:**

Audit list deployments y correlación con consultas de pods.

### 6. Enumerar servicios internos

**MITRE:** T1613

Enumerar Services para descubrir endpoints internos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get services -o json | tee "${STRIKE_STATE_DIR}/k8s-list-services.json"
```

**Resultado esperado:**

Se obtiene la lista de servicios del namespace.

**Señales de detección:**

Audit list services y posterior acceso de red.

### 7. Enumerar NetworkPolicies

**MITRE:** T1613

Enumerar controles de segmentación visibles.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get networkpolicies -o json | tee "${STRIKE_STATE_DIR}/k8s-list-networkpolicies.json"
```

**Resultado esperado:**

Se obtienen políticas o una denegación.

**Señales de detección:**

Audit list networkpolicies antes de movimiento lateral.

### 8. Enumerar ClusterRoles

**MITRE:** T1613

Enumerar roles de clúster para identificar privilegios reutilizables.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl get clusterroles -o json | tee "${STRIKE_STATE_DIR}/k8s-list-clusterroles.json"
```

**Resultado esperado:**

Se obtiene la lista o RBAC la bloquea.

**Señales de detección:**

Audit list clusterroles y clusterrolebindings.

### 9. Enumerar RoleBindings

**MITRE:** T1613

Enumerar bindings del namespace BAS.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get rolebindings -o json | tee "${STRIKE_STATE_DIR}/k8s-list-rolebindings.json"
```

**Resultado esperado:**

Se obtienen bindings y subjects.

**Señales de detección:**

Audit list rolebindings y búsqueda de service accounts privilegiadas.

### 10. Comprobar permiso de lectura de Secrets

**MITRE:** T1613

Usar SelfSubjectAccessReview mediante kubectl auth can-i para saber si la identidad puede leer Secrets.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl auth can-i get secrets -n "${STRIKE_K8S_NAMESPACE}" | tee "${STRIKE_STATE_DIR}/k8s-can-i-get-secrets.txt"
```

**Resultado esperado:**

La salida devuelve yes o no sin cambiar recursos.

**Señales de detección:**

Audit SelfSubjectAccessReview con verb get sobre secrets.

### 11. Enumerar metadatos de Secrets

**MITRE:** T1552.007

Enumerar nombres y metadatos de Secrets sin imprimir valores.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get secrets -o json | jq "{items:[.items[]|{metadata:{name:.metadata.name,namespace:.metadata.namespace},type:.type}]}" | tee "${STRIKE_STATE_DIR}/k8s-list-secret-metadata.json"
```

**Resultado esperado:**

Se obtiene la lista o la acción es bloqueada.

**Señales de detección:**

Audit list secrets y correlación con get posterior.

### 12. Leer Secret canary

**MITRE:** T1552.007

Leer exclusivamente el Secret sintético creado por el laboratorio y guardar solo un hash del valor.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get secret strike-bas-secret -o jsonpath="{.data.token}" | base64 -d | sha256sum | tee "${STRIKE_STATE_DIR}/k8s-get-canary-secret.sha256"
```

**Resultado esperado:**

Se obtiene un hash reproducible o RBAC bloquea la lectura.

**Señales de detección:**

Audit get secret strike-bas-secret; identidad, namespace y user agent.

### 13. Leer token montado de ServiceAccount

**MITRE:** T1552.001

Ejecutar una lectura controlada del token proyectado dentro del pod BAS y guardar únicamente su hash.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
POD=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" get pod -l app=strike-bas-app -o jsonpath="{.items[0].metadata.name}")
kubectl -n "${STRIKE_K8S_NAMESPACE}" exec "$POD" -- sh -c "sha256sum /var/run/secrets/kubernetes.io/serviceaccount/token" | tee "${STRIKE_STATE_DIR}/k8s-read-mounted-serviceaccount-token.txt"
```

**Resultado esperado:**

Se obtiene un hash sin exponer el token.

**Señales de detección:**

Audit pods/exec y lectura de ruta de service account; runtime process telemetry.

### 14. Reutilizar token de ServiceAccount

**MITRE:** T1550.001

Crear un token efímero para la service account BAS y usarlo en una llamada aislada al API server.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
TOKEN=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" create token strike-bas-low --duration=10m)
SERVER=$(kubectl config view --minify -o jsonpath="{.clusters[0].cluster.server}")
CA=$(mktemp)
kubectl config view --raw --minify -o jsonpath="{.clusters[0].cluster.certificate-authority-data}" | base64 -d > "$CA"
kubectl --server="$SERVER" --certificate-authority="$CA" --token="$TOKEN" -n "${STRIKE_K8S_NAMESPACE}" get pods -o name | tee "${STRIKE_STATE_DIR}/k8s-reuse-serviceaccount-token.txt"
rm -f "$CA"
```

**Resultado esperado:**

El token permite o bloquea una consulta según RBAC.

**Señales de detección:**

TokenRequest, nueva autenticación bearer y llamada list pods con user agent alternativo.

### 15. Ejecutar comando dentro de un pod

**MITRE:** T1609

Usar pods/exec para ejecutar id y uname dentro del pod canary.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
POD=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" get pod -l app=strike-bas-app -o jsonpath="{.items[0].metadata.name}")
kubectl -n "${STRIKE_K8S_NAMESPACE}" exec "$POD" -- sh -c "id; uname -a" | tee "${STRIKE_STATE_DIR}/k8s-pod-exec.txt"
```

**Resultado esperado:**

El comando se ejecuta o RBAC/admission lo bloquea.

**Señales de detección:**

Audit create pods/exec; kubelet/runtime exec y procesos shell.

### 16. Crear Job de ejecución canary

**MITRE:** T1610

Crear un Job efímero que escribe una marca sintética y finaliza.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" create job strike-bas-job --image=busybox:1.36 -- sh -c "echo strike-bas-job; sleep 2"
kubectl -n "${STRIKE_K8S_NAMESPACE}" wait --for=condition=complete job/strike-bas-job --timeout=90s
```

**Resultado esperado:**

El Job completa o un control lo bloquea.

**Señales de detección:**

Audit create jobs/pods; imagen, service account y command.

### 17. Desplegar pod efímero

**MITRE:** T1610

Crear un pod canary con etiqueta STRIKE-BAS y sin privilegios.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" run strike-bas-ephemeral --image=busybox:1.36 --labels=strike-bas=true --restart=Never -- sleep 300
kubectl -n "${STRIKE_K8S_NAMESPACE}" wait --for=condition=Ready pod/strike-bas-ephemeral --timeout=90s
```

**Resultado esperado:**

El pod alcanza Running o es bloqueado por política.

**Señales de detección:**

Audit create pod; imagen, tag mutable, service account y namespace.

### 18. Crear CronJob de persistencia canary

**MITRE:** T1053.007

Crear un CronJob etiquetado que ejecuta una marca sintética cada quince minutos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" create cronjob strike-bas-cron --image=busybox:1.36 --schedule="*/15 * * * *" -- sh -c "echo strike-bas-cron"
kubectl -n "${STRIKE_K8S_NAMESPACE}" label cronjob strike-bas-cron strike-bas=true --overwrite
```

**Resultado esperado:**

El recurso se crea o es bloqueado.

**Señales de detección:**

Audit create cronjobs; schedule, image y principal no habitual.

### 19. Crear ServiceAccount adicional

**MITRE:** T1136

Crear una service account canary sin permisos adicionales.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" create serviceaccount strike-bas-backdoor
kubectl -n "${STRIKE_K8S_NAMESPACE}" label serviceaccount strike-bas-backdoor strike-bas=true --overwrite
```

**Resultado esperado:**

La cuenta se crea y queda etiquetada.

**Señales de detección:**

Audit create serviceaccounts fuera de automatización habitual.

### 20. Agregar RoleBinding elevado

**MITRE:** T1098.006

Vincular temporalmente la service account backdoor al ClusterRole canary strike-bas-elevated dentro del namespace.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" create rolebinding strike-bas-backdoor-binding --clusterrole=strike-bas-elevated --serviceaccount="${STRIKE_K8S_NAMESPACE}":strike-bas-backdoor
```

**Resultado esperado:**

El binding se crea o RBAC lo bloquea.

**Señales de detección:**

Audit create rolebinding con referencia a rol elevado y service account nueva.

### 21. Agregar ClusterRoleBinding canary

**MITRE:** T1098.006

Crear un ClusterRoleBinding temporal hacia un ClusterRole BAS de lectura limitada.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl create clusterrolebinding strike-bas-cluster-binding --clusterrole=strike-bas-cluster-reader --serviceaccount="${STRIKE_K8S_NAMESPACE}":strike-bas-backdoor
```

**Resultado esperado:**

El binding se crea o un guardrail lo bloquea.

**Señales de detección:**

Audit create clusterrolebinding y subject de namespace BAS.

### 22. Desplegar DaemonSet canary

**MITRE:** T1543.005

Crear un DaemonSet no privilegiado que ejecuta una marca sintética por nodo y se elimina después.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
cat <<'YAML' | sed "s/__NS__/${STRIKE_K8S_NAMESPACE}/g" | kubectl apply -f -
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: strike-bas-daemon
  namespace: __NS__
  labels: {strike-bas: "true"}
spec:
  selector: {matchLabels: {app: strike-bas-daemon}}
  template:
    metadata: {labels: {app: strike-bas-daemon, strike-bas: "true"}}
    spec:
      containers:
      - name: marker
        image: busybox:1.36
        command: ["sh","-c","echo strike-bas-daemon; sleep 300"]
YAML
```

**Resultado esperado:**

Se programa en nodos permitidos o queda bloqueado.

**Señales de detección:**

Audit create daemonsets y creación de pods en múltiples nodos.

### 23. Intentar pod privilegiado

**MITRE:** T1611

Crear un pod privilegiado únicamente en el namespace BAS para validar Pod Security Admission y admission policies.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
test "${STRIKE_ALLOW_PRIVILEGED_TESTS}" = "true" || exit 90
cat <<'YAML' | sed "s/__NS__/${STRIKE_K8S_NAMESPACE}/g" | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: strike-bas-privileged
  namespace: __NS__
  labels: {strike-bas: "true"}
spec:
  restartPolicy: Never
  containers:
  - name: test
    image: busybox:1.36
    command: ["sh","-c","id; sleep 30"]
    securityContext: {privileged: true}
YAML
```

**Resultado esperado:**

El control debe bloquearlo o el pod se crea y se elimina inmediatamente.

**Señales de detección:**

Audit create pod con privileged=true, host namespaces y capabilities.

### 24. Intentar montaje hostPath

**MITRE:** T1611

Crear un pod canary que intenta montar solo /etc/hostname del nodo como readOnly.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
test "${STRIKE_ALLOW_HOSTPATH_TESTS}" = "true" || exit 90
cat <<'YAML' | sed "s/__NS__/${STRIKE_K8S_NAMESPACE}/g" | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: strike-bas-hostpath
  namespace: __NS__
  labels: {strike-bas: "true"}
spec:
  restartPolicy: Never
  containers:
  - name: test
    image: busybox:1.36
    command: ["sh","-c","sha256sum /host/hostname; sleep 20"]
    volumeMounts: [{name: host, mountPath: /host/hostname, readOnly: true}]
  volumes: [{name: host, hostPath: {path: /etc/hostname, type: File}}]
YAML
```

**Resultado esperado:**

Pod Security o admission debería bloquearlo; si se crea, solo lee un hash y se elimina.

**Señales de detección:**

Audit pod con hostPath y mount readOnly.

### 25. Intentar pod con hostNetwork

**MITRE:** T1611

Crear un pod con hostNetwork únicamente para validar controles de admisión.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
test "${STRIKE_ALLOW_HOSTNETWORK_TESTS}" = "true" || exit 90
cat <<'YAML' | sed "s/__NS__/${STRIKE_K8S_NAMESPACE}/g" | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: strike-bas-hostnetwork
  namespace: __NS__
  labels: {strike-bas: "true"}
spec:
  hostNetwork: true
  restartPolicy: Never
  containers:
  - name: test
    image: busybox:1.36
    command: ["sh","-c","ip addr; sleep 20"]
YAML
```

**Resultado esperado:**

La creación es bloqueada o se elimina tras verificar el atributo.

**Señales de detección:**

Audit pod spec hostNetwork=true.

### 26. Acceder a servicio interno canary

**MITRE:** T1046

Desde el pod BAS, resolver y consultar el servicio interno strike-bas-internal.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
POD=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" get pod -l app=strike-bas-app -o jsonpath="{.items[0].metadata.name}")
kubectl -n "${STRIKE_K8S_NAMESPACE}" exec "$POD" -- wget -qO- --timeout=5 http://strike-bas-internal | tee "${STRIKE_STATE_DIR}/k8s-access-internal-service.txt"
```

**Resultado esperado:**

Se obtiene una respuesta sintética o NetworkPolicy bloquea la conexión.

**Señales de detección:**

DNS/service access, flow logs/CNI telemetry y pods/exec.

### 27. Intentar acceso a metadata cloud

**MITRE:** T1552.005

Desde el pod BAS, intentar una solicitud con timeout corto a la dirección link-local de metadata sin recuperar credenciales.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
POD=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" get pod -l app=strike-bas-app -o jsonpath="{.items[0].metadata.name}")
kubectl -n "${STRIKE_K8S_NAMESPACE}" exec "$POD" -- sh -c "wget -S -O /dev/null -T 2 http://169.254.169.254/ 2>&1 | head -20" | tee "${STRIKE_STATE_DIR}/k8s-attempt-cloud-metadata.txt"
```

**Resultado esperado:**

La red bloquea la solicitud o responde con un código controlado.

**Señales de detección:**

Network flow hacia 169.254.169.254 desde pod; runtime wget/curl.

### 28. Eliminar NetworkPolicy canary

Respaldar y eliminar temporalmente solo la NetworkPolicy etiquetada strike-bas=true; restaurarla después.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get networkpolicy strike-bas-deny-egress -o yaml > "${STRIKE_STATE_DIR}/strike-bas-deny-egress.yaml"
kubectl -n "${STRIKE_K8S_NAMESPACE}" delete networkpolicy strike-bas-deny-egress
```

**Resultado esperado:**

La política desaparece temporalmente o RBAC la bloquea.

**Señales de detección:**

Audit delete networkpolicy y cambio de conectividad.

### 29. Relajar etiqueta Pod Security

Cambiar temporalmente la etiqueta enforce del namespace BAS de restricted a privileged y restaurarla.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
OLD=$(kubectl get ns "${STRIKE_K8S_NAMESPACE}" -o jsonpath="{.metadata.labels.pod-security\.kubernetes\.io/enforce}")
printf "%s" "$OLD" > "${STRIKE_STATE_DIR}/pod-security-old.txt"
kubectl label ns "${STRIKE_K8S_NAMESPACE}" pod-security.kubernetes.io/enforce=privileged --overwrite
```

**Resultado esperado:**

La etiqueta cambia o un admission/authorization control lo bloquea.

**Señales de detección:**

Audit patch namespace sobre pod-security.kubernetes.io/enforce.

### 30. Modificar comando de Deployment

**MITRE:** T1609

Respaldar y modificar temporalmente el comando del contenedor canary para escribir una marca, luego restaurar.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get deployment strike-bas-app -o yaml > "${STRIKE_STATE_DIR}/strike-bas-app-original.yaml"
kubectl -n "${STRIKE_K8S_NAMESPACE}" patch deployment strike-bas-app --type=strategic -p="{"spec":{"template":{"spec":{"containers":[{"name":"app","command":["sh","-c","echo strike-bas-patched; sleep 3600"]}]}}}}"
kubectl -n "${STRIKE_K8S_NAMESPACE}" rollout status deployment/strike-bas-app --timeout=90s
```

**Resultado esperado:**

El rollout completa o admission/RBAC lo bloquea.

**Señales de detección:**

Audit patch deployment; rollout y nuevos pods.

### 31. Eliminar sidecar de seguridad canary

Respaldar el Deployment y eliminar temporalmente el sidecar marker llamado security-sidecar.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get deployment strike-bas-app -o yaml > "${STRIKE_STATE_DIR}/strike-bas-app-sidecar-original.yaml"
kubectl -n "${STRIKE_K8S_NAMESPACE}" patch deployment strike-bas-app --type=json -p="[{"op":"remove","path":"/spec/template/spec/containers/1"}]"
kubectl -n "${STRIKE_K8S_NAMESPACE}" rollout status deployment/strike-bas-app --timeout=90s
```

**Resultado esperado:**

El rollout completa o el cambio es bloqueado; el sidecar se restaura.

**Señales de detección:**

Audit patch deployment eliminando un contenedor de seguridad.

### 32. Recolectar ConfigMap canary

**MITRE:** T1613

Leer un ConfigMap sintético que representa configuración sensible no secreta.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
kubectl -n "${STRIKE_K8S_NAMESPACE}" get configmap strike-bas-config -o json | tee "${STRIKE_STATE_DIR}/k8s-get-canary-configmap.json"
```

**Resultado esperado:**

Se obtiene el valor canary o RBAC bloquea la acción.

**Señales de detección:**

Audit get configmap y acceso inusual a configuración de aplicación.

### 33. Eliminar pod canary

**MITRE:** T1485

Eliminar un pod gestionado para validar resiliencia y recreación automática del Deployment.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
POD=$(kubectl -n "${STRIKE_K8S_NAMESPACE}" get pod -l app=strike-bas-app -o jsonpath="{.items[0].metadata.name}")
kubectl -n "${STRIKE_K8S_NAMESPACE}" delete pod "$POD" --wait=true
kubectl -n "${STRIKE_K8S_NAMESPACE}" rollout status deployment/strike-bas-app --timeout=90s
```

**Resultado esperado:**

El pod es eliminado y el Deployment crea un reemplazo.

**Señales de detección:**

Audit delete pod, ReplicaSet replacement y alertas de disponibilidad.

### 34. Ejecutar consumo controlado de CPU

**MITRE:** T1496

Crear un Job de CPU limitado durante 20 segundos con requests/limits bajos.

```bash
set -euo pipefail
STRIKE_STATE_DIR="${STRIKE_STATE_DIR:-/tmp/strike-k8s-state}"
mkdir -p "${STRIKE_STATE_DIR}"
command -v kubectl >/dev/null 2>&1 || { echo "kubectl no está instalado" >&2; exit 90; }
cat <<'YAML' | sed "s/__NS__/${STRIKE_K8S_NAMESPACE}/g" | kubectl apply -f -
apiVersion: batch/v1
kind: Job
metadata:
  name: strike-bas-cpu
  namespace: __NS__
  labels: {strike-bas: "true"}
spec:
  template:
    spec:
      restartPolicy: Never
      containers:
      - name: cpu
        image: busybox:1.36
        command: ["sh","-c","timeout 20 sh -c 'while true; do :; done' || true"]
        resources:
          requests: {cpu: "25m", memory: "16Mi"}
          limits: {cpu: "100m", memory: "32Mi"}
YAML
kubectl -n "${STRIKE_K8S_NAMESPACE}" wait --for=condition=complete job/strike-bas-cpu --timeout=90s
```

**Resultado esperado:**

El Job finaliza dentro del límite o políticas lo bloquean.

**Señales de detección:**

Audit create job, métricas de CPU y quota/admission events.

---
_Exportado desde STRIKE — `kubernetes-cluster-compromise-and-workload-pivot`_
