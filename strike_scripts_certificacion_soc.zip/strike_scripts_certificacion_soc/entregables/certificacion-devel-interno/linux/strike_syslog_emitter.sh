#!/usr/bin/env bash
#
# strike_syslog_emitter.sh
# -------------------------------------------------------------------------
# Emisor de certificacion SOC para la metodologia STRIKE.
#
# Envia al receptor de syslog del SIEM una RAFAGA de eventos sinteticos,
# uno por cada paso del catalogo STRIKE (strike_catalog.json). Cada evento
# es un registro syslog valido (RFC3164 por defecto, RFC5424 opcional) que
# EMULA ser un endpoint llamado EP_CERTIFICATION e incluye en el mensaje:
#
#     STRIKE_CERT id=<escenario.paso> mitre=<Txxxx> platform=<...>
#                 scenario="<nombre>" step="<titulo>" cmd="<comando>"
#
# Objetivo: certificar que el SIEM tiene bien configuradas las reglas de
# deteccion de TODOS los comandos de STRIKE. Luego se revisa en el SIEM
# que IDs llegaron y que alertas se dispararon, cruzando contra el
# manifiesto que este script escribe (--manifest).
#
# IMPORTANTE: este script NO ejecuta ninguno de los comandos ofensivos.
# Solo construye texto de log y lo envia por el socket. Es seguro correrlo
# en un endpoint de certificacion.
#
# Dependencias: bash (redireccion /dev/udp) o nc; python3 O jq para leer
# el JSON. Sin dependencias exoticas.
#
# Autor: Devel Security - Certificacion SOC / STRIKE
# -------------------------------------------------------------------------

set -u

# ---------------------------- valores por defecto -------------------------
SERVER=""
PORT="514"
PROTO="udp"                 # udp | tcp
HOSTNAME_TAG="EP_CERTIFICATION"
APP_TAG="STRIKE_CERT"
FORMAT="rfc3164"            # rfc3164 | rfc5424
FACILITY="16"               # local0
SEVERITY="5"                # notice
DELAY_MS="20"               # pausa entre datagramas (evita perdida UDP)
CATALOG=""
FILTER_SCENARIO=""
FILTER_PLATFORM=""
MANIFEST=""
DRY_RUN="0"
NO_MARKERS="0"
RUN_ID=""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

usage() {
    cat <<'EOF'
Uso: strike_syslog_emitter.sh -s <IP_SIEM> [opciones]

Obligatorio:
  -s, --server IP        IP/host del receptor syslog del SIEM

Conexion:
  -p, --port N           Puerto destino (default 514)
      --proto udp|tcp    Protocolo (default udp)

Identidad del evento:
  -H, --hostname NAME    Hostname que se emula (default EP_CERTIFICATION)
  -t, --tag TAG          Tag/APP-NAME del syslog (default STRIKE_CERT)
      --format FMT       rfc3164 | rfc5424 (default rfc3164)
      --facility N       Facility syslog 0-23 (default 16 = local0)
      --severity N       Severity syslog 0-7 (default 5 = notice)

Catalogo y filtros:
      --catalog PATH     Ruta a strike_catalog.json (autodetecta si se omite)
      --scenario N       Enviar solo el escenario N (1..13). Repetible con comas: 1,2,7
      --platform P       Enviar solo una plataforma: windows|linux|aws|azure|
                         cicd|hybrid-ad|kubernetes|entra-m365

Ejecucion:
      --delay-ms N       Pausa entre eventos en ms (default 20)
      --manifest PATH    Escribe CSV con lo enviado (timestamp,id,mitre,platform,title)
      --no-markers       No enviar eventos RUN_START / RUN_END
      --dry-run          No envia nada: imprime los mensajes a stdout
  -h, --help             Esta ayuda

Ejemplos:
  ./strike_syslog_emitter.sh -s 10.0.0.50
  ./strike_syslog_emitter.sh -s 10.0.0.50 -p 1514 --proto tcp --format rfc5424
  ./strike_syslog_emitter.sh -s 10.0.0.50 --scenario 1,2,3 --manifest run.csv
  ./strike_syslog_emitter.sh -s 10.0.0.50 --platform windows --dry-run
EOF
}

log()  { printf '%s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# ------------------------------ parseo de args ----------------------------
while [ $# -gt 0 ]; do
    case "$1" in
        -s|--server)   SERVER="$2"; shift 2;;
        -p|--port)     PORT="$2"; shift 2;;
        --proto)       PROTO="$2"; shift 2;;
        -H|--hostname) HOSTNAME_TAG="$2"; shift 2;;
        -t|--tag)      APP_TAG="$2"; shift 2;;
        --format)      FORMAT="$2"; shift 2;;
        --facility)    FACILITY="$2"; shift 2;;
        --severity)    SEVERITY="$2"; shift 2;;
        --catalog)     CATALOG="$2"; shift 2;;
        --scenario)    FILTER_SCENARIO="$2"; shift 2;;
        --platform)    FILTER_PLATFORM="$2"; shift 2;;
        --delay-ms)    DELAY_MS="$2"; shift 2;;
        --manifest)    MANIFEST="$2"; shift 2;;
        --no-markers)  NO_MARKERS="1"; shift;;
        --dry-run)     DRY_RUN="1"; shift;;
        -h|--help)     usage; exit 0;;
        *) die "argumento desconocido: $1 (usa --help)";;
    esac
done

[ "$DRY_RUN" = "1" ] || [ -n "$SERVER" ] || die "falta -s/--server (o usa --dry-run)"
case "$PROTO" in udp|tcp) ;; *) die "--proto debe ser udp o tcp";; esac
case "$FORMAT" in rfc3164|rfc5424) ;; *) die "--format debe ser rfc3164 o rfc5424";; esac

# ------------------------- localizar el catalogo --------------------------
if [ -z "$CATALOG" ]; then
    for cand in \
        "$SCRIPT_DIR/strike_catalog.json" \
        "$SCRIPT_DIR/../catalog/strike_catalog.json" \
        "./strike_catalog.json" \
        "./catalog/strike_catalog.json"; do
        if [ -f "$cand" ]; then CATALOG="$cand"; break; fi
    done
fi
[ -n "$CATALOG" ] && [ -f "$CATALOG" ] || die "no encuentro strike_catalog.json (usa --catalog)"

# ---------------------- extraer filas del catalogo ------------------------
# Produce TSV: strike_id \t scenario_id \t platform \t mitre \t scenario_name \t title \t summary_cmd
# Preferimos python3 (mas portable que jq); si no, jq.
extract_rows() {
    if command -v python3 >/dev/null 2>&1; then
        python3 - "$CATALOG" "$FILTER_SCENARIO" "$FILTER_PLATFORM" <<'PY'
import json, sys
cat_path, f_scn, f_plat = sys.argv[1], sys.argv[2], sys.argv[3]
scns = set(x.strip() for x in f_scn.split(",") if x.strip()) if f_scn else None
plat = f_plat.strip() if f_plat else None
data = json.load(open(cat_path, encoding="utf-8"))
def clean(s):
    return (s or "").replace("\t", " ").replace("\r", " ").replace("\n", " ")
for st in data["steps"]:
    if scns is not None and str(st["scenario_id"]) not in scns:
        continue
    if plat is not None and st["platform"] != plat:
        continue
    cmd = st.get("summary_cmd") or st.get("command") or st["title"]
    row = [st["strike_id"], str(st["scenario_id"]), st["platform"], st["mitre"],
           st["scenario_name"], st["title"], cmd]
    print("\t".join(clean(c) for c in row))
PY
    elif command -v jq >/dev/null 2>&1; then
        jq -r --arg scn "$FILTER_SCENARIO" --arg plat "$FILTER_PLATFORM" '
          .steps[]
          | select($scn=="" or ([$scn|split(",")[]] | index(.scenario_id|tostring)))
          | select($plat=="" or .platform==$plat)
          | [ .strike_id, (.scenario_id|tostring), .platform, .mitre,
              .scenario_name, .title,
              (.summary_cmd // .command // .title) ]
          | map(gsub("[\t\r\n]";" "))
          | @tsv
        ' "$CATALOG"
    else
        die "necesito python3 o jq para leer el JSON"
    fi
}

# ------------------------------ transporte --------------------------------
# Abre un unico socket persistente cuando es posible (TCP), o envia datagramas
# sueltos (UDP). Usa /dev/udp|/dev/tcp de bash; si falla, intenta nc.
SOCK_FD=""
USE_NC="0"
NC_BIN=""

open_transport() {
    [ "$DRY_RUN" = "1" ] && return 0
    if ( exec 3<>"/dev/$PROTO/$SERVER/$PORT" ) 2>/dev/null; then
        exec 3<>"/dev/$PROTO/$SERVER/$PORT" || die "no pude abrir /dev/$PROTO/$SERVER/$PORT"
        SOCK_FD="3"
        return 0
    fi
    # fallback a nc
    for b in nc ncat netcat; do
        if command -v "$b" >/dev/null 2>&1; then NC_BIN="$b"; USE_NC="1"; return 0; fi
    done
    die "sin /dev/$PROTO disponible y sin nc/ncat. Instala netcat o usa bash con net-redirections."
}

close_transport() {
    [ -n "$SOCK_FD" ] && exec 3>&- 2>/dev/null
    SOCK_FD=""
}

send_raw() {
    # $1 = linea de syslog ya formada (sin salto final)
    local msg="$1"
    if [ "$DRY_RUN" = "1" ]; then
        printf '%s\n' "$msg"
        return 0
    fi
    if [ -n "$SOCK_FD" ]; then
        printf '%s\n' "$msg" >&3
    elif [ "$USE_NC" = "1" ]; then
        if [ "$PROTO" = "udp" ]; then
            printf '%s\n' "$msg" | "$NC_BIN" -u -w1 "$SERVER" "$PORT" 2>/dev/null
        else
            printf '%s\n' "$msg" | "$NC_BIN" -w1 "$SERVER" "$PORT" 2>/dev/null
        fi
    fi
}

# --------------------------- formato de syslog ----------------------------
pri() { echo $(( FACILITY * 8 + SEVERITY )); }

ts_rfc3164() {
    # "Mmm dd HH:MM:SS" con dia con espacio de relleno (no cero)
    local d; d=$(date "+%e")
    date "+%b $d %H:%M:%S" | sed 's/  / /'
    # (mantener dos espacios tras el mes es valido en RFC3164; lo dejamos natural)
}

ts_rfc5424() { date -u "+%Y-%m-%dT%H:%M:%S.%6NZ" 2>/dev/null || date -u "+%Y-%m-%dT%H:%M:%SZ"; }

# Construye el cuerpo estructurado comun del mensaje.
build_body() {
    # args: id mitre platform scenario title cmd
    local id="$1" mitre="$2" platform="$3" scenario="$4" title="$5" cmd="$6"
    printf 'id=%s mitre=%s platform=%s scenario="%s" step="%s" cmd="%s"' \
        "$id" "$mitre" "$platform" "$scenario" "$title" "$cmd"
}

emit() {
    # args: id mitre platform scenario title cmd
    local id="$1" mitre="$2" platform="$3" scenario="$4" title="$5" cmd="$6"
    local body line
    body="$(build_body "$id" "$mitre" "$platform" "$scenario" "$title" "$cmd")"
    if [ "$FORMAT" = "rfc5424" ]; then
        # <PRI>1 TIMESTAMP HOST APP PROCID MSGID [SD] MSG
        local sd
        sd=$(printf '[strike@47111 run_id="%s" id="%s" mitre="%s" platform="%s"]' \
                "$RUN_ID" "$id" "$mitre" "$platform")
        # <PRI>1 TIMESTAMP HOST APP PROCID MSGID SD MSG   (MSGID = STRIKE_<id>)
        line=$(printf '<%s>1 %s %s %s %s %s %s %s' \
                "$(pri)" "$(ts_rfc5424)" "$HOSTNAME_TAG" "$APP_TAG" "$$" \
                "STRIKE_$id" "$sd" "$body")
    else
        # <PRI>TIMESTAMP HOST TAG: MSG
        line=$(printf '<%s>%s %s %s[%s]: %s run_id=%s %s' \
                "$(pri)" "$(ts_rfc3164)" "$HOSTNAME_TAG" "$APP_TAG" "$$" \
                "$APP_TAG" "$RUN_ID" "$body")
    fi
    send_raw "$line"
}

emit_marker() {
    # args: kind  (RUN_START | RUN_END)  extra
    local kind="$1" extra="$2"
    emit "$kind" "N/A" "certification" "STRIKE-SOC-CERT" "$kind" "$extra"
}

# --------------------------------- run ------------------------------------
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"

# Leer todas las filas a un arreglo (para contar antes de enviar).
mapfile -t ROWS < <(extract_rows) || die "fallo leyendo el catalogo"
[ "${#ROWS[@]}" -gt 0 ] || die "el catalogo no devolvio pasos (revisa filtros --scenario/--platform)"

log "================ STRIKE SOC Certification - Emisor syslog ================"
log " Receptor     : ${SERVER:-(dry-run)}:$PORT/$PROTO     formato=$FORMAT"
log " Endpoint     : $HOSTNAME_TAG   tag=$APP_TAG   pri=$(pri)"
log " Catalogo     : $CATALOG"
log " Run ID       : $RUN_ID"
log " Eventos      : ${#ROWS[@]}  (filtro escenario='${FILTER_SCENARIO:-todos}' plataforma='${FILTER_PLATFORM:-todas}')"
[ "$DRY_RUN" = "1" ] && log " MODO         : DRY-RUN (no se envia nada)"
log "========================================================================="

open_transport

# Manifiesto (CSV) para reconciliar en el SIEM.
if [ -n "$MANIFEST" ]; then
    echo "sent_utc,run_id,strike_id,scenario_id,platform,mitre,title" > "$MANIFEST" \
        || die "no pude escribir manifiesto $MANIFEST"
fi

# delay en segundos para sleep (soporta decimales via awk)
DELAY_S=$(awk -v ms="$DELAY_MS" 'BEGIN{printf "%.3f", ms/1000}')

[ "$NO_MARKERS" = "1" ] || emit_marker "RUN_START" "total_eventos=${#ROWS[@]} catalogo=$(basename "$CATALOG")"

SENT=0
for row in "${ROWS[@]}"; do
    IFS=$'\t' read -r id scn platform mitre scenario title cmd <<< "$row"
    emit "$id" "$mitre" "$platform" "$scenario" "$title" "$cmd"
    SENT=$((SENT + 1))
    if [ -n "$MANIFEST" ]; then
        # CSV; el titulo va entre comillas con las comillas internas escapadas (RFC4180)
        mtitle=${title//\"/\"\"}
        printf '%s,%s,%s,%s,%s,%s,"%s"\n' \
            "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$RUN_ID" "$id" "$scn" "$platform" "$mitre" "$mtitle" >> "$MANIFEST"
    fi
    # progreso cada 25
    if [ $((SENT % 25)) -eq 0 ]; then log " ... enviados $SENT/${#ROWS[@]}"; fi
    [ "$DRY_RUN" = "1" ] || sleep "$DELAY_S" 2>/dev/null || true
done

[ "$NO_MARKERS" = "1" ] || emit_marker "RUN_END" "enviados=$SENT run_id=$RUN_ID"

close_transport

log "========================================================================="
log " Enviados: $SENT eventos como $HOSTNAME_TAG hacia ${SERVER:-(dry-run)}:$PORT/$PROTO"
[ -n "$MANIFEST" ] && log " Manifiesto: $MANIFEST"
log " Ahora en el SIEM filtra host=$HOSTNAME_TAG y/o tag=$APP_TAG, run_id=$RUN_ID"
log " y verifica que cada STRIKE id haya llegado y disparado su regla/alerta."
log "========================================================================="
