#Requires -Version 5.1
<#
.SYNOPSIS
    Invoke-StrikeTelemetryAudit.ps1 - Audita la POSTURA DE TELEMETRIA de un
    endpoint Windows frente a la metodologia STRIKE (certificacion SOC).

.DESCRIPTION
    Para cada paso (comando) de los escenarios Windows del catalogo STRIKE,
    este script determina QUE fuente de datos / evento se necesita para
    detectarlo y verifica si el host esta configurado para generarla:

      * Advanced Audit Policy (auditpol): Process Creation (4688),
        Account/Group Management (4720/4732...), Security System Extension
        (4697/7045), Other Object Access (4698 scheduled tasks),
        Registry (4657), Firewall policy change (4946-4948).
      * Inclusion de linea de comandos en 4688 (registro).
      * PowerShell Script Block (4104) y Module Logging.
      * Sysmon: instalado? servicio, driver y canal Operational.
      * Salud de los canales de evento (Security, System, PowerShell, Sysmon,
        BITS-Client): habilitados y tamano.

    NO ejecuta ninguno de los comandos ofensivos de STRIKE: solo lee el
    catalogo y consulta la configuracion local. Es de solo lectura.

    Resultado por cada ID STRIKE (ej. 1.1, 3.14):
        COVERED      el host puede generar toda la telemetria necesaria
        PARTIAL      genera lo basico pero falta enriquecimiento
        NOT_COVERED  falta la telemetria primaria (no se veria el comando)

    Exporta CSV y JSON para evidencia de la certificacion.

.PARAMETER CatalogPath
    Ruta a strike_catalog.json. Si se omite, se autodetecta junto al script
    o en ..\catalog\.

.PARAMETER OutputDir
    Carpeta donde escribir los reportes CSV/JSON. Default: .\strike-audit-out

.PARAMETER Full
    Muestra en consola TODOS los pasos (no solo los PARTIAL / NOT_COVERED).

.PARAMETER DeepSysmon
    Intenta volcar la config efectiva de Sysmon (sysmon -c) para verificar
    cobertura por tipo de evento. Requiere el binario de Sysmon y admin.

.EXAMPLE
    .\Invoke-StrikeTelemetryAudit.ps1

.EXAMPLE
    .\Invoke-StrikeTelemetryAudit.ps1 -Full -OutputDir C:\evidencia\soc

.NOTES
    Ejecutar en PowerShell ELEVADO (auditpol requiere privilegios de admin).
    Autor: Devel Security - Certificacion SOC / STRIKE
#>

[CmdletBinding()]
param(
    [string] $CatalogPath,
    [string] $OutputDir = ".\strike-audit-out",
    [switch] $Full,
    [switch] $DeepSysmon,
    [switch] $OpenReport,
    [string] $LogoPath
)

$ErrorActionPreference = 'Stop'
$script:ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ============================ util de salida ==============================
function Write-Head($text) {
    Write-Host ""
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
}
function Color-For($verdict) {
    switch ($verdict) {
        'OK'          { 'Green' }   'COVERED'     { 'Green' }
        'PARTIAL'     { 'Yellow' }  'UNKNOWN'     { 'DarkYellow' }
        'MISSING'     { 'Red' }     'NOT_COVERED' { 'Red' }
        'NA'          { 'DarkGray' } default       { 'Gray' }
    }
}

# ============================ localizar catalogo ==========================
if (-not $CatalogPath) {
    $cands = @(
        (Join-Path $script:ScriptDir 'strike_catalog.json'),
        (Join-Path $script:ScriptDir '..\catalog\strike_catalog.json'),
        '.\strike_catalog.json',
        '.\catalog\strike_catalog.json'
    )
    foreach ($c in $cands) { if (Test-Path $c) { $CatalogPath = (Resolve-Path $c).Path; break } }
}
if (-not $CatalogPath -or -not (Test-Path $CatalogPath)) {
    throw "No encuentro strike_catalog.json. Usa -CatalogPath."
}
$catalog = Get-Content -Raw -Path $CatalogPath -Encoding UTF8 | ConvertFrom-Json

# ============================ contexto de ejecucion =======================
$IsAdmin = ([Security.Principal.WindowsPrincipal]`
    [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole]::Administrator)

Write-Head "STRIKE - Audit de telemetria Windows (certificacion SOC)"
Write-Host (" Host        : {0}" -f $env:COMPUTERNAME)
Write-Host (" Fecha       : {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
Write-Host (" Catalogo    : {0}" -f $CatalogPath)
Write-Host (" Admin       : {0}" -f $(if ($IsAdmin) { 'SI' } else { 'NO (auditpol quedara en UNKNOWN - reabrir elevado)' })) `
    -ForegroundColor $(if ($IsAdmin) { 'Green' } else { 'Yellow' })

# =========================================================================
#  PROBES - se ejecutan una sola vez y se cachean en $Signals
# =========================================================================
$Signals = @{}   # key -> [pscustomobject]@{ Name; State; Detail }

function Set-Signal($key, $name, $state, $detail) {
    $Signals[$key] = [pscustomobject]@{ Name = $name; State = $state; Detail = $detail }
}

# --- auditpol por GUID (locale-independiente en el GUID) -----------------
# Las GUID de subcategoria son estables; el texto "Inclusion Setting" puede
# estar localizado, por eso buscamos tokens de exito en varios idiomas.
$AuditGuids = @{
    PROC_4688   = '{0CCE922B-69AE-11D9-BED3-505054503030}'  # Process Creation
    ACCT_MGMT   = '{0CCE9235-69AE-11D9-BED3-505054503030}'  # User Account Management
    GROUP_MGMT  = '{0CCE9237-69AE-11D9-BED3-505054503030}'  # Security Group Management
    SVC_EXT     = '{0CCE9211-69AE-11D9-BED3-505054503030}'  # Security System Extension
    OBJ_OTHER   = '{0CCE9227-69AE-11D9-BED3-505054503030}'  # Other Object Access Events
    REG_AUDIT   = '{0CCE921E-69AE-11D9-BED3-505054503030}'  # Registry
    FW_MPSSVC   = '{0CCE9232-69AE-11D9-BED3-505054503030}'  # MPSSVC Rule-Level Policy Change
    FW_FILTER   = '{0CCE9233-69AE-11D9-BED3-505054503030}'  # Filtering Platform Policy Change
}
$SuccessTokens = 'Success|Correcto|Exito|xito|Erfolg|Reussite|Riuscito'

function Probe-Audit($key, $name, $guid) {
    if (-not $IsAdmin) { Set-Signal $key $name 'UNKNOWN' 'requiere admin para leer auditpol'; return }
    try {
        $raw = & auditpol /get /subcategory:"$guid" /r 2>$null
        $line = $raw | Where-Object { $_ -match [regex]::Escape($guid) } | Select-Object -First 1
        if (-not $line) { Set-Signal $key $name 'UNKNOWN' 'auditpol sin dato'; return }
        $cols = $line.Split(',')
        $incl = ($cols[4]).Trim()
        if ($incl -match $SuccessTokens) {
            Set-Signal $key $name 'OK' ("Inclusion='{0}'" -f $incl)
        } else {
            Set-Signal $key $name 'MISSING' ("Inclusion='{0}' (sin auditoria de exito)" -f $incl)
        }
    } catch {
        Set-Signal $key $name 'UNKNOWN' ("error auditpol: {0}" -f $_.Exception.Message)
    }
}

foreach ($k in $AuditGuids.Keys) {
    $nm = switch ($k) {
        'PROC_4688'  { 'Audit Process Creation (4688)' }
        'ACCT_MGMT'  { 'Audit User Account Management (4720/4722/4738)' }
        'GROUP_MGMT' { 'Audit Security Group Management (4732/4728/4756)' }
        'SVC_EXT'    { 'Audit Security System Extension (4697)' }
        'OBJ_OTHER'  { 'Audit Other Object Access (4698 scheduled task)' }
        'REG_AUDIT'  { 'Audit Registry object access (4657 - requiere SACL)' }
        'FW_MPSSVC'  { 'Audit MPSSVC Rule-Level Policy Change (4946-4948)' }
        'FW_FILTER'  { 'Audit Filtering Platform Policy Change' }
    }
    Probe-Audit $k $nm $AuditGuids[$k]
}

# --- registro: cmdline en 4688 y PowerShell logging ----------------------
function Get-RegVal($path, $name) {
    try { return (Get-ItemProperty -Path $path -Name $name -ErrorAction Stop).$name }
    catch { return $null }
}

$cmdline = Get-RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' 'ProcessCreationIncludeCmdLine_Enabled'
if ($cmdline -eq 1) { Set-Signal 'CMDLINE' 'Linea de comandos en 4688' 'OK' 'ProcessCreationIncludeCmdLine_Enabled=1' }
elseif ($null -eq $cmdline) { Set-Signal 'CMDLINE' 'Linea de comandos en 4688' 'MISSING' 'clave ausente (no se captura cmdline)' }
else { Set-Signal 'CMDLINE' 'Linea de comandos en 4688' 'MISSING' ("valor={0}" -f $cmdline) }

$sbl = Get-RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging'
if ($sbl -eq 1) { Set-Signal 'PS_SBL' 'PowerShell Script Block Logging (4104)' 'OK' 'EnableScriptBlockLogging=1' }
else { Set-Signal 'PS_SBL' 'PowerShell Script Block Logging (4104)' 'MISSING' 'no habilitado' }

$psmod = Get-RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging' 'EnableModuleLogging'
if ($psmod -eq 1) { Set-Signal 'PS_MOD' 'PowerShell Module Logging (4103)' 'OK' 'EnableModuleLogging=1' }
else { Set-Signal 'PS_MOD' 'PowerShell Module Logging (4103)' 'MISSING' 'no habilitado' }

# --- Sysmon ---------------------------------------------------------------
$sysmonSvc = Get-Service -Name 'Sysmon','Sysmon64' -ErrorAction SilentlyContinue | Select-Object -First 1
$sysmonLog = $null
try { $sysmonLog = Get-WinEvent -ListLog 'Microsoft-Windows-Sysmon/Operational' -ErrorAction Stop } catch {}
if ($sysmonSvc -or $sysmonLog) {
    $det = @()
    if ($sysmonSvc) { $det += ("servicio={0}/{1}" -f $sysmonSvc.Name, $sysmonSvc.Status) }
    if ($sysmonLog) { $det += ("canal={0}" -f $(if ($sysmonLog.IsEnabled) { 'habilitado' } else { 'deshabilitado' })) }
    $state = if ($sysmonSvc -and $sysmonSvc.Status -eq 'Running') { 'OK' } else { 'PARTIAL' }
    Set-Signal 'SYSMON' 'Sysmon (ProcCreate/File/Reg/Net/ImageLoad)' $state ($det -join '; ')
} else {
    Set-Signal 'SYSMON' 'Sysmon' 'MISSING' 'no instalado (sin servicio ni canal Operational)'
}

if ($DeepSysmon -and $sysmonSvc) {
    try {
        $bin = (Get-Process -Name $sysmonSvc.Name -ErrorAction SilentlyContinue | Select-Object -First 1).Path
        if ($bin) {
            $cfg = & $bin -c 2>$null | Out-String
            Write-Host " [DeepSysmon] config efectiva obtenida ($($cfg.Length) chars)" -ForegroundColor DarkGray
        }
    } catch { Write-Host " [DeepSysmon] no se pudo volcar config: $($_.Exception.Message)" -ForegroundColor DarkYellow }
}

# --- BITS-Client/Operational ---------------------------------------------
try {
    $bits = Get-WinEvent -ListLog 'Microsoft-Windows-Bits-Client/Operational' -ErrorAction Stop
    if ($bits.IsEnabled) { Set-Signal 'BITS_LOG' 'BITS-Client/Operational (59/60)' 'OK' ("tam={0}MB" -f [math]::Round($bits.MaximumSizeInBytes/1MB,0)) }
    else { Set-Signal 'BITS_LOG' 'BITS-Client/Operational' 'MISSING' 'canal deshabilitado' }
} catch { Set-Signal 'BITS_LOG' 'BITS-Client/Operational' 'UNKNOWN' 'canal no disponible' }

# --- salud de canales de evento ------------------------------------------
function Get-LogInfo($name) {
    try {
        $l = Get-WinEvent -ListLog $name -ErrorAction Stop
        return [pscustomobject]@{
            Name = $name; Enabled = $l.IsEnabled
            MB = [math]::Round($l.MaximumSizeInBytes / 1MB, 0); Records = $l.RecordCount
        }
    } catch { return [pscustomobject]@{ Name = $name; Enabled = $null; MB = $null; Records = $null } }
}
$logChannels = @(
    'Security','System','Windows PowerShell',
    'Microsoft-Windows-PowerShell/Operational',
    'Microsoft-Windows-Sysmon/Operational',
    'Microsoft-Windows-Bits-Client/Operational'
)
$logHealth = $logChannels | ForEach-Object { Get-LogInfo $_ }

# =========================================================================
#  REMEDIACION: como habilitar cada fuente de datos que falte
# =========================================================================
function New-Remediation($what, $gpo, $cmd) {
    [pscustomobject]@{ What = $what; Gpo = $gpo; Cmd = $cmd }
}
$Remediation = @{
    PROC_4688  = New-Remediation 'Habilitar auditoria de creacion de procesos (evento 4688).' `
        'Equipo > Config. Windows > Config. seguridad > Config. avanzada de auditoria > Seguimiento detallado > Auditar la creacion de procesos = Correcto' `
        'auditpol /set /subcategory:"{0CCE922B-69AE-11D9-BED3-505054503030}" /success:enable'
    CMDLINE    = New-Remediation 'Incluir la linea de comandos completa en el evento 4688.' `
        'Plantillas administrativas > Sistema > Auditar la creacion de procesos > Incluir linea de comandos en los eventos de creacion de procesos = Habilitado' `
        'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" /v ProcessCreationIncludeCmdLine_Enabled /t REG_DWORD /d 1 /f'
    PS_SBL     = New-Remediation 'Activar PowerShell Script Block Logging (evento 4104).' `
        'Plantillas administrativas > Componentes de Windows > Windows PowerShell > Activar el registro de bloques de script de PowerShell = Habilitado' `
        'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" /v EnableScriptBlockLogging /t REG_DWORD /d 1 /f'
    PS_MOD     = New-Remediation 'Activar PowerShell Module Logging (evento 4103).' `
        'Plantillas administrativas > Componentes de Windows > Windows PowerShell > Activar el registro de modulos = Habilitado (ModuleNames = *)' `
        'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging" /v EnableModuleLogging /t REG_DWORD /d 1 /f ; reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames" /v * /t REG_SZ /d * /f'
    SYSMON     = New-Remediation 'Instalar Sysmon con una configuracion de deteccion (p.ej. SwiftOnSecurity/Olaf) para ProcessCreate(1), FileCreate(11), Registry(12/13), Network(3), ImageLoad(7).' `
        '(No es GPO) Desplegar binario + config por GPO/SCCM/Intune y mantener la config versionada.' `
        'sysmon64.exe -accepteula -i sysmonconfig.xml   # actualizar: sysmon64 -c sysmonconfig.xml'
    ACCT_MGMT  = New-Remediation 'Auditar gestion de cuentas de usuario (4720/4722/4738).' `
        'Config. avanzada de auditoria > Administracion de cuentas > Auditar administracion de cuentas de usuario = Correcto' `
        'auditpol /set /subcategory:"{0CCE9235-69AE-11D9-BED3-505054503030}" /success:enable'
    GROUP_MGMT = New-Remediation 'Auditar gestion de grupos de seguridad (4732/4728/4756).' `
        'Config. avanzada de auditoria > Administracion de cuentas > Auditar administracion de grupos de seguridad = Correcto' `
        'auditpol /set /subcategory:"{0CCE9237-69AE-11D9-BED3-505054503030}" /success:enable'
    SVC_EXT    = New-Remediation 'Auditar extension del sistema de seguridad (instalacion de servicios, 4697).' `
        'Config. avanzada de auditoria > Seguimiento de directivas > Auditar la extension del sistema de seguridad = Correcto' `
        'auditpol /set /subcategory:"{0CCE9211-69AE-11D9-BED3-505054503030}" /success:enable'
    OBJ_OTHER  = New-Remediation 'Auditar otros eventos de acceso a objetos (tareas programadas, 4698).' `
        'Config. avanzada de auditoria > Acceso a objetos > Auditar otros eventos de acceso a objetos = Correcto' `
        'auditpol /set /subcategory:"{0CCE9227-69AE-11D9-BED3-505054503030}" /success:enable'
    REG_AUDIT  = New-Remediation 'Auditar acceso al registro (4657). OJO: ademas requiere SACL en las claves a vigilar; preferir Sysmon 12/13.' `
        'Config. avanzada de auditoria > Acceso a objetos > Auditar el registro = Correcto (+ SACL en claves criticas)' `
        'auditpol /set /subcategory:"{0CCE921E-69AE-11D9-BED3-505054503030}" /success:enable'
    FW_MPSSVC  = New-Remediation 'Auditar cambios de directiva de firewall (4946-4948).' `
        'Config. avanzada de auditoria > Cambio de directivas > Auditar el cambio de directiva de nivel de regla MPSSVC = Correcto' `
        'auditpol /set /subcategory:"{0CCE9232-69AE-11D9-BED3-505054503030}" /success:enable'
    FW_FILTER  = New-Remediation 'Auditar cambios de la plataforma de filtrado (firewall).' `
        'Config. avanzada de auditoria > Cambio de directivas > Auditar el cambio de la directiva de la plataforma de filtrado = Correcto' `
        'auditpol /set /subcategory:"{0CCE9233-69AE-11D9-BED3-505054503030}" /success:enable'
    BITS_LOG   = New-Remediation 'Habilitar el canal BITS-Client/Operational (transferencias, 59/60).' `
        '(No es GPO) Habilitar el canal de evento operativo.' `
        'wevtutil sl Microsoft-Windows-Bits-Client/Operational /e:true'
}

# =========================================================================
#  MAPEO: comando STRIKE  ->  senales de telemetria requeridas
# =========================================================================
function Get-RequiredSignals($cmd, $mitre) {
    $c = ($cmd + ' ' + $mitre).ToLower()
    $reqs = New-Object System.Collections.ArrayList

    # Requisito PRIMARIO: todo comando de endpoint debe verse como proceso.
    [void]$reqs.Add([pscustomobject]@{ Label = 'Ejecucion de proceso (4688 / Sysmon 1)'; Alt = @('PROC_4688','SYSMON'); Critical = $true })
    # Enriquecimiento: linea de comandos completa.
    [void]$reqs.Add([pscustomobject]@{ Label = 'Linea de comandos (cmdline 4688 / Sysmon 1)'; Alt = @('CMDLINE','SYSMON'); Critical = $false })

    $isPs = $c -match 'powershell|invoke-command|invoke-expression|get-|new-local|add-local|start-bitstransfer|convertto-secure|enable-psremoting|get-smbshare|get-localuser'
    if ($isPs) {
        [void]$reqs.Add([pscustomobject]@{ Label = 'PowerShell Script Block (4104)'; Alt = @('PS_SBL'); Critical = $false })
    }
    if ($c -match 'reg add|reg\.exe|reg query|reg delete|reg query|hkcu|hklm|hkey_|reg\b') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Modificacion de registro (Sysmon 12/13 o 4657+SACL)'; Alt = @('SYSMON','REG_AUDIT'); Critical = $false })
    }
    if ($c -match 'net user.*\/add|user \/add|useradd|new-localuser|net\.exe user') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Creacion de cuenta (4720)'; Alt = @('ACCT_MGMT'); Critical = $false })
    }
    if ($c -match 'localgroup.*\/add|add-localgroupmember|net group.*\/add|net localgroup') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Cambio de grupo/privilegio (4732/4728/4756)'; Alt = @('GROUP_MGMT'); Critical = $false })
    }
    if ($c -match 'sc\.exe create|sc create|new-service|binpath') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Instalacion de servicio (7045 / 4697)'; Alt = @('SVC_EXT','PROC_4688'); Critical = $false })
    }
    if ($c -match 'schtasks') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Tarea programada (4698)'; Alt = @('OBJ_OTHER','SYSMON'); Critical = $false })
    }
    if ($c -match 'netsh advfirewall|netsh firewall|set-netfirewall|advfirewall') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Cambio de firewall (4946-4948)'; Alt = @('FW_MPSSVC','FW_FILTER','PROC_4688'); Critical = $false })
    }
    if ($c -match 'bitsadmin|start-bitstransfer|bits') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Transferencia BITS (BITS-Client 59/60)'; Alt = @('BITS_LOG','PROC_4688'); Critical = $false })
    }
    if ($c -match 'echo .*>|copy |cp |downloader|out-file|set-content|certutil|curl |wget |> c:\\') {
        [void]$reqs.Add([pscustomobject]@{ Label = 'Escritura de archivo (Sysmon 11)'; Alt = @('SYSMON'); Critical = $false })
    }
    return $reqs
}

function Eval-Req($req) {
    $states = @($req.Alt | ForEach-Object { if ($Signals.ContainsKey($_)) { $Signals[$_].State } else { 'NA' } })
    if ($states -contains 'OK') { return 'OK' }
    if (($states -contains 'PARTIAL') -or ($states -contains 'UNKNOWN')) { return 'PARTIAL' }
    return 'MISSING'
}

# =========================================================================
#  EVALUACION por paso (solo plataforma windows)
# =========================================================================
$winSteps = $catalog.steps | Where-Object { $_.platform -eq 'windows' }
$otherSteps = $catalog.steps | Where-Object { $_.platform -ne 'windows' }

$results = New-Object System.Collections.ArrayList
foreach ($s in $winSteps) {
    $srcCmd = if ($s.command) { $s.command } else { $s.title }
    $reqs = Get-RequiredSignals $srcCmd $s.mitre
    $missing = New-Object System.Collections.ArrayList
    $partial = New-Object System.Collections.ArrayList
    $criticalFail = $false
    foreach ($r in $reqs) {
        $st = Eval-Req $r
        if ($st -eq 'MISSING') { [void]$missing.Add($r.Label); if ($r.Critical) { $criticalFail = $true } }
        elseif ($st -eq 'PARTIAL') { [void]$partial.Add($r.Label); if ($r.Critical) { $criticalFail = $true } }
    }
    $verdict = if ($criticalFail) { 'NOT_COVERED' }
               elseif ($missing.Count -gt 0 -or $partial.Count -gt 0) { 'PARTIAL' }
               else { 'COVERED' }
    [void]$results.Add([pscustomobject]@{
        StrikeId  = $s.strike_id
        Scenario  = $s.scenario_id
        Mitre     = $s.mitre
        Title     = $s.title
        Verdict   = $verdict
        Missing   = ($missing -join ' | ')
        Partial   = ($partial -join ' | ')
        Command   = $srcCmd
    })
}

# =========================================================================
#  SALIDA
# =========================================================================
Write-Head "Postura de fuentes de datos (telemetria del host)"
foreach ($key in ($Signals.Keys | Sort-Object)) {
    $sig = $Signals[$key]
    Write-Host ("  [{0,-7}] {1,-52} {2}" -f $sig.State, $sig.Name, $sig.Detail) -ForegroundColor (Color-For $sig.State)
}

Write-Head "Salud de canales de evento"
$logHealth | ForEach-Object {
    $state = if ($_.Enabled -eq $true) { 'OK' } elseif ($null -eq $_.Enabled) { 'UNKNOWN' } else { 'MISSING' }
    Write-Host ("  [{0,-7}] {1,-45} {2}" -f $state, $_.Name,
        $(if ($null -ne $_.MB) { "max=$($_.MB)MB  registros=$($_.Records)" } else { 'no disponible' })) `
        -ForegroundColor (Color-For $state)
}

Write-Head "Resultado por paso STRIKE (Windows)"
$show = if ($Full) { $results } else { $results | Where-Object { $_.Verdict -ne 'COVERED' } }
if (-not $Full) {
    Write-Host " (mostrando solo PARTIAL / NOT_COVERED; usa -Full para ver todos)`n" -ForegroundColor DarkGray
}
foreach ($r in $show) {
    Write-Host ("  {0,-6} {1,-11} {2,-8} {3}" -f $r.StrikeId, $r.Mitre, $r.Verdict, $r.Title) -ForegroundColor (Color-For $r.Verdict)
    if ($r.Missing)  { Write-Host ("          falta  : {0}" -f $r.Missing) -ForegroundColor Red }
    if ($r.Partial)  { Write-Host ("          parcial: {0}" -f $r.Partial) -ForegroundColor Yellow }
}

# --- scorecard por escenario ---------------------------------------------
Write-Head "Scorecard por escenario"
$byScn = $results | Group-Object Scenario | Sort-Object { [int]$_.Name }
foreach ($g in $byScn) {
    $cov = ($g.Group | Where-Object Verdict -eq 'COVERED').Count
    $par = ($g.Group | Where-Object Verdict -eq 'PARTIAL').Count
    $nc  = ($g.Group | Where-Object Verdict -eq 'NOT_COVERED').Count
    $scnName = ($catalog.meta.scenarios | Where-Object { $_.scenario_id -eq [int]$g.Name }).name
    Write-Host ("  Escenario {0,-2} [{1}]" -f $g.Name, $scnName)
    Write-Host ("     COVERED={0}  PARTIAL={1}  NOT_COVERED={2}  (total {3})" -f $cov, $par, $nc, $g.Group.Count) `
        -ForegroundColor $(if ($nc -gt 0) { 'Red' } elseif ($par -gt 0) { 'Yellow' } else { 'Green' })
}

# --- resumen global --------------------------------------------------------
$tCov = ($results | Where-Object Verdict -eq 'COVERED').Count
$tPar = ($results | Where-Object Verdict -eq 'PARTIAL').Count
$tNc  = ($results | Where-Object Verdict -eq 'NOT_COVERED').Count
Write-Head "Resumen global"
Write-Host ("  Pasos Windows evaluados : {0}" -f $results.Count)
Write-Host ("  COVERED                 : {0}" -f $tCov) -ForegroundColor Green
Write-Host ("  PARTIAL                 : {0}" -f $tPar) -ForegroundColor Yellow
Write-Host ("  NOT_COVERED             : {0}" -f $tNc)  -ForegroundColor Red
Write-Host ("  Pasos NO-Windows (Linux/cloud, fuera de este audit de host): {0}" -f $otherSteps.Count) -ForegroundColor DarkGray
Write-Host "  -> Esos se certifican por el camino SIEM/syslog (strike_syslog_emitter.sh)." -ForegroundColor DarkGray

# =========================================================================
#  EXPORTACION
# =========================================================================
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$csvPath  = Join-Path $OutputDir ("strike-telemetry-audit-$stamp.csv")
$jsonPath = Join-Path $OutputDir ("strike-telemetry-audit-$stamp.json")

$results | Select-Object StrikeId,Scenario,Mitre,Verdict,Missing,Partial,Title,Command |
    Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

$report = [pscustomobject]@{
    host        = $env:COMPUTERNAME
    generated   = (Get-Date -Format 's')
    admin       = $IsAdmin
    catalog     = $CatalogPath
    signals     = $Signals
    log_health  = $logHealth
    summary     = [pscustomobject]@{ covered = $tCov; partial = $tPar; not_covered = $tNc; windows_steps = $results.Count; non_windows_steps = $otherSteps.Count }
    results     = $results
}
# UTF-8 SIN BOM (Set-Content -Encoding UTF8 en PS 5.1 agrega BOM y rompe parsers JSON estrictos)
$jsonText = $report | ConvertTo-Json -Depth 6
[System.IO.File]::WriteAllText($jsonPath, $jsonText, (New-Object System.Text.UTF8Encoding $false))

# --- reporte HTML ---------------------------------------------------------
function Html-Enc($s) {
    if ($null -eq $s) { return '' }
    return ([string]$s).Replace('&','&amp;').Replace('<','&lt;').Replace('>','&gt;').Replace('"','&quot;')
}
function Badge($state) {
    $cls = switch ($state) {
        'OK' { 'ok' } 'COVERED' { 'ok' } 'PARTIAL' { 'warn' } 'UNKNOWN' { 'unk' }
        'MISSING' { 'bad' } 'NOT_COVERED' { 'bad' } default { 'unk' }
    }
    return "<span class='badge $cls'>$(Html-Enc $state)</span>"
}

function New-HtmlReport {
    $sb = New-Object System.Text.StringBuilder
    $add = { param($t) [void]$sb.AppendLine($t) }

    # --- logo embebido (data-URI, para mantener el HTML autocontenido) ---
    $logoFile = $LogoPath
    if (-not $logoFile) {
        foreach ($c in @(
            (Join-Path $script:ScriptDir 'logo.png'),
            (Join-Path $script:ScriptDir '..\logo.png'),
            '.\logo.png')) {
            if (Test-Path $c) { $logoFile = (Resolve-Path $c).Path; break }
        }
    }
    $logoTag = ''
    if ($logoFile -and (Test-Path $logoFile)) {
        try {
            $b64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($logoFile))
            $ext = ([System.IO.Path]::GetExtension($logoFile)).TrimStart('.').ToLower()
            if ($ext -eq 'jpg') { $ext = 'jpeg' }
            $logoTag = "<img class='logo' src='data:image/$ext;base64,$b64' alt='Devel Group'>"
        } catch {}
    }
    if (-not $logoTag) { $logoTag = "<div class='logo-fallback'>DEVEL<span>/</span>GROUP</div>" }

    # --- filas: fuentes de datos ---
    $sigRows = ''
    foreach ($key in ($Signals.Keys | Sort-Object)) {
        $s = $Signals[$key]
        $sigRows += "<tr><td>$(Badge $s.State)</td><td>$(Html-Enc $s.Name)</td><td class='mono'>$(Html-Enc $s.Detail)</td></tr>`n"
    }

    # --- filas: acciones recomendadas (senales no-OK con remediacion) ---
    $actRows = ''
    foreach ($key in ($Signals.Keys | Sort-Object)) {
        $s = $Signals[$key]
        if ($s.State -eq 'OK') { continue }
        if (-not $Remediation.ContainsKey($key)) { continue }
        $r = $Remediation[$key]
        $actRows += @"
<tr>
  <td>$(Badge $s.State)</td>
  <td><b>$(Html-Enc $s.Name)</b><div class='muted'>$(Html-Enc $r.What)</div></td>
  <td class='mono small'>$(Html-Enc $r.Gpo)</td>
  <td class='mono small cmd'>$(Html-Enc $r.Cmd)</td>
</tr>
"@
    }
    if (-not $actRows) { $actRows = "<tr><td colspan='4' class='muted'>Sin acciones pendientes: todas las fuentes de datos auditables estan OK.</td></tr>" }

    # --- filas: salud de canales ---
    $logRows = ''
    foreach ($l in $logHealth) {
        $st = if ($l.Enabled -eq $true) { 'OK' } elseif ($null -eq $l.Enabled) { 'UNKNOWN' } else { 'MISSING' }
        $info = if ($null -ne $l.MB) { "max $($l.MB) MB &middot; $($l.Records) registros" } else { 'no disponible' }
        $logRows += "<tr><td>$(Badge $st)</td><td>$(Html-Enc $l.Name)</td><td class='mono'>$info</td></tr>`n"
    }

    # --- filas: pasos ---
    $stepRows = ''
    foreach ($r in ($results | Sort-Object { [int]($_.StrikeId.Split('.')[0]) }, { [int]($_.StrikeId.Split('.')[1]) })) {
        $gaps = @()
        if ($r.Missing) { $gaps += "<span class='gap bad'>$(Html-Enc $r.Missing)</span>" }
        if ($r.Partial) { $gaps += "<span class='gap warn'>$(Html-Enc $r.Partial)</span>" }
        $stepRows += @"
<tr data-verdict='$($r.Verdict)'>
  <td class='mono'>$(Html-Enc $r.StrikeId)</td>
  <td>$(Badge $r.Verdict)</td>
  <td class='mono'>$(Html-Enc $r.Mitre)</td>
  <td>$(Html-Enc $r.Title)</td>
  <td class='small'>$($gaps -join '<br>')</td>
</tr>
"@
    }

    # --- scorecard ---
    $scRows = ''
    foreach ($g in ($results | Group-Object Scenario | Sort-Object { [int]$_.Name })) {
        $cov = ($g.Group | Where-Object Verdict -eq 'COVERED').Count
        $par = ($g.Group | Where-Object Verdict -eq 'PARTIAL').Count
        $nc  = ($g.Group | Where-Object Verdict -eq 'NOT_COVERED').Count
        $nm  = ($catalog.meta.scenarios | Where-Object { $_.scenario_id -eq [int]$g.Name }).name
        $scRows += "<tr><td class='mono'>$($g.Name)</td><td>$(Html-Enc $nm)</td><td class='ok-t'>$cov</td><td class='warn-t'>$par</td><td class='bad-t'>$nc</td><td>$($g.Group.Count)</td></tr>`n"
    }

    $adminNote = if ($IsAdmin) { '' } else {
        "<div class='alert'>Este reporte se genero SIN privilegios de administrador: las subcategorias de <code>auditpol</code> quedaron en UNKNOWN e inflan los NOT_COVERED. Volver a ejecutar en una consola elevada para un resultado valido.</div>"
    }

    $html = @"
<!doctype html>
<html lang='es'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>STRIKE - Audit de telemetria - $(Html-Enc $env:COMPUTERNAME)</title>
<style>
 :root{--bg:#f6f7f9;--card:#fff;--fg:#1a1f29;--muted:#6b7280;--line:#e5e7eb;
   --ok:#15803d;--okbg:#dcfce7;--warn:#a16207;--warnbg:#fef9c3;--bad:#b91c1c;--badbg:#fee2e2;--unk:#4b5563;--unkbg:#e5e7eb;--accent:#0e7490;}
 @media (prefers-color-scheme:dark){:root{--bg:#0f1115;--card:#171a21;--fg:#e5e7eb;--muted:#9ca3af;--line:#2a2f3a;
   --ok:#4ade80;--okbg:#0c2c1a;--warn:#facc15;--warnbg:#2c2410;--bad:#f87171;--badbg:#2c1416;--unk:#9ca3af;--unkbg:#232732;--accent:#22d3ee;}}
 *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;padding:0 0 24px}
 h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:28px 0 10px;color:var(--accent)}
 .wrap{max-width:1200px;margin:0 auto;padding:0 24px}
 /* --- banda de certificacion --- */
 .cert{background:#0d0f13;border-bottom:3px solid #ff3a0e;color:#fff;padding:18px 24px;margin-bottom:8px}
 .cert .in{max-width:1200px;margin:0 auto;display:flex;align-items:center;gap:20px;flex-wrap:wrap}
 .cert .logo{height:52px;width:auto;display:block}
 .cert .logo-fallback{font-weight:800;font-size:26px;letter-spacing:.02em;color:#fff}
 .cert .logo-fallback span{color:#ff3a0e}
 .cert .txt{border-left:1px solid #2a2f3a;padding-left:20px}
 .cert .t1{font-size:12px;letter-spacing:.22em;color:#9aa3b2;text-transform:uppercase;margin:0}
 .cert .t2{font-size:20px;font-weight:700;margin:2px 0 0;color:#fff}
 .cert .t3{font-size:13px;margin-top:3px;color:#ff6a43;font-weight:600;letter-spacing:.03em}
 .cert .seal{margin-left:auto;text-align:right;font-size:11px;color:#9aa3b2;line-height:1.4}
 .cert .seal b{color:#fff;font-size:13px}
 .meta{color:var(--muted);font-size:13px}
 .cards{display:flex;gap:14px;flex-wrap:wrap;margin:18px 0}
 .kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px 20px;min-width:150px;flex:1}
 .kpi .n{font-size:30px;font-weight:700}.kpi .l{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em}
 .kpi.ok .n{color:var(--ok)}.kpi.warn .n{color:var(--warn)}.kpi.bad .n{color:var(--bad)}
 table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden}
 th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}
 th{background:rgba(127,127,127,.08);font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted)}
 tr:last-child td{border-bottom:0}
 .mono{font-family:ui-monospace,Consolas,monospace;font-size:12px}.small{font-size:12px}.muted{color:var(--muted);font-size:12px;margin-top:3px}
 .cmd{white-space:pre-wrap;word-break:break-all;background:rgba(127,127,127,.07);border-radius:6px;padding:4px 6px}
 .badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}
 .badge.ok{background:var(--okbg);color:var(--ok)}.badge.warn{background:var(--warnbg);color:var(--warn)}
 .badge.bad{background:var(--badbg);color:var(--bad)}.badge.unk{background:var(--unkbg);color:var(--unk)}
 .ok-t{color:var(--ok);font-weight:700}.warn-t{color:var(--warn);font-weight:700}.bad-t{color:var(--bad);font-weight:700}
 .alert{background:var(--warnbg);color:var(--warn);border:1px solid var(--warn);border-radius:10px;padding:10px 14px;margin:14px 0;font-size:13px}
 .gap{display:block}.gap.bad{color:var(--bad)}.gap.warn{color:var(--warn)}
 code{font-family:ui-monospace,Consolas,monospace;background:rgba(127,127,127,.12);padding:1px 4px;border-radius:4px}
 .filters{margin:10px 0}.filters button{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:999px;padding:5px 12px;cursor:pointer;font-size:12px;margin-right:6px}
 .filters button.active{background:var(--accent);color:#fff;border-color:var(--accent)}
 footer{color:var(--muted);font-size:12px;margin-top:30px;text-align:center}
</style></head><body>
 <div class='cert'><div class='in'>
   $logoTag
   <div class='txt'>
     <p class='t1'>Certificacion de Fuentes de Informacion</p>
     <p class='t2'>iSOC &mdash; Devel Group</p>
     <p class='t3'>Metodologia STRIKE &middot; Audit de telemetria de endpoint Windows</p>
   </div>
   <div class='seal'><b>$(Html-Enc $env:COMPUTERNAME)</b><br>$(Get-Date -Format 'yyyy-MM-dd HH:mm')<br>Run elevado: $(if($IsAdmin){'SI'}else{'NO'})</div>
 </div></div>
 <div class='wrap'>
 <div class='meta'>Catalogo: $(Html-Enc (Split-Path $CatalogPath -Leaf)) &middot; $($results.Count) pasos Windows evaluados &middot; $($otherSteps.Count) pasos no-Windows (via SIEM)</div>
 $adminNote
 <div class='cards'>
   <div class='kpi ok'><div class='n'>$tCov</div><div class='l'>Covered</div></div>
   <div class='kpi warn'><div class='n'>$tPar</div><div class='l'>Partial</div></div>
   <div class='kpi bad'><div class='n'>$tNc</div><div class='l'>Not covered</div></div>
   <div class='kpi'><div class='n'>$($results.Count)</div><div class='l'>Pasos Windows</div></div>
   <div class='kpi'><div class='n'>$($otherSteps.Count)</div><div class='l'>No-Windows (SIEM)</div></div>
 </div>

 <h2>Acciones recomendadas (que configurar)</h2>
 <table><thead><tr><th>Estado</th><th>Fuente de datos / que hacer</th><th>Ruta GPO</th><th>Comando (admin)</th></tr></thead>
 <tbody>$actRows</tbody></table>

 <h2>Postura de fuentes de datos</h2>
 <table><thead><tr><th>Estado</th><th>Fuente</th><th>Detalle</th></tr></thead><tbody>$sigRows</tbody></table>

 <h2>Salud de canales de evento</h2>
 <table><thead><tr><th>Estado</th><th>Canal</th><th>Detalle</th></tr></thead><tbody>$logRows</tbody></table>

 <h2>Scorecard por escenario</h2>
 <table><thead><tr><th>#</th><th>Escenario</th><th>Covered</th><th>Partial</th><th>Not cov.</th><th>Total</th></tr></thead><tbody>$scRows</tbody></table>

 <h2>Resultado por paso STRIKE</h2>
 <div class='filters'>
   <button class='active' onclick='flt(this,"all")'>Todos</button>
   <button onclick='flt(this,"NOT_COVERED")'>Not covered</button>
   <button onclick='flt(this,"PARTIAL")'>Partial</button>
   <button onclick='flt(this,"COVERED")'>Covered</button>
 </div>
 <table id='steps'><thead><tr><th>ID</th><th>Veredicto</th><th>MITRE</th><th>Tecnica / paso</th><th>Telemetria faltante</th></tr></thead>
 <tbody>$stepRows</tbody></table>

 <footer>Generado por Invoke-StrikeTelemetryAudit.ps1 &middot; Devel Security &mdash; Certificacion SOC / STRIKE</footer>
</div>
<script>
 function flt(btn,v){
   document.querySelectorAll('.filters button').forEach(function(b){b.classList.remove('active')});
   btn.classList.add('active');
   document.querySelectorAll('#steps tbody tr').forEach(function(r){
     r.style.display=(v==='all'||r.getAttribute('data-verdict')===v)?'':'none';
   });
 }
</script></body></html>
"@
    return $html
}

$htmlPath = Join-Path $OutputDir ("strike-telemetry-audit-$stamp.html")
[System.IO.File]::WriteAllText($htmlPath, (New-HtmlReport), (New-Object System.Text.UTF8Encoding $false))

Write-Host ""
Write-Host (" Reporte CSV : {0}" -f $csvPath) -ForegroundColor Cyan
Write-Host (" Reporte JSON: {0}" -f $jsonPath) -ForegroundColor Cyan
Write-Host (" Reporte HTML: {0}" -f $htmlPath) -ForegroundColor Cyan
Write-Host ""
if ($OpenReport) { try { Invoke-Item $htmlPath } catch {} }
