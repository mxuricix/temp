# STRIKE – Certificación SOC

Dos herramientas para certificar la detección de **toda** la metodología BAS
STRIKE en el SIEM y en los endpoints, partiendo de un **catálogo maestro único**.

Ninguna de las dos ejecuta los comandos ofensivos de STRIKE. Son de lectura /
emisión de logs sintéticos: seguras de correr en producción.

---

## 1. Catálogo maestro (`catalog/`)

`catalog/strike_catalog.json` es el inventario de **337 pasos** de los 13
escenarios STRIKE, generado automáticamente desde los `.md` exportados.

Cada paso tiene un **ID estable `escenario.paso`** (ej. `1.1`, `3.14`, `8.48`)
para trazabilidad end-to-end. Ese ID viaja dentro de cada evento syslog y de
cada fila del reporte de Windows, así "sabemos toda la metodología".

| ID escenario | Plataforma  | Escenario | Pasos |
|---|---|---|---|
| 1  | windows     | 2025-PA-P1-Windows-Baseline-v01 | 14 |
| 2  | windows     | 2026-PA-P2-Windows-Baseline-v01 | 17 |
| 3  | windows     | 2026-PA-P2-Windows-Baseline-v02 | 18 |
| 4  | windows     | Binpack MalwareWriteRun v01 | 6 |
| 5  | windows     | Binpack MalwareWriteRun v02 | 5 |
| 6  | windows     | Binpack MalwareWriteRun v03 | 6 |
| 7  | linux       | 2025-PA-P1-Linux-Baseline-v01 | 11 |
| 8  | aws         | AWS Atomic Identity Compromise & Data Plane Intrusion | 48 |
| 9  | azure       | Azure Subscription and Resource Compromise | 45 |
| 10 | cicd        | CICD Supply Chain Compromise to Production | 40 |
| 11 | hybrid-ad   | Hybrid Active Directory to Microsoft Entra Compromise | 45 |
| 12 | kubernetes  | Kubernetes Cluster Compromise and Workload Pivot | 34 |
| 13 | entra-m365  | Microsoft Entra ID and Microsoft 365 Identity Compromise | 48 |

**Regenerar el catálogo** (si cambian los `.md` de STRIKE):

```bash
python catalog/build_catalog.py
```

Campos por paso: `strike_id`, `scenario_id`, `scenario_name`, `platform`,
`step`, `title`, `mitre`, `command` (fiel al origen) y `summary_cmd` (una
línea, sin andamiaje, para el mensaje syslog).

---

## 2. Emisor de syslog – certificar reglas del SIEM (`linux/`)

`linux/strike_syslog_emitter.sh` envía al receptor syslog del SIEM una
**ráfaga** de eventos sintéticos, uno por cada paso del catálogo, emulando ser
un endpoint llamado **`EP_CERTIFICATION`**. Luego se revisa en el SIEM qué IDs
llegaron y qué alertas dispararon.

- Transporte **UDP** (default) o TCP, a la IP/puerto que le des.
- Formato **RFC3164** (default) o **RFC5424**, syslog-compliant.
- Marca cada evento con `id=<escenario.paso>`, `mitre=`, `platform=`,
  `scenario=`, `step=`, `cmd=` y un `run_id` único por ejecución.
- Eventos marcadores `RUN_START` / `RUN_END` para acotar el lote en el SIEM.
- **No ejecuta nada**: solo construye texto de log y lo manda por el socket.

### Uso

```bash
# Ráfaga completa (337 eventos) al SIEM
./linux/strike_syslog_emitter.sh -s 10.0.0.50

# Puerto/proto/formato a medida + manifiesto para reconciliar
./linux/strike_syslog_emitter.sh -s 10.0.0.50 -p 1514 --proto tcp \
    --format rfc5424 --manifest certificacion_$(date +%F).csv

# Solo ciertos escenarios o una plataforma
./linux/strike_syslog_emitter.sh -s 10.0.0.50 --scenario 1,2,3
./linux/strike_syslog_emitter.sh -s 10.0.0.50 --platform windows

# Ver qué se enviaría sin enviar nada
./linux/strike_syslog_emitter.sh --dry-run | less
```

Ejemplo de evento (RFC3164):

```
<133>Oct 29 13:16:12 EP_CERTIFICATION STRIKE_CERT[13054]: STRIKE_CERT run_id=20261029T191611Z-13054 id=1.1 mitre=T1047 platform=windows scenario="2025-PA-P1-Windows-Baseline-v01" step="Windows Management Instrumentation: T1047" cmd="cmd /c wmic useraccount get /ALL /format:csv"
```

**En el SIEM:** filtra `host=EP_CERTIFICATION` y/o `tag=STRIKE_CERT` y acota por
`run_id`. El `--manifest` genera un CSV (`sent_utc,run_id,strike_id,...`) para
cruzar "enviado vs. alertado" y encontrar reglas faltantes.

Dependencias: `bash` (redirección `/dev/udp`) o `nc`; `python3` **o** `jq`.

---

## 3. Audit de telemetría Windows (`windows/`)

`windows/Invoke-StrikeTelemetryAudit.ps1` audita, para cada paso Windows del
catálogo, si el host **puede generar la telemetría necesaria para detectarlo**.
Revisa:

- **Advanced Audit Policy** (via `auditpol`, por GUID, locale-independiente):
  Process Creation (4688), Account/Group Management (4720/4732…), Security
  System Extension (4697/7045), Other Object Access (4698), Registry (4657),
  Firewall policy change (4946-4948).
- **Línea de comandos en 4688** (`ProcessCreationIncludeCmdLine_Enabled`).
- **PowerShell** Script Block (4104) y Module Logging (4103).
- **Sysmon**: servicio, driver y canal Operational (y config con `-DeepSysmon`).
- **Salud de canales** de evento (Security, System, PowerShell, Sysmon, BITS).

Cada paso recibe un veredicto: **COVERED** / **PARTIAL** / **NOT_COVERED**, con
el detalle de qué telemetría falta. Exporta **CSV + JSON** como evidencia.

### Uso (PowerShell **elevado** – `auditpol` requiere admin)

```powershell
.\windows\Invoke-StrikeTelemetryAudit.ps1                 # resumen + faltantes
.\windows\Invoke-StrikeTelemetryAudit.ps1 -Full           # todos los pasos
.\windows\Invoke-StrikeTelemetryAudit.ps1 -OutputDir C:\evidencia\soc
.\windows\Invoke-StrikeTelemetryAudit.ps1 -DeepSysmon     # inspecciona config Sysmon
```

> Sin privilegios de admin, `auditpol` no se puede leer y esos ítems quedan en
> `UNKNOWN` (lo que infla los `NOT_COVERED`). Correr siempre elevado.

---

## Flujo de certificación sugerido

1. **SIEM (reglas):** correr el emisor syslog con `--manifest`; en el SIEM
   verificar, por `run_id`, qué `strike_id` llegaron y cuáles dispararon alerta.
   Los que no → regla faltante o mal configurada.
2. **Endpoint (telemetría):** correr el audit de Windows elevado en una máquina
   representativa; los `PARTIAL`/`NOT_COVERED` indican fuentes de datos que hay
   que habilitar (GPO de auditoría, cmdline, PS logging, Sysmon) antes de
   confiar en las reglas del SIEM.

---

## Estructura

```
strike_scripts_certificacion_soc/
├─ catalog/
│  ├─ build_catalog.py          # parser .md -> JSON
│  └─ strike_catalog.json       # catálogo maestro (337 pasos)
├─ linux/
│  └─ strike_syslog_emitter.sh  # ráfaga de syslog al SIEM (EP_CERTIFICATION)
├─ windows/
│  └─ Invoke-StrikeTelemetryAudit.ps1   # audit de postura de telemetría
└─ STRIKE/                       # export original de la metodología (.md)
```
