# HANDOFF — STRIKE / Certificación SOC (iSOC · Devel Group)

> Documento de traspaso para el **siguiente agente/ingeniero**. Describe qué
> hace cada pieza, cómo encaja, los puntos frágiles conocidos y cómo probar y
> regenerar. Escrito para quien va a continuar y **depurar**, no para el cliente.

Última actualización: 2026-10-29 · Entorno de desarrollo: Windows 11 + Git Bash + PowerShell 5.1 + Python 3.13.

---

## 1. Objetivo del proyecto

Dos capacidades de certificación sobre la metodología BAS **STRIKE**:

1. **Validación de fuentes de información (postura de telemetría del endpoint).**
   ¿El host (Windows/Linux) está configurado para *generar* la telemetría que
   el SOC necesita para detectar cada comando de STRIKE? → scripts de auditoría
   de **solo lectura** que producen un reporte HTML de certificación.
2. **Certificación de reglas del SIEM.** Emitir una ráfaga de eventos syslog
   sintéticos (uno por paso de STRIKE) emulando un endpoint `EP_CERTIFICATION`,
   para verificar que las reglas de detección del SIEM existan y disparen.

Ninguna herramienta ejecuta los comandos ofensivos de STRIKE. La #1 solo lee
configuración; la #2 solo envía texto de log por un socket.

---

## 2. Arquitectura y flujo de datos

```
STRIKE/STRIKE/*.md  (13 escenarios, export original)
        │
        │  catalog/build_catalog.py   (parser)
        ▼
catalog/strike_catalog.json   ← CATÁLOGO MAESTRO (337 pasos, fuente única de verdad)
        │
        ├────────────────────────────┬─────────────────────────────┐
        ▼                            ▼                             ▼
windows/Invoke-Strike…​.ps1   linux/strike_linux_posture…​.sh   linux/strike_syslog_emitter.sh
 (audit postura Windows)      (audit postura Linux)           (ráfaga syslog al SIEM)
        │                            │                             │
        ▼                            ▼                             ▼
 reporte HTML+CSV+JSON        reporte HTML+CSV              datagramas UDP/TCP + manifiesto CSV

tools/build_manuals.py  →  entregables/*/Manual-*.pdf   (reportlab)
```

**Idea central:** todo se deriva de un único catálogo. El ID estable
`escenario.paso` (ej. `1.1`, `3.14`, `8.48`) viaja por los tres caminos para dar
trazabilidad end-to-end ("¿llegó el evento 3.14?", "¿este host cubre 3.14?").

---

## 3. El catálogo maestro

- **Generador:** `catalog/build_catalog.py`. Parsea los `.md` y escribe
  `catalog/strike_catalog.json`. Regenerar con:
  ```bash
  python catalog/build_catalog.py
  ```
- **Orden de escenarios** fijado en la lista `SCENARIOS` del script. **Ese orden
  define los IDs** (`scenario_id`). ⚠️ Reordenar = romper IDs ya usados en el
  SIEM. No reordenar sin avisar.

| scenario_id | platform | pasos | fuente .md |
|---|---|---|---|
| 1 | windows | 14 | 2025-PA-P1-Windows-Baseline-v01 |
| 2 | windows | 17 | 2026-PA-P2-Windows-Baseline-v01 |
| 3 | windows | 18 | 2026-PA-P2-Windows-Baseline-v02 |
| 4 | windows | 6 | Binpack v01 |
| 5 | windows | 5 | Binpack v02 |
| 6 | windows | 6 | Binpack v03 |
| 7 | linux | 11 | 2025-PA-P1-Linux-Baseline-v01 |
| 8 | aws | 48 | AWS Atomic Identity… |
| 9 | azure | 45 | Azure Subscription… |
| 10 | cicd | 40 | CICD Supply Chain… |
| 11 | hybrid-ad | 45 | Hybrid AD → Entra |
| 12 | kubernetes | 34 | Kubernetes Cluster… |
| 13 | entra-m365 | 48 | Entra ID + M365 |

**Total: 337 pasos.** Windows = 66, Linux = 11, cloud = 260.

**Schema por paso:**
```json
{
  "strike_id": "3.14", "scenario_id": 3, "scenario_name": "...",
  "platform": "windows", "step": 14,
  "title": "...", "mitre": "T1218.011",
  "command": "…texto fiel del .md (multilínea)…",
  "summary_cmd": "…una línea, sin andamiaje, truncado a 300 chars…"
}
```

**Detalles del parser a tener presente:**
- `summary_cmd` quita boilerplate (`set -euo pipefail`, `mkdir -p`, guardas
  `command -v`, `AWS_PAGER=""`, `| tee …`, `Import-Module`, etc.), aplana a una
  línea con ` ; ` y trunca a 300. `command` queda fiel al original.
- **8 pasos sin comando** (los "Descarga de X" de los binpacks): `command` y
  `summary_cmd` vacíos → los consumidores caen al `title`.
- **23 pasos con `mitre="N/A"`** (no tenían `**MITRE:**` ni Txxxx en el título).
- El campo `mitre` se toma de la línea `**MITRE:**`; si falta, del primer
  `Txxxx` del título. Hay desalineaciones intencionales en el origen (p.ej. el
  título dice T1136.001 pero `**MITRE:**` dice T1087.001): se respeta el `.md`.

---

## 4. `windows/Invoke-StrikeTelemetryAudit.ps1`

Audita la **postura de telemetría** del host Windows contra los 66 pasos
`platform=windows`. PowerShell 5.1, **requiere admin** (para `auditpol`).

**Parámetros:** `-CatalogPath` `-OutputDir` (def. `.\strike-audit-out`) `-Full`
`-DeepSysmon` `-OpenReport` `-LogoPath`. Autodetecta catálogo en `.\` o
`..\catalog\` relativo al script, y `logo.png` en `.`/`..`.

**Probes (una vez, cacheadas en `$Signals`):**
- `auditpol /get /subcategory:"{GUID}" /r` — las **GUID son locale-independientes**;
  el texto "Inclusion Setting" sí está localizado → se detecta éxito con el regex
  `$SuccessTokens` (Success/Correcto/Exito/Erfolg/…). GUIDs en `$AuditGuids`.
- Registro: `ProcessCreationIncludeCmdLine_Enabled`, ScriptBlock/Module logging.
- Sysmon: servicio `Sysmon`/`Sysmon64` + canal `Microsoft-Windows-Sysmon/Operational`.
- `BITS-Client/Operational` y salud de canales (`Get-WinEvent -ListLog`).

**Mapeo paso→señales:** `Get-RequiredSignals $cmd $mitre` devuelve requisitos,
cada uno con `Alt` (alternativas, OR) y `Critical`. Es **heurística por regex**
sobre el texto del comando (powershell/reg/net user/schtasks/sc.exe/netsh/bitsadmin/…).

**Veredicto (`Eval-Req` + lógica):**
- Req satisfecho si **alguna** alternativa está `OK`; `PARTIAL` si hay
  `PARTIAL/UNKNOWN`; si no, `MISSING`.
- Si un req **Critical** no es OK → `NOT_COVERED`. Si hay faltantes/parciales no
  críticos → `PARTIAL`. Todo OK → `COVERED`.
- El req crítico es "ejecución de proceso" (`PROC_4688` o `SYSMON`). Por eso
  **sin admin** (auditpol UNKNOWN) + sin Sysmon → todo `NOT_COVERED`.

**Remediación:** `$Remediation` mapea cada señal → `{What, Gpo, Cmd}`. Alimenta
la sección "Acciones recomendadas" del HTML.

**Salidas:** CSV (`Export-Csv -Encoding UTF8`, con BOM — OK para Excel), JSON y
HTML **sin BOM** (via `[IO.File]::WriteAllText(..., UTF8Encoding($false))` —
`Set-Content -Encoding UTF8` en 5.1 mete BOM y rompe `json.load`).

**HTML:** `New-HtmlReport` — banda de certificación oscura con logo embebido
(data-URI base64), KPIs, acciones, postura, scorecard, tabla por paso con filtro JS.

---

## 5. `linux/strike_linux_posture_audit.sh`

Equivalente Linux (11 pasos `platform=linux`). **Bash 4+** (arreglos asociativos),
**requiere root** para `auditctl -l`.

**Parámetros:** `--catalog --output-dir --logo --full --no-html`.

**Probes → `SIG_STATE/SIG_NAME/SIG_DETAIL`:**
- auditd instalado/corriendo (`auditctl -s`, `systemctl is-active`).
- Reglas: se concatena `auditctl -l` + `/etc/audit/rules.d/*.rules` en
  `$ALL_AUDIT_RULES`; `rules_match <regex>` busca ahí. Señales: `EXECVE`,
  `W_IDENTITY`, `W_SUDOERS`, `W_CRON`, `W_RC`, `W_HIST`, `W_MODULES`.
- `SYSLOG_RUN` (rsyslog/syslog-ng activo) y `SYSLOG_FWD` (destino remoto
  `@`/`@@`/`omfwd` en `/etc/rsyslog*`, o `destination network()` en syslog-ng).
- `JOURNALD` persistente, `EXTRA` (sysmon-for-linux/auditbeat/osquery/falco).

**Mapeo:** `required_for $cmd $mitre` imprime líneas `LABEL|ALT1,ALT2|critical`.
`eval_alt` evalúa alternativas. Misma lógica de veredicto que Windows.
Remediación en `REM_WHAT/REM_CMD` (comandos `auditctl` concretos).

**⚠️ GOTCHA ya corregido (no reintroducir):** las filas de resultados se guardan
en `RESULTS_TSV` separadas por TAB y se releen con `IFS=$'\t' read`. Como el TAB
**es whitespace para `read`**, los campos vacíos consecutivos se colapsan y
**desalinean las columnas**. Solución aplicada: se usa centinela `-` para
`missing`/`partial` vacíos al escribir, y cada consumidor (consola/CSV/HTML)
trata `-` como vacío. Si agregás campos opcionales al TSV, aplicá el mismo patrón.

**Salidas:** HTML (misma banda/branding, logo via `base64 -w0` o `base64|tr -d`)
+ CSV.

---

## 6. `linux/strike_syslog_emitter.sh`

Emisor de la ráfaga de certificación al SIEM. **No ejecuta nada.**

**Parámetros clave:** `-s` (IP, obligatorio salvo `--dry-run`), `-p` (514),
`--proto udp|tcp`, `-H` (hostname, def. `EP_CERTIFICATION`), `-t` (tag
`STRIKE_CERT`), `--format rfc3164|rfc5424`, `--facility --severity`,
`--scenario N[,N]`, `--platform`, `--delay-ms`, `--manifest`, `--no-markers`,
`--dry-run`.

**Transporte:** intenta `/dev/<proto>/<ip>/<port>` (feature de bash); si no,
`nc`/`ncat`. UDP = un datagrama por `printf`. Lee el catálogo con **python3 o jq**
(`extract_rows`), emite TSV y el bash lo recorre.

**Evento (RFC3164):**
```
<PRI>Mmm dd HH:MM:SS EP_CERTIFICATION STRIKE_CERT[pid]: STRIKE_CERT run_id=… id=1.1 mitre=T1047 platform=windows scenario="…" step="…" cmd="…"
```
RFC5424 añade `MSGID=STRIKE_<id>` y structured-data `[strike@47111 …]`. Marcadores
`RUN_START`/`RUN_END` acotan el lote; `run_id` único por corrida. `--manifest`
escribe CSV `sent_utc,run_id,strike_id,scenario_id,platform,mitre,title` para
reconciliar en el SIEM.

**Nota conceptual importante:** para los escenarios **cloud** (8–13), el evento
syslog lleva el `summary_cmd` como texto, pero las reglas cloud del SIEM realmente
se disparan con logs de auditoría de la nube (CloudTrail, Azure Activity, k8s
audit…), no con syslog de endpoint. Para cloud, la ráfaga sirve de **trazabilidad
de IDs**, no de disparo realista. Documentarlo si el cliente espera alertas cloud.

---

## 7. `tools/build_manuals.py`

Genera los 2 PDF con **reportlab** (+ Pillow para el logo). Regenerar:
```bash
python tools/build_manuals.py
```
Escribe directo en `entregables/*/Manual-*.pdf`. El contenido de cada manual está
en `manual_cliente()` y `manual_interno()` (listas de flowables). La banda de
certificación está en `cert_band()`. Para previsualizar sin poppler: usar PyMuPDF
(`fitz`) → `get_pixmap(dpi=110).save(png)` y abrir el PNG.

---

## 8. `entregables/` (paquetes finales)

Son **copias** autocontenidas; la **fuente de verdad es la raíz del repo**.

```
entregables/
├─ validacion-fuentes-clientes/       (para el CLIENTE; Windows + Linux)
│  ├─ Manual-Validacion-Fuentes-de-Informacion.pdf
│  ├─ windows/Invoke-StrikeTelemetryAudit.ps1
│  ├─ linux/strike_linux_posture_audit.sh
│  ├─ catalog/strike_catalog.json
│  ├─ logo.png · LEEME.txt
└─ certificacion-devel-interno/        (uso INTERNO; emisor syslog)
   ├─ Manual-Certificacion-Reglas-SIEM-INTERNO.pdf
   ├─ linux/strike_syslog_emitter.sh
   ├─ catalog/strike_catalog.json
   ├─ logo.png · LEEME.txt
```

Los scripts autodetectan `../catalog/strike_catalog.json` y `../logo.png`, así que
cada carpeta funciona sola.

**⚠️ Si editás un script en la raíz, re-copialo al entregable** (y corré
`build_manuals.py` si cambió el texto del manual). Hoy la copia es manual; un
`tools/package.sh` que sincronice + zipee sería una buena mejora (ver TODO).

---

## 9. Cómo probar (rápido)

```bash
# 1. Catálogo
python catalog/build_catalog.py                       # => 337 pasos

# 2. Emisor: ver sin enviar / contar
bash linux/strike_syslog_emitter.sh --dry-run --no-markers | wc -l    # 337
# Self-test UDP real: levantar un listener python en 127.0.0.1:5514 y
bash linux/strike_syslog_emitter.sh -s 127.0.0.1 -p 5514 --scenario 4

# 3. Audit Linux (degradado en Git Bash: sin auditd da MISSING, no crashea)
bash linux/strike_linux_posture_audit.sh --output-dir ./_t

# 4. Manuales
python tools/build_manuals.py
```

```powershell
# 5. Audit Windows — ELEVADO (si no, auditpol=UNKNOWN y todo NOT_COVERED)
powershell -ExecutionPolicy Bypass -File .\windows\Invoke-StrikeTelemetryAudit.ps1 -OpenReport
```

**Lanzar PS elevado desde un proceso no elevado** (patrón probado; ⚠️ el CWD de un
proceso elevado es `System32`, por eso hay que pasar `-OutputDir` **absoluto**):
```powershell
$proj=(Get-Location).Path
Start-Process powershell -Verb RunAs -Wait -WorkingDirectory $proj -ArgumentList @(
  '-NoProfile','-ExecutionPolicy','Bypass','-File', "$proj\windows\Invoke-StrikeTelemetryAudit.ps1",
  '-OutputDir', "$proj\strike-audit-out")
# abrir el HTML desde contexto NO elevado:
Start-Process (Get-ChildItem .\strike-audit-out\*.html | Sort LastWriteTime | Select -Last 1).FullName
```

**Estado de validación:** Windows audit ejecutado real **elevado** en el box de
dev (4688 y cmdline resultaron MISSING, Sysmon PARTIAL → 66 NOT_COVERED; hallazgo
legítimo de esa máquina). Emisor probado por UDP real contra listener local.
Linux audit probado **solo en Git Bash degradado** (sin auditd/systemctl) →
**falta validarlo en un host Linux real con auditd**.

---

## 10. Gotchas / puntos frágiles (lista de revisión)

- **auditpol localizado:** `$SuccessTokens` cubre varios idiomas pero no todos.
  Si un cliente usa un locale raro, un subcategory habilitado podría leerse como
  MISSING. Mitigación futura: parsear por posición/estado numérico.
- **Sin privilegios:** Windows sin admin → auditpol UNKNOWN; Linux sin root →
  `auditctl -l` vacío (`AUDIT_READABLE=0` lo marca UNKNOWN). Ambos reportes lo
  advierten con banner, pero inflan NOT_COVERED. Siempre elevado/root.
- **BOM en PS 5.1:** usar `WriteAllText(...UTF8Encoding $false)` para JSON/HTML.
- **TSV + TAB whitespace en bash:** centinela `-` (ver §5). No romper.
- **`/dev/udp`** depende de que bash tenga net-redirections; hay fallback a `nc`.
- **Mapeo heurístico:** `Get-RequiredSignals`/`required_for` son regex sobre el
  comando. Comandos nuevos o renombrados pueden no matchear la señal correcta.
  Revisar al añadir escenarios.
- **Python de Windows vs Git Bash `/tmp`:** el `python` del PATH es el de Windows
  y no entiende `/tmp` de Git Bash; usar rutas Windows para archivos temporales
  en pruebas.
- **REG_AUDIT (4657)** requiere SACL además de la subcategoría; se marca pero no
  se verifica la SACL.
- **Cloud por syslog:** trazabilidad, no disparo realista (ver §6).

---

## 11. TODO / mejoras sugeridas

- [ ] Validar `strike_linux_posture_audit.sh` en un host Linux real con auditd.
- [ ] `tools/package.sh`: sincronizar raíz→entregables y generar `.zip` por paquete.
- [ ] Exportar JSON también en el audit Linux (hoy HTML+CSV).
- [ ] Afinar mapeo: Sysmon EventID 10 (LSASS) para binpacks de mimikatz/credenciales.
- [ ] `-DeepSysmon`: parsear la config efectiva y verificar cobertura por EventID.
- [ ] Modo del emisor que confirme recepción (TCP + ack lógico) o reintentos.
- [ ] Firmar los PDF / versionarlos.
- [ ] Localización de `auditpol` más robusta.

---

## 12. Dependencias

- **Windows:** PowerShell 5.1+, admin para `auditpol`. Sin módulos externos.
- **Linux:** bash 4+, `auditd`/`auditctl`, `systemctl`; `python3` o `jq` (emisor);
  `base64` (logo en HTML). Root para auditoría.
- **Build (dev):** Python 3.13, `reportlab`, `Pillow` (manuales), `fitz`/PyMuPDF
  (preview opcional). `catalog/build_catalog.py` usa solo stdlib.
