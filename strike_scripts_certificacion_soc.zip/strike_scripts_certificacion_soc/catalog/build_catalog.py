#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_catalog.py  -  Generador del catalogo maestro STRIKE.

Parsea los .md exportados desde STRIKE y produce strike_catalog.json:
un unico inventario de TODOS los pasos (comandos) de la metodologia,
con un ID estable "escenario.paso" (ej. 1.1, 3.14) para trazabilidad
end-to-end entre el audit de Windows y el emisor de syslog.

No ejecuta ningun comando: solo lee texto y arma datos.

Uso:
    python build_catalog.py            # usa ./STRIKE/STRIKE junto al repo
    python build_catalog.py <ruta_raiz_STRIKE>
"""

import json
import os
import re
import sys

# (scenario_id, platform, carpeta, archivo)
# El orden fija los IDs de escenario; no reordenar sin avisar al SOC.
SCENARIOS = [
    (1,  "windows",      "2025-PA-P1-Windows-Baseline-v01",                        "windows-baseline-p1.md"),
    (2,  "windows",      "2026-PA-P2-Windows-Baseline-v01",                        "windowsbaselinep2v1.md"),
    (3,  "windows",      "2026-PA-P2-Windows-Baseline-v02",                        "windowsbaselinep2v2.md"),
    (4,  "windows",      "2026-PA-P1-Windows-Binpack-MalwareWriteRun-v01",         "binpackv1-malwarewriteandrun.md"),
    (5,  "windows",      "2026-PA-P1-Windows-Binpack-MalwareWriteRun-v02",         "binpackv2-malwarewriteandrun.md"),
    (6,  "windows",      "2026-PA-P1-Windows-Binpack-MalwareWriteRun-v03",         "binpackv3-malwarewriteandrun.md"),
    (7,  "linux",        "2025-PA-P1-Linux-Baseline-v01",                          "linuxbaseline.md"),
    (8,  "aws",          "AWS Atomic Identity Compromise and Data Plane Intrusion", "aws-atomic-identity-compromise-and-data-plane-intrusion.md"),
    (9,  "azure",        "Azure Subscription and Resource Compromise",             "azure-subscription-and-resource-compromise.md"),
    (10, "cicd",         "CICD Supply Chain Compromise to Production",             "ci-cd-supply-chain-compromise-to-production.md"),
    (11, "hybrid-ad",    "Hybrid Active Directory to Microsoft Entra Compromise",  "hybrid-active-directory-to-microsoft-entra-compromise.md"),
    (12, "kubernetes",   "Kubernetes Cluster Compromise and Workload Pivot",       "kubernetes-cluster-compromise-and-workload-pivot.md"),
    (13, "entra-m365",   "Microsoft Entra ID and Microsoft 365 Identity Compromise","microsoft-entra-id-and-microsoft-365-identity-compromise.md"),
]

# Lineas de "andamiaje" que no aportan a la deteccion y ensucian el mensaje syslog.
BOILERPLATE_RE = [
    re.compile(r'^set\s+-[eux]+o?\b'),
    re.compile(r'^set\s+-[eux]+\b'),
    re.compile(r'^STRIKE_[A-Z_]+='),
    re.compile(r'^[A-Z_]+="\$\{[A-Z_]+:-'),          # VAR="${VAR:-default}"
    re.compile(r'^mkdir\s+-p\b'),
    re.compile(r'^command\s+-v\b'),
    re.compile(r'^\$ErrorActionPreference\b'),
    re.compile(r'^Import-Module\b'),
    re.compile(r'^\s*$'),
]
# Prefijos/sufijos de ruido que envuelven al comando real.
PREFIX_STRIP_RE = re.compile(r'^(AWS_PAGER="")\s+')
SUFFIX_TEE_RE   = re.compile(r'\s*\|\s*tee\b.*$')

STEP_RE   = re.compile(r'^###\s+(\d+)\.\s+(.*?)\s*$')
MITRE_RE  = re.compile(r'\*\*MITRE:\*\*\s*([A-Za-z0-9.\/,\s-]+?)\s*$')
MITRE_IN_TITLE_RE = re.compile(r'\b(T\d{4}(?:\.\d{3})?)\b')
FENCE_RE  = re.compile(r'^```')


def parse_file(path):
    """Devuelve lista de pasos crudos: (step_no, title, mitre, command)."""
    with open(path, encoding="utf-8") as fh:
        lines = fh.read().splitlines()

    steps = []
    cur = None          # dict del paso en curso
    in_code = False
    code_buf = []

    def flush():
        if cur is not None:
            cur["command"] = "\n".join(code_buf).strip()
            steps.append(cur)

    for line in lines:
        m = STEP_RE.match(line)
        if m and not in_code:
            # cerrar paso anterior
            flush()
            code_buf[:] = []
            cur = {
                "step": int(m.group(1)),
                "title": m.group(2).strip(),
                "mitre": "",
                "command": "",
            }
            continue

        if cur is None:
            continue

        if FENCE_RE.match(line):
            # solo capturamos el primer bloque de codigo del paso
            if in_code:
                in_code = False
            elif not code_buf:
                in_code = True
            continue

        if in_code:
            code_buf.append(line)
            continue

        mm = MITRE_RE.search(line)
        if mm and not cur["mitre"]:
            cur["mitre"] = mm.group(1).strip()

    # cerrar el ultimo (ojo si quedo bloque abierto)
    in_code = False
    flush()

    # fallback de MITRE: tomarlo del titulo si no habia linea **MITRE:**
    for s in steps:
        if not s["mitre"]:
            tm = MITRE_IN_TITLE_RE.search(s["title"])
            s["mitre"] = tm.group(1) if tm else "N/A"
    return steps


def summarize_command(command, title, limit=300):
    """Comando de una sola linea, sin andamiaje, para el mensaje syslog."""
    if not command:
        return ""
    kept = []
    for raw in command.split("\n"):
        line = raw.strip()
        if any(rx.search(line) for rx in BOILERPLATE_RE):
            continue
        line = PREFIX_STRIP_RE.sub("", line)
        line = SUFFIX_TEE_RE.sub("", line)
        line = line.strip()
        if line:
            kept.append(line)
    flat = " ; ".join(kept) if kept else command.replace("\n", " ; ")
    flat = re.sub(r"\s+", " ", flat).strip()
    if len(flat) > limit:
        flat = flat[:limit - 3].rstrip() + "..."
    return flat


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.dirname(here)
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(repo, "STRIKE", "STRIKE")

    if not os.path.isdir(root):
        print(f"[!] No encuentro la raiz STRIKE en: {root}", file=sys.stderr)
        sys.exit(1)

    catalog = []
    for sid, platform, folder, fname in SCENARIOS:
        path = os.path.join(root, folder, fname)
        if not os.path.isfile(path):
            print(f"[!] Falta archivo (escenario {sid}): {path}", file=sys.stderr)
            continue
        steps = parse_file(path)
        for s in steps:
            catalog.append({
                "strike_id":     f"{sid}.{s['step']}",
                "scenario_id":   sid,
                "scenario_name": folder,
                "platform":      platform,
                "step":          s["step"],
                "title":         s["title"],
                "mitre":         s["mitre"],
                "command":       s["command"],
                "summary_cmd":   summarize_command(s["command"], s["title"]),
            })
        print(f"[ok] escenario {sid:>2} ({platform:<11}) {folder}: {len(steps)} pasos")

    out = os.path.join(here, "strike_catalog.json")
    meta = {
        "catalog_version": "1.0",
        "generated_from":  "STRIKE methodology export",
        "total_steps":     len(catalog),
        "scenarios":       [{"scenario_id": s[0], "platform": s[1], "name": s[2]} for s in SCENARIOS],
    }
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"meta": meta, "steps": catalog}, fh, ensure_ascii=False, indent=2)

    print(f"\n[+] Catalogo escrito: {out}")
    print(f"[+] Total de pasos: {len(catalog)}")


if __name__ == "__main__":
    main()
